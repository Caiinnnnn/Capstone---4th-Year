﻿Imports System.Data.SqlClient

Module Connections
    'connection for database
    Public Function StrConnection() As SqlConnection
        'Return New SqlConnection("Server = LAPTOP-29BSDVQ5; Initial Catalog = payrollsystem; Trusted_Connection=True;")
        Return New SqlConnection("Server = LAPTOP-29BSDVQ5\SQLEXPRESS; Initial Catalog = capstone_payrollsystem; Trusted_Connection=True;")
    End Function

    ' initializing database connection
    Public strCon As SqlConnection = StrConnection()

    Public result As String
    Public cmd As New SqlCommand
    Public da As New SqlDataAdapter
    Public dt As New DataTable
    Public myreader As SqlDataReader

    'for inserting sql
    Public Sub CreateSql(ByVal sql As String, ByVal connection As SqlConnection, ByVal prompt_msg As Boolean)
        Try
            'connection.Open()
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
                result = cmd.ExecuteNonQuery
                If result = 0 Then
                    If prompt_msg = True Then
                        MessageBox.Show("Failed to add data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                Else
                    If prompt_msg = True Then
                        MessageBox.Show("Data Saved Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message + " - create")
            Exit Sub
        Finally
            connection.Close()
        End Try
    End Sub

    'for loading dtgview with table data
    Public Sub Reload(ByVal sql As String, ByVal DTG As Object, ByVal connection As SqlConnection)
        Try
            dt = New DataTable
            'connection.Open()
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
            End With
            da.SelectCommand = cmd
            da.Fill(dt)
            DTG.datasource = dt
        Catch ex As Exception
            MessageBox.Show(ex.Message + " - reload")
            Exit Sub
        Finally
            connection.Close()
            da.Dispose()
        End Try
    End Sub

    'for searching in datagridview
    Public Sub Search(ByVal sql As String, ByVal DTG As Object, ByVal connection As SqlConnection)
        Try
            dt = New DataTable
            'connection.Open()
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
            End With
            da.SelectCommand = cmd
            da.Fill(dt)
            DTG.datasource = dt
        Catch ex As Exception
            MessageBox.Show(ex.Message + " - search")
            Exit Sub
        Finally
            connection.Close()
            da.Dispose()
        End Try
    End Sub

    Public Sub Login(ByVal sql As String, ByVal username As String, ByVal password As String, ByVal connection As SqlConnection)
        Try
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
            End With

            dt = New DataTable
            da = New SqlDataAdapter(sql, connection)
            da.Fill(dt)

            If dt.Rows.Count = 0 Then
                MessageBox.Show("Invalid Username/Password")
                App.TxtboxUsername.Clear()
                App.TxtboxPassword.Clear()
                App.TxtboxUsername.Focus()
                Exit Sub
            Else
                GlobalVariables.loginUsername = App.TxtboxUsername.Text
                GlobalVariables.loginPassword = App.TxtboxUsername.Text
                Dashboard.Show()
                connection.Close()
                App.Hide()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message & " - login")
            App.TxtboxUsername.Clear()
            App.TxtboxPassword.Clear()
            App.TxtboxUsername.Focus()
            Exit Sub
        Finally
            connection.Close()
        End Try
    End Sub

    'for retrieving single row from a table
    Public Sub RetrieveRow(ByVal sql As String, ByVal connection As SqlConnection)
        If connection.State = ConnectionState.Open Then
            connection.Close()
            connection.Open()
        ElseIf connection.State = ConnectionState.Closed Then
            connection.Open()
        End If

        Dim cmd As New SqlCommand(sql, connection)

        myreader = cmd.ExecuteReader

        myreader.Read()
    End Sub

    'for updating values in a table
    Public Sub UpdateSql(ByVal sql As String, ByVal connection As SqlConnection, ByVal prompt_msg As Boolean)
        Try
            'connection.Open()

            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If

            With cmd
                .Connection = connection
                .CommandText = sql

                result = cmd.ExecuteNonQuery
                If result = 0 Then
                    If prompt_msg = True Then
                        MessageBox.Show("Failed to update data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                Else
                    If prompt_msg = True Then
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End
                    End If
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message + " - updates")
            Exit Sub
        Finally
            connection.Close()
        End Try
    End Sub

    ' for checking if a unique id exists
    Public Sub CheckID(ByVal sql As String, ByVal connection As SqlConnection)
        Try
            'connection.Open()
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
            End With

            dt = New DataTable
            da = New SqlDataAdapter(sql, connection)
            da.Fill(dt)

        Catch ex As Exception
            MessageBox.Show(ex.Message + " - checkID")
            Exit Sub
        Finally
            If connection.State = ConnectionState.Open Then
                connection.Close()
                da.Dispose()
            End If
        End Try
    End Sub

    'adding items to comboboxes
    Public Sub FillComboboxes(ByVal sql As String, ByVal value As String, ByVal cmbox As Object, ByVal connection As SqlConnection)
        Try
            dt = New DataTable

            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
            End With
            da.SelectCommand = cmd
            da.Fill(dt)

            cmbox.DataSource = dt
            cmbox.DisplayMember = value
            cmbox.ValueMember = value

        Catch ex As Exception
            MessageBox.Show(ex.Message + " - fillComboboxes")
            Exit Sub
        Finally
            connection.Close()
            da.Dispose()
        End Try
    End Sub

    'for retrieving multiple datas from a table for viewing
    Public Function RetrieveData(ByVal sql As String, ByVal connection As SqlConnection)

        If connection.State = ConnectionState.Open Then
            connection.Close()
            connection.Open()
        ElseIf connection.State = ConnectionState.Closed Then
            connection.Open()
        End If

        dt = New DataTable

        With cmd
            .Connection = connection
            .CommandText = sql
        End With

        da.SelectCommand = cmd
        da.Fill(dt)

        Return dt

        connection.Close()

    End Function

    'for deleting multiple rows
    Public Sub DeleteRows(ByVal sql As String, ByVal connection As SqlConnection)
        Try
            'connection.Open()
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If

            With cmd
                .Connection = connection
                .CommandText = sql
                result = cmd.ExecuteNonQuery
                If result = 0 Then
                    MessageBox.Show("Failed to add data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    'MessageBox.Show("Data Deleted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message + " - deleteRows")
            Exit Sub
        Finally
            connection.Close()
        End Try
    End Sub

    Public Sub LoginWithAdmin(ByVal sql As String, ByVal username As String, ByVal password As String, ByVal connection As SqlConnection)
        Try
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
            End With

            dt = New DataTable
            da = New SqlDataAdapter(sql, connection)
            da.Fill(dt)

            If dt.Rows.Count = 0 Then
                MessageBox.Show("Invalid Username/Password")
                App.TxtboxUsername.Clear()
                App.TxtboxPassword.Clear()
                App.TxtboxUsername.Focus()
                Exit Sub
            Else
                GlobalVariables.loginUsername = App.TxtboxUsername.Text
                GlobalVariables.loginPassword = App.TxtboxUsername.Text

                RetrieveRow("SELECT * FROM user_accts WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon)
                Dim position As String = myreader("UserType").ToString

                App.Hide()

                If position = "Admin" Then
                    'MessageBox.Show("Hello")
                    AdminDashboard.Show()
                    AdminDashboard.Focus()
                Else
                    Dashboard.Show()
                End If

                connection.Close()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message & " - LoginWithAdmin")
            App.TxtboxUsername.Clear()
            App.TxtboxPassword.Clear()
            App.TxtboxUsername.Focus()
            Exit Sub
        Finally
            connection.Close()
        End Try
    End Sub

    Public Function CountSql(ByVal sql As String, ByVal connection As SqlConnection) As Integer
        Try
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
                .CommandType = CommandType.Text
            End With
            Dim count As Integer = Convert.ToInt64(cmd.ExecuteScalar())
            Return count
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            connection.Close()
        End Try
    End Function

    Public Sub CreateQuery(ByVal sql As String,
                           ByVal connection As SqlConnection,
                           ByVal prompt_msg As Boolean,
                           Optional ByVal success_msg As String = "Data added successfully",
                           Optional ByVal failed_msg As String = "Failed to add data")
        Try
            'connection.Open()
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
                result = cmd.ExecuteNonQuery
                If result = 0 Then
                    If prompt_msg = True Then
                        MessageBox.Show(failed_msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                Else
                    If prompt_msg = True Then
                        MessageBox.Show(success_msg, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message + " - CreateQuery")
            Exit Sub
        Finally
            connection.Close()
        End Try
    End Sub

    Public Sub UpdateQuery(ByVal sql As String,
                           ByVal connection As SqlConnection,
                           ByVal prompt_msg As Boolean,
                           Optional ByVal success_msg As String = "Data updated successfully",
                           Optional ByVal failed_msg As String = "Failed to update data")
        Try
            'connection.Open()
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
                result = cmd.ExecuteNonQuery
                If result = 0 Then
                    If prompt_msg = True Then
                        MessageBox.Show(failed_msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                Else
                    If prompt_msg = True Then
                        MessageBox.Show(success_msg, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message + " - UpdateQuery")
            Exit Sub
        Finally
            connection.Close()
        End Try
    End Sub

    Public Sub DeleteQuery(ByVal sql As String,
                           ByVal connection As SqlConnection,
                           ByVal prompt_msg As Boolean,
                           Optional ByVal success_msg As String = "Data deleted successfully",
                           Optional ByVal failed_msg As String = "Failed to delete data")
        Try
            'connection.Open()
            If connection.State = ConnectionState.Open Then
                connection.Close()
                connection.Open()
            ElseIf connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            With cmd
                .Connection = connection
                .CommandText = sql
                result = cmd.ExecuteNonQuery
                If result = 0 Then
                    If prompt_msg = True Then
                        MessageBox.Show(failed_msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                Else
                    If prompt_msg = True Then
                        MessageBox.Show(success_msg, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message + " - DeleteQuery")
            Exit Sub
        Finally
            connection.Close()
        End Try
    End Sub

End Module
