﻿Module InputChecking
    Public Function CheckForAlphaCharacters(ByVal StringToCheck As String)
        For i = 0 To StringToCheck.Length - 1
            If Not Char.IsLetter(StringToCheck.Chars(i)) Then ' checks if the input is not alpha
                If Not Char.IsWhiteSpace(StringToCheck.Chars(i)) Then 'checks if the input is not a whitespace
                    Return ""
                End If
            End If
        Next

        Return StringToCheck
    End Function

    Public Function CheckForNumericCharacters(ByVal StringToCheck As String)
        For i = 0 To StringToCheck.Length - 1
            If Not Char.IsNumber(StringToCheck.Chars(i)) Then ' checks if the input is not numeric
                Return ""
            End If
        Next

        Return StringToCheck
    End Function

    Public Function validateDoublesAndCurrency(ByVal stringValue As String)
        Dim value As Double
        If Double.TryParse(stringValue, value) Then
            stringValue = stringValue
        Else
            stringValue = ""
        End If

        Return stringValue
    End Function

    Public Function CountRowsDtglist(ByVal columnName As String, ByVal search As String, ByVal dtglist As DataGridView)

        Dim rowCount As Integer

        For Each row As DataGridViewRow In dtglist.Rows
            If row.Cells(columnName).Value = search Then
                rowCount += 1
            End If
        Next

        Return rowCount

    End Function
End Module
