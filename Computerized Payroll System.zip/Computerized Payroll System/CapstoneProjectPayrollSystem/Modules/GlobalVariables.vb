﻿Module GlobalVariables
    Public loginUsername As String
    Public loginPassword As String
    Public loginFullName As String
    Public loginType As String
    Public loginPosition As String
End Module
