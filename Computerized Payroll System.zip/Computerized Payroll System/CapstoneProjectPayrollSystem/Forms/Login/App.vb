﻿Public Class App
    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Me.Close()
    End Sub

    Private Sub ChckboxShowPassword_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxShowPassword.CheckedChanged
        If ChckboxShowPassword.Checked = True Then
            TxtboxPassword.PasswordChar = ""
        Else
            TxtboxPassword.PasswordChar = "*"
        End If
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        LoginWithAdmin("SELECT * FROM user_accts WHERE Username = '" & TxtboxUsername.Text & "'
                                        AND Password = '" & TxtboxPassword.Text & "'", TxtboxUsername.Text, TxtboxPassword.Text, strCon)
    End Sub
End Class