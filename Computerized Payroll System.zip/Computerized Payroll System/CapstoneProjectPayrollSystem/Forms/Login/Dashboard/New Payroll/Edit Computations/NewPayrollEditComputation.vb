﻿Public Class NewPayrollEditComputation

    Public Sub NewPayrollEdit_Compute()
        ' filling empty textboxes and values
        If CmboxMonth.Text = "1.0" Then
            TxtboxCalendarDays.Text = "22"
            TxtboxTotalNoOfDaysServed.Text = "22"
        ElseIf CmboxMonth.Text = "0.5" Then
            TxtboxCalendarDays.Text = "22"
            TxtboxTotalNoOfDaysServed.Text = "11"
        End If

        If TxtboxCalendarDays.Text = "" Then
            TxtboxCalendarDays.Text = "22"
        End If

        If TxtboxTotalNoOfDaysServed.Text = "" Then
            TxtboxTotalNoOfDaysServed.Text = "22"
        End If

        If TxtboxAdjustmentAdd.Text = "" Then
            TxtboxAdjustmentAdd.Text = "0"
        End If

        If TxtboxAdjustmentSub.Text = "" Then
            TxtboxAdjustmentSub.Text = "0"
        End If

        If TxtboxAbsences.Text = "" Then
            TxtboxAbsences.Text = "0"
        End If

        If TxtboxTardiness.Text = "" Then
            TxtboxTardiness.Text = "0"
        End If

        If TxtboxHdmf.Text = "" Then
            TxtboxHdmf.Text = "0"
        End If

        If TxtboxTax.Text = "" Then
            TxtboxTax.Text = "0"
        End If

        ' calendar days cannot be lower than total no of days served
        If CDbl(TxtboxCalendarDays.Text) < CDbl(TxtboxTotalNoOfDaysServed.Text) Then
            MessageBox.Show("Invalid digit variables")
            Exit Sub
        End If

        ' setting base variables
        Dim month As Double
        Dim calendarDays As Double
        Dim totalNoOfDaysServed As Double
        Dim monthlyRate As Double

        If CmboxMonth.SelectedIndex = -1 Then
            month = 0
        Else
            month = CDbl(CmboxMonth.Text)
        End If

        calendarDays = CDbl(TxtboxCalendarDays.Text)
        totalNoOfDaysServed = CDbl(TxtboxTotalNoOfDaysServed.Text)
        monthlyRate = CDbl(TxtboxSalary.Text)

        ' setting base computations and grosspay
        Dim dailyRate As Double
        Dim basic As Double
        Dim absences As Double
        Dim tardiness As Double
        Dim absencesAmount As Double
        Dim tardinessAmount As Double
        Dim leaveWithoutPay As Double
        Dim adjustmentAdd As Double
        Dim adjustmentSub As Double
        Dim grosspay As Double

        dailyRate = Math.Round(monthlyRate / calendarDays, 2)
        basic = Math.Round((monthlyRate / calendarDays) * totalNoOfDaysServed, 2)
        absences = Math.Round(CDbl(TxtboxAbsences.Text), 2)
        tardiness = Math.Round(CDbl(TxtboxTardiness.Text), 2)
        absencesAmount = Math.Round((monthlyRate / 22) * absences, 2)
        tardinessAmount = Math.Round((monthlyRate / 22 / 8 / 60) * tardiness, 2)
        leaveWithoutPay = Math.Round(absencesAmount + tardinessAmount, 2)
        adjustmentAdd = Math.Round(CDbl(TxtboxAdjustmentAdd.Text), 2)
        adjustmentSub = Math.Round(CDbl(TxtboxAdjustmentSub.Text), 2)
        grosspay = (basic + adjustmentAdd) - (absencesAmount + tardinessAmount + adjustmentSub)

        ' setting deductions, tax, and net pay
        Dim sssPs As Double
        Dim sssEs As Double
        Dim phic As Double
        Dim hdmf As Double
        Dim tax As Double
        Dim netpay As Double

        ' Sss
        If ChckboxSss.Checked = True Then
            sssPs = Math.Round(basic * 0.045, 2)
            sssEs = Math.Round(basic * 0.095, 2)

            If CmboxMonth.SelectedIndex = -1 Then
                sssPs = Math.Round(basic * 0.045, 2)
                sssEs = Math.Round(basic * 0.095, 2)
            Else
                sssPs = Math.Round(monthlyRate * 0.045, 2)
                sssEs = Math.Round(monthlyRate * 0.095, 2)
            End If

        ElseIf ChckboxSss.Checked = False Then
            sssPs = 0
            sssEs = 0
        End If

        'phic
        If ChckboxPhic.Checked = True Then
            phic = Math.Round((monthlyRate / 2) * 0.05, 2)
        ElseIf ChckboxPhic.Checked = False Then
            phic = 0
        End If

        'hdmf
        If ChckboxHdmf.Checked = True Then
            hdmf = Math.Round(CDbl(TxtboxHdmf.Text), 2)
        ElseIf ChckboxHdmf.Checked = False Then
            hdmf = 0
        End If

        'tax
        If ChckboxTax.Checked = True Then
            tax = Math.Round(CDbl(TxtboxTax.Text), 2)
        ElseIf ChckboxTax.Checked = False Then
            tax = 0
        End If

        netpay = Math.Round((grosspay) - (sssPs + phic + hdmf + tax), 2)

        ' basic information variables
        Dim remarks As String
        Dim coverage As String

        remarks = TxtboxRemarks.Text.ToUpper

        'converting month digits to 3-lettered month
        Dim months As Dictionary(Of String, String) = New Dictionary(Of String, String)
        months.Add("01", "JAN")
        months.Add("02", "FEB")
        months.Add("03", "MAR")
        months.Add("04", "APR")
        months.Add("05", "MAY")
        months.Add("06", "JUN")
        months.Add("07", "JUL")
        months.Add("08", "AUG")
        months.Add("09", "SEP")
        months.Add("10", "OCT")
        months.Add("11", "NOV")
        months.Add("12", "DEC")

        'for setting the coverage value

        If TxtboxCoverage.Text = "" Then 'if NewPayroll.TxtboxCoverage.Text is empty
            If NewPayroll.TxtboxPeriod.Text = "" Then 'if NewPayroll.TxtboxPeriod.Text is empty
                coverage = months.Item(Format(Date.Today, "MM")) + " " + Date.Today.Year.ToString
            Else
                coverage = NewPayroll.TxtboxPeriod.Text.ToString
            End If
        Else
            coverage = TxtboxCoverage.Text.ToUpper
        End If

        'setting for output
        TxtboxTotalDailyRate.Text = dailyRate
        TxtboxTotalBasic.Text = basic
        TxtboxTotalAbsencesCount.Text = absences
        TxtboxTotalTardinessCount.Text = tardiness
        TxtboxTotalAbsencesAmount.Text = absencesAmount
        TxtboxTotalTardinessAmount.Text = tardinessAmount
        TxtboxTotalAdjustmentAdd.Text = adjustmentAdd
        TxtboxTotalAdjustmentSub.Text = adjustmentSub
        TxtboxTotalGrossPay.Text = grosspay
        TxtboxTotalSssPs.Text = sssPs
        TxtboxTotalSssEs.Text = sssEs
        TxtboxTotalPhic.Text = phic
        TxtboxTotalHdmf.Text = hdmf
        TxtboxTotalTax.Text = tax
        TxtboxTotalNetPay.Text = netpay

    End Sub

    Private Sub CmboxMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmboxMonth.SelectedIndexChanged
        If CmboxMonth.Text = "1.0" Then
            TxtboxCalendarDays.Text = "22"
            TxtboxTotalNoOfDaysServed.Text = "22"

            TxtboxCalendarDays.Enabled = False
            TxtboxTotalNoOfDaysServed.Enabled = False
        ElseIf CmboxMonth.Text = "0.5" Then
            TxtboxCalendarDays.Text = "22"
            TxtboxTotalNoOfDaysServed.Text = "11"

            TxtboxCalendarDays.Enabled = False
            TxtboxTotalNoOfDaysServed.Enabled = False
        End If
    End Sub

    Private Sub ChckboxHdmf_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxHdmf.CheckedChanged
        If ChckboxHdmf.Checked = True Then
            TxtboxHdmf.Enabled = True
        Else
            TxtboxHdmf.Enabled = False
            TxtboxHdmf.Clear()
        End If
    End Sub

    Private Sub ChckboxTax_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxTax.CheckedChanged
        If ChckboxTax.Checked = True Then
            TxtboxTax.Enabled = True
        Else
            TxtboxTax.Enabled = False
            TxtboxTax.Clear()
        End If
    End Sub

    Private Sub NewPayrollEditComputation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        NewPayrollEdit_Compute()
    End Sub

    Private Sub BtnClearField_Click(sender As Object, e As EventArgs) Handles BtnClearField.Click
        TxtboxRemarks.Clear()
        TxtboxCoverage.Clear()
        CmboxMonth.SelectedIndex = -1
        TxtboxCalendarDays.Clear()
        TxtboxTotalNoOfDaysServed.Clear()
        TxtboxAdjustmentAdd.Clear()
        TxtboxAdjustmentSub.Clear()
        TxtboxAbsences.Clear()
        TxtboxTardiness.Clear()
        TxtboxHdmf.Clear()
        TxtboxTax.Clear()
        ChckboxHdmf.Checked = False
        ChckboxTax.Checked = False
        ChckboxSss.Checked = False
        ChckboxPhic.Checked = False

        TxtboxTotalDailyRate.Clear()
        TxtboxTotalBasic.Clear()
        TxtboxTotalAbsencesAmount.Clear()
        TxtboxTotalTardinessAmount.Clear()
        TxtboxTotalAdjustmentAdd.Clear()
        TxtboxTotalAdjustmentSub.Clear()
        TxtboxTotalGrossPay.Clear()
        TxtboxTotalSssPs.Clear()
        TxtboxTotalSssEs.Clear()
        TxtboxTotalPhic.Clear()
        TxtboxTotalHdmf.Clear()
        TxtboxTotalTax.Clear()
        TxtboxTotalNetPay.Clear()

        TxtboxRemarks.Focus()
    End Sub

    Private Sub BtnCompute_Click(sender As Object, e As EventArgs) Handles BtnCompute.Click
        NewPayrollEdit_Compute()
    End Sub

    Private Sub TxtboxRemarks_Leave(sender As Object, e As EventArgs) Handles TxtboxRemarks.Leave
        TxtboxRemarks.Text = TxtboxRemarks.Text.ToUpper
    End Sub

    Private Sub TxtboxCoverage_Leave(sender As Object, e As EventArgs) Handles TxtboxCoverage.Leave
        TxtboxCoverage.Text = TxtboxCoverage.Text.ToUpper
    End Sub

    Private Sub TxtboxCalendarDays_TextChanged(sender As Object, e As EventArgs) Handles TxtboxCalendarDays.TextChanged
        TxtboxCalendarDays.Text = CheckForNumericCharacters(TxtboxCalendarDays.Text)
    End Sub

    Private Sub TxtboxTotalNoOfDaysServed_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTotalNoOfDaysServed.TextChanged
        TxtboxTotalNoOfDaysServed.Text = CheckForNumericCharacters(TxtboxTotalNoOfDaysServed.Text)
    End Sub

    Private Sub TxtboxAdjustmentAdd_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAdjustmentAdd.TextChanged
        TxtboxAdjustmentAdd.Text = CheckForNumericCharacters(TxtboxAdjustmentAdd.Text)
    End Sub

    Private Sub TxtboxAdjustmentSub_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAdjustmentSub.TextChanged
        TxtboxAdjustmentSub.Text = CheckForNumericCharacters(TxtboxAdjustmentSub.Text)
    End Sub

    Private Sub TxtboxAbsences_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAbsences.TextChanged
        TxtboxAbsences.Text = CheckForNumericCharacters(TxtboxAbsences.Text)
    End Sub

    Private Sub TxtboxTardiness_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTardiness.TextChanged
        TxtboxTardiness.Text = CheckForNumericCharacters(TxtboxTardiness.Text)
    End Sub

    Private Sub TxtboxHdmf_TextChanged(sender As Object, e As EventArgs) Handles TxtboxHdmf.TextChanged
        TxtboxHdmf.Text = validateDoublesAndCurrency(TxtboxHdmf.Text)
    End Sub

    Private Sub TxtboxTax_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTax.TextChanged
        TxtboxTax.Text = validateDoublesAndCurrency(TxtboxTax.Text)
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click

        If TxtboxCalendarDays.Text = "" Then
            MessageBox.Show("Important fields cannot be empty")
            Exit Sub
        End If

        If TxtboxTotalNoOfDaysServed.Text = "" Then
            MessageBox.Show("Important fields cannot be empty")
            Exit Sub
        End If

        Dim coverage As String

        'converting month digits to 3-lettered month
        Dim months As Dictionary(Of String, String) = New Dictionary(Of String, String)
        months.Add("01", "JAN")
        months.Add("02", "FEB")
        months.Add("03", "MAR")
        months.Add("04", "APR")
        months.Add("05", "MAY")
        months.Add("06", "JUN")
        months.Add("07", "JUL")
        months.Add("08", "AUG")
        months.Add("09", "SEP")
        months.Add("10", "OCT")
        months.Add("11", "NOV")
        months.Add("12", "DEC")

        If TxtboxCoverage.Text = "" Then 'if NewPayroll.TxtboxCoverage.Text is empty
            If NewPayroll.TxtboxPeriod.Text = "" Then 'if NewPayroll.TxtboxPeriod.Text is empty
                coverage = months.Item(Format(Date.Today, "MM")) + " " + Date.Today.Year.ToString
            Else
                coverage = NewPayroll.TxtboxPeriod.Text.ToString
            End If
        Else
            coverage = TxtboxCoverage.Text.ToUpper
        End If

        For Each row As DataGridViewRow In NewPayroll.Dtglist.Rows
            If TxtboxAcctNo.Text = row.Cells("ACC NO").Value Then
                row.Cells("MONTH").Value = CmboxMonth.Text
                row.Cells("CALENDAR DAYS").Value = TxtboxCalendarDays.Text
                row.Cells("TOTAL NO OF DAYS SERVED").Value = TxtboxTotalNoOfDaysServed.Text
                row.Cells("DAILY RATE").Value = TxtboxTotalDailyRate.Text
                row.Cells("BASIC").Value = TxtboxTotalBasic.Text
                row.Cells("ABSENCES").Value = TxtboxTotalAbsencesCount.Text
                row.Cells("ABSENCES AMOUNT").Value = TxtboxTotalAbsencesAmount.Text
                row.Cells("TARDINESS").Value = TxtboxTotalTardinessCount.Text
                row.Cells("TARDINESS AMOUNT").Value = TxtboxTotalTardinessAmount.Text
                row.Cells("ADD").Value = TxtboxTotalAdjustmentAdd.Text
                row.Cells("SUB").Value = TxtboxTotalAdjustmentSub.Text
                row.Cells("GROSS PAY").Value = TxtboxTotalGrossPay.Text
                row.Cells("SSS PS").Value = TxtboxTotalSssPs.Text
                row.Cells("SSS ES").Value = TxtboxTotalSssEs.Text
                row.Cells("PHIC").Value = TxtboxTotalPhic.Text
                row.Cells("HDMF").Value = TxtboxTotalHdmf.Text
                row.Cells("TAX").Value = TxtboxTotalTax.Text
                row.Cells("NET PAY").Value = TxtboxTotalNetPay.Text

                NewPayroll.RefreshNewPayrollDtglist()

                row.DefaultCellStyle.BackColor = Color.PaleVioletRed
                row.DefaultCellStyle.ForeColor = Color.White

                MessageBox.Show("UPDATED SUCCESSFULLY")
                NewPayroll.Dtglist.ClearSelection()
                Me.Close()
                Exit For
            End If
        Next

    End Sub
End Class