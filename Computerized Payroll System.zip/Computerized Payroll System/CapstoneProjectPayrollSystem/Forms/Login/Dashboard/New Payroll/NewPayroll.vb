﻿Imports System.ComponentModel

Public Class NewPayroll

    Public tblNewPayroll As New DataTable("tblNewPayroll")

    Public Sub RefreshNewPayrollDtglist()
        Dim totalSalary As Double = 0
        Dim totalBasic As Double = 0
        Dim totalLeaveWithoutPay As Double = 0
        Dim totalGrosspay As Double = 0
        Dim totalSssPs As Double = 0
        Dim totalSssEs As Double = 0
        Dim totalPhic As Double = 0
        Dim totalHdmf As Double = 0
        Dim totalTax As Double = 0
        Dim totalNetpay As Double = 0

        For Each row As DataGridViewRow In Dtglist.Rows
            totalSalary = Math.Round(totalSalary + CDbl(row.Cells("SALARY").Value), 2)
            totalBasic = Math.Round(totalBasic + CDbl(row.Cells("BASIC").Value), 2)
            totalLeaveWithoutPay = Math.Round(totalLeaveWithoutPay + (CDbl(row.Cells("ABSENCES AMOUNT").Value + CDbl(row.Cells("TARDINESS AMOUNT").Value))), 2)
            totalGrosspay = Math.Round(totalGrosspay + CDbl(row.Cells("GROSS PAY").Value), 2)
            totalSssPs = Math.Round(totalSssPs + CDbl(row.Cells("SSS PS").Value), 2)
            totalSssEs = Math.Round(totalSssEs + CDbl(row.Cells("SSS ES").Value), 2)
            totalPhic = Math.Round(totalPhic + CDbl(row.Cells("PHIC").Value), 2)
            totalHdmf = Math.Round(totalHdmf + CDbl(row.Cells("HDMF").Value), 2)
            totalTax = Math.Round(totalTax + CDbl(row.Cells("TAX").Value), 2)
            totalNetpay = Math.Round(totalNetpay + CDbl(row.Cells("NET PAY").Value), 2)
        Next


        TxtboxTotalRecords.Text = Dtglist.DisplayedRowCount(True).ToString
        TxtboxTotalSalary.Text = totalSalary
        TxtboxTotalBasic.Text = totalBasic
        TxtboxTotalLeaveWithoutPay.Text = totalLeaveWithoutPay
        TxtboxTotalGrossPay.Text = totalGrosspay
        TxtboxTotalSssPs.Text = totalSssPs
        TxtboxTotalSssEs.Text = totalSssEs
        TxtboxTotalPhic.Text = totalPhic
        TxtboxTotalHdmf.Text = totalHdmf
        TxtboxTotalTax.Text = totalTax
        TxtboxTotalNetPay.Text = totalNetpay

        Dtglist.ClearSelection()
    End Sub

    Private Sub NewPayroll_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TxtboxPayrollType.Text = GlobalVariables.loginType
        TxtboxCreatedBy.Text = GlobalVariables.loginUsername

        tblNewPayroll.Columns.Add("EMP NO", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("ACC NO", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("FULL NAME", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("POSITION", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("COVERAGE", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("REMARKS", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("SSS NUM", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("HDMF NUM", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("PHIC NUM", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("SALARY", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("MONTH", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("CALENDAR DAYS", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("TOTAL NO OF DAYS SERVED", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("DAILY RATE", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("BASIC", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("ABSENCES", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("ABSENCES AMOUNT", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("TARDINESS", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("TARDINESS AMOUNT", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("ADD", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("SUB", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("GROSS PAY", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("SSS PS", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("SSS ES", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("PHIC", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("HDMF", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("TAX", Type.GetType("System.String"))
        tblNewPayroll.Columns.Add("NET PAY", Type.GetType("System.String"))

        Dtglist.DataSource = tblNewPayroll

        TxtboxHdmf.Enabled = False
        TxtboxTax.Enabled = False

        'prevents the column from being sorted
        For Each column As DataGridViewColumn In Dtglist.Columns
            Dtglist.Columns(column.Name).SortMode = DataGridViewColumnSortMode.NotSortable
        Next

        RefreshNewPayrollDtglist()

    End Sub

    Private Sub BtnSelectEmployees_Click(sender As Object, e As EventArgs) Handles BtnSelectEmployees.Click
        NewPayrollSelectEmployees.Show()
    End Sub

    Private Sub TxtboxPayrollTitle_Leave(sender As Object, e As EventArgs) Handles TxtboxPayrollTitle.Leave
        TxtboxPayrollTitle.Text = TxtboxPayrollTitle.Text.ToUpper
    End Sub

    Private Sub TxtboxPeriod_Leave(sender As Object, e As EventArgs) Handles TxtboxPeriod.Leave
        TxtboxPeriod.Text = TxtboxPeriod.Text.ToUpper
    End Sub

    Private Sub TxtboxRemarks_Leave(sender As Object, e As EventArgs) Handles TxtboxRemarks.Leave
        TxtboxRemarks.Text = TxtboxRemarks.Text.ToUpper
    End Sub

    Private Sub TxtboxCoverage_Leave(sender As Object, e As EventArgs) Handles TxtboxCoverage.Leave
        TxtboxCoverage.Text = TxtboxCoverage.Text.ToUpper
    End Sub

    Private Sub TxtboxCalendarDays_TextChanged(sender As Object, e As EventArgs) Handles TxtboxCalendarDays.TextChanged
        TxtboxCalendarDays.Text = CheckForNumericCharacters(TxtboxCalendarDays.Text)
    End Sub

    Private Sub TxtboxTotalNoOfDaysServed_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTotalNoOfDaysServed.TextChanged
        TxtboxTotalNoOfDaysServed.Text = CheckForNumericCharacters(TxtboxTotalNoOfDaysServed.Text)
    End Sub

    Private Sub TxtboxAdjustmentAdd_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAdjustmentAdd.TextChanged
        TxtboxAdjustmentAdd.Text = validateDoublesAndCurrency(TxtboxAdjustmentAdd.Text)
    End Sub

    Private Sub TxtboxAdjustmentSub_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAdjustmentSub.TextChanged
        TxtboxAdjustmentSub.Text = validateDoublesAndCurrency(TxtboxAdjustmentSub.Text)
    End Sub

    Private Sub TxtboxAbsences_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAbsences.TextChanged
        TxtboxAbsences.Text = CheckForNumericCharacters(TxtboxAbsences.Text)
    End Sub

    Private Sub TxtboxTardiness_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTardiness.TextChanged
        TxtboxTardiness.Text = CheckForNumericCharacters(TxtboxTardiness.Text)
    End Sub

    Private Sub TxtboxHdmf_TextChanged(sender As Object, e As EventArgs) Handles TxtboxHdmf.TextChanged
        TxtboxHdmf.Text = validateDoublesAndCurrency(TxtboxHdmf.Text)
    End Sub

    Private Sub TxtboxTax_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTax.TextChanged
        TxtboxTax.Text = validateDoublesAndCurrency(TxtboxTax.Text)
    End Sub

    Private Sub CmboxMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmboxMonth.SelectedIndexChanged
        If CmboxMonth.SelectedIndex <> -1 Then
            TxtboxCalendarDays.Enabled = False
            TxtboxTotalNoOfDaysServed.Enabled = False
            TxtboxCalendarDays.Clear()
            TxtboxTotalNoOfDaysServed.Clear()
        Else
            TxtboxCalendarDays.Enabled = True
            TxtboxTotalNoOfDaysServed.Enabled = True
        End If
    End Sub

    Private Sub BtnClearField_Click(sender As Object, e As EventArgs) Handles BtnClearField.Click
        TxtboxRemarks.Clear()
        TxtboxCoverage.Clear()
        CmboxMonth.SelectedIndex = -1
        TxtboxCalendarDays.Clear()
        TxtboxTotalNoOfDaysServed.Clear()
        TxtboxAdjustmentAdd.Clear()
        TxtboxAdjustmentSub.Clear()
        TxtboxAbsences.Clear()
        TxtboxTardiness.Clear()
        TxtboxHdmf.Clear()
        TxtboxTax.Clear()
        ChckboxHdmf.Checked = False
        ChckboxTax.Checked = False
        ChckboxSss.Checked = False
        ChckboxPhic.Checked = False
    End Sub

    Private Sub ChckboxHdmf_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxHdmf.CheckedChanged
        If ChckboxHdmf.Checked = True Then
            TxtboxHdmf.Enabled = True
        Else
            TxtboxHdmf.Enabled = False
            TxtboxHdmf.Clear()
        End If
    End Sub

    Private Sub RemoveRowsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveRowsToolStripMenuItem.Click
        'removing selected rows
        For Each row As DataGridViewRow In Dtglist.SelectedRows
            Dtglist.Rows.Remove(row)
        Next
        RefreshNewPayrollDtglist()
    End Sub

    Private Sub ChckboxTax_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxTax.CheckedChanged
        If ChckboxTax.Checked = True Then
            TxtboxTax.Enabled = True
        Else
            TxtboxTax.Enabled = False
            TxtboxTax.Clear()
        End If
    End Sub

    Private Sub BtnCreate_Click(sender As Object, e As EventArgs) Handles BtnCreate.Click
        'checks if important fields are empty
        If TxtboxPayrollTitle.Text = "" Or
            TxtboxPeriod.Text = "" Then

            MessageBox.Show("Fields cannot be empty")
            Exit Sub
        End If

        'prompts a messagebox confirmation
        Dim result As DialogResult = MessageBox.Show("Confirm Payroll?", "Add Payroll", MessageBoxButtons.YesNo)
        If result = DialogResult.No Then
            Exit Sub
        End If

        'sorting the list by FULL NAME ascending
        Dtglist.Sort(Dtglist.Columns("FULL NAME"), ListSortDirection.Ascending)
        Dtglist.ClearSelection()

        'gets the value of 1st row and 2nd column in the dtglist
        Dim headerPayrollNameTo As String = Dtglist.Rows(0).Cells("FULL NAME").Value

        'retrieves the payroll no header counter, 0 indicates what row and "PayrollNo" is the column
        Dim payrollNo As Object = CInt(RetrieveData("SELECT * FROM payrollno", strCon).Rows(0)("PayrollNo")) + 1

        'formating payroll no
        Dim textPayrollNo = Date.Today.Year.ToString + "-" + Date.Today.Month.ToString + "-" + payrollNo.ToString

        'setting header variables
        Dim headerPayrollNo As String = textPayrollNo
        Dim headerType As String = TxtboxPayrollType.Text.ToUpper
        Dim headerPayrollTitle As String = TxtboxPayrollTitle.Text.ToUpper
        Dim headerAmount As String = TxtboxTotalSalary.Text
        Dim headerPeriod As String = TxtboxPeriod.Text.ToUpper
        Dim headerCreatedBy As String = TxtboxCreatedBy.Text

        For Each row As DataGridViewRow In Dtglist.Rows
            Dim acctNo As String = row.Cells("ACC NO").Value
            Dim fullName As String = row.Cells("FULL NAME").Value
            Dim position As String = row.Cells("POSITION").Value
            Dim coverage As String = row.Cells("COVERAGE").Value
            Dim remarks As String = row.Cells("REMARKS").Value
            Dim sssNum As String = row.Cells("SSS NUM").Value
            Dim hdmfNum As String = row.Cells("HDMF NUM").Value
            Dim phicNum As String = row.Cells("PHIC NUM").Value
            Dim salary As String = row.Cells("SALARY").Value
            Dim month As String = row.Cells("MONTH").Value
            Dim calendarDays As String = row.Cells("CALENDAR DAYS").Value
            Dim totalNoOfDaysServed As String = row.Cells("TOTAL NO OF DAYS SERVED").Value
            Dim dailyRate As String = row.Cells("DAILY RATE").Value
            Dim basic As String = row.Cells("BASIC").Value
            Dim absences As String = row.Cells("ABSENCES").Value
            Dim absencesAmount As String = row.Cells("ABSENCES AMOUNT").Value
            Dim tardiness As String = row.Cells("TARDINESS").Value
            Dim tardinessAmount As String = row.Cells("TARDINESS AMOUNT").Value
            Dim adjustmentAdd As String = row.Cells("ADD").Value
            Dim adjustmentSub As String = row.Cells("SUB").Value
            Dim grossPay As String = row.Cells("GROSS PAY").Value
            Dim sssPs As String = row.Cells("SSS PS").Value
            Dim sssEs As String = row.Cells("SSS ES").Value
            Dim phic As String = row.Cells("PHIC").Value
            Dim hdmf As String = row.Cells("HDMF").Value
            Dim tax As String = row.Cells("TAX").Value
            Dim netPay As String = row.Cells("NET PAY").Value

            CreateQuery("INSERT INTO payrollreports (AcctNo,
                                                     FullName,
                                                     Position,
                                                     Coverage,
                                                     Remarks,
                                                     SssNum,
                                                     HdmfNum,
                                                     PhicNum,
                                                     Salary,
                                                     Month,
                                                     CalendarDays,
                                                     TotalNoOfDaysServed,
                                                     DailyRate,
                                                     Basic,
                                                     Absences,
                                                     AbsencesAmount,
                                                     Tardiness,
                                                     TardinessAmount,
                                                     AdjustmentAdd,
                                                     AdjustmentSub,
                                                     GrossPay,
                                                     SssPs,
                                                     SssEs,
                                                     Phic,
                                                     Hdmf,
                                                     Tax,
                                                     NetPay,
                                                     HeaderPayrollNo,
                                                     HeaderType,
                                                     HeaderPayrollTitle,
                                                     HeaderPeriod,
                                                     HeaderCreatedBy)
                                                     VALUES
                                                     ('" & acctNo & "',
                                                     '" & fullName & "',
                                                     '" & position & "',
                                                     '" & coverage & "',
                                                     '" & remarks & "',
                                                     '" & sssNum & "',
                                                     '" & hdmfNum & "',
                                                     '" & phicNum & "',
                                                     '" & salary & "',
                                                     '" & month & "',
                                                     '" & calendarDays & "',
                                                     '" & totalNoOfDaysServed & "',
                                                     '" & dailyRate & "',
                                                     '" & basic & "',
                                                     '" & absences & "',
                                                     '" & absencesAmount & "',
                                                     '" & tardiness & "',
                                                     '" & tardinessAmount & "',
                                                     '" & adjustmentAdd & "',
                                                     '" & adjustmentSub & "',
                                                     '" & grossPay & "',
                                                     '" & sssPs & "',
                                                     '" & sssEs & "',
                                                     '" & phic & "',
                                                     '" & hdmf & "',
                                                     '" & tax & "',
                                                     '" & netPay & "',
                                                     '" & headerPayrollNo & "',
                                                     '" & headerType & "',
                                                     '" & headerPayrollTitle & "',
                                                     '" & headerPeriod & "',
                                                     '" & headerCreatedBy & "')", strCon, False)
        Next

        CreateQuery("INSERT INTO payrollheaders (PayrollNo,
                                                 Type,
                                                 NameTo,
                                                 PayrollTitle,
                                                 Amount,
                                                 Period,
                                                 CreatedBy)
                                                 VALUES (
                                                 '" & textPayrollNo & "',
                                                 '" & headerType & "',
                                                 '" & headerPayrollNameTo & "',
                                                 '" & headerPayrollTitle & "',
                                                 '" & headerAmount & "',
                                                 '" & headerPeriod & "',
                                                 '" & headerCreatedBy & "')", strCon, True)

        UpdateQuery("UPDATE payrollno SET PayrollNo = '" & payrollNo & "'", strCon, False)
        Dashboard.RefreshDashboard()
        Me.Close()
    End Sub

    Private Sub Dtglist_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dtglist.CellDoubleClick
        If Dtglist.RowCount <= 0 Then
            Exit Sub
        End If

        ' To check if the specific form is opened
        If Application.OpenForms().OfType(Of NewPayrollEditComputation).Any Then
            MessageBox.Show("Form currently opened")
            Exit Sub
        End If

        NewPayrollEditComputation.TxtboxFullName.Text = Dtglist.CurrentRow.Cells("FULL NAME").Value
        NewPayrollEditComputation.TxtboxAcctNo.Text = Dtglist.CurrentRow.Cells("ACC NO").Value
        NewPayrollEditComputation.TxtboxPosition.Text = Dtglist.CurrentRow.Cells("POSITION").Value
        NewPayrollEditComputation.TxtboxSalary.Text = Dtglist.CurrentRow.Cells("SALARY").Value

        NewPayrollEditComputation.TxtboxRemarks.Text = Dtglist.CurrentRow.Cells("REMARKS").Value
        NewPayrollEditComputation.TxtboxCoverage.Text = Dtglist.CurrentRow.Cells("COVERAGE").Value

        NewPayrollEditComputation.CmboxMonth.Text = Dtglist.CurrentRow.Cells("MONTH").Value

        If Dtglist.CurrentRow.Cells("MONTH").Value = "0.5" Or Dtglist.CurrentRow.Cells("MONTH").Value = "1.0" Then
            NewPayrollEditComputation.TxtboxCalendarDays.Enabled = False
            NewPayrollEditComputation.TxtboxTotalNoOfDaysServed.Enabled = False
        Else
            NewPayrollEditComputation.TxtboxCalendarDays.Enabled = True
            NewPayrollEditComputation.TxtboxTotalNoOfDaysServed.Enabled = True
        End If

        NewPayrollEditComputation.TxtboxCalendarDays.Text = Dtglist.CurrentRow.Cells("CALENDAR DAYS").Value
        NewPayrollEditComputation.TxtboxTotalNoOfDaysServed.Text = Dtglist.CurrentRow.Cells("TOTAL NO OF DAYS SERVED").Value

        NewPayrollEditComputation.TxtboxAdjustmentAdd.Text = Dtglist.CurrentRow.Cells("ADD").Value
        NewPayrollEditComputation.TxtboxAdjustmentSub.Text = Dtglist.CurrentRow.Cells("SUB").Value

        NewPayrollEditComputation.TxtboxAbsences.Text = Dtglist.CurrentRow.Cells("ABSENCES").Value
        NewPayrollEditComputation.TxtboxTardiness.Text = Dtglist.CurrentRow.Cells("TARDINESS").Value

        If Dtglist.CurrentRow.Cells("PHIC").Value = "0" Then
            NewPayrollEditComputation.ChckboxPhic.Checked = False
        Else
            NewPayrollEditComputation.ChckboxPhic.Checked = True
        End If

        If Dtglist.CurrentRow.Cells("SSS PS").Value = "0" Then
            NewPayrollEditComputation.ChckboxSss.Checked = False
        Else
            NewPayrollEditComputation.ChckboxSss.Checked = True
        End If

        If Dtglist.CurrentRow.Cells("HDMF").Value = "0" Then
            NewPayrollEditComputation.TxtboxHdmf.Text = Dtglist.CurrentRow.Cells("HDMF").Value
            NewPayrollEditComputation.TxtboxHdmf.Enabled = False
            NewPayrollEditComputation.ChckboxHdmf.Checked = False

        Else
            NewPayrollEditComputation.TxtboxHdmf.Text = Dtglist.CurrentRow.Cells("HDMF").Value
            NewPayrollEditComputation.TxtboxHdmf.Enabled = True
            NewPayrollEditComputation.ChckboxHdmf.Checked = True
        End If

        If Dtglist.CurrentRow.Cells("TAX").Value = "0" Then
            NewPayrollEditComputation.TxtboxTax.Text = Dtglist.CurrentRow.Cells("TAX").Value
            NewPayrollEditComputation.TxtboxTax.Enabled = False
            NewPayrollEditComputation.ChckboxTax.Checked = False
        Else
            NewPayrollEditComputation.TxtboxTax.Text = Dtglist.CurrentRow.Cells("TAX").Value
            NewPayrollEditComputation.TxtboxTax.Enabled = True
            NewPayrollEditComputation.ChckboxTax.Checked = True
        End If

        NewPayrollEditComputation.Show()
        NewPayrollEditComputation.NewPayrollEdit_Compute()
    End Sub
End Class