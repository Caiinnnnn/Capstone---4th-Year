﻿Public Class NewPayrollSelectEmployees

    Private Sub HighlightEmployees()
        ' for checking if the employee is added to payroll
        For Each row As DataGridViewRow In Dtglist.Rows
            ' iterating dtglist rows
            For Each row2 As DataGridViewRow In NewPayroll.Dtglist.Rows
                'checking for duplicates in multipleAdd.dtglist.Rows via AcctNo
                If row.Cells("acctNo").Value = row2.Cells("ACC NO").Value Then

                    row.DefaultCellStyle.BackColor = Color.Yellow
                    row.DefaultCellStyle.ForeColor = Color.Black
                End If
            Next
        Next
    End Sub
    Private Sub NewPayrollSelectEmployees_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload("SELECT employeesnums.EmployeeNo,
                       employees.AcctNo,
                       FullName,
                       LastName,
                       Suffix,
                       Appellation,
                       FirstName,
                       MiddleName,
                       BirthDate,
                       Salary,
                       Position,
                       Remarks,
                       SssNum,
                       HdmfNum,
                       PhicNum
                FROM employeesnums INNER JOIN employees
                ON employeesnums.AcctNo = employees.AcctNo
                WHERE
                Status = 'ACTIVE' AND Type = '" & GlobalVariables.loginType & "'",
                Dtglist, strCon)

        HighlightEmployees()
        Dtglist.ClearSelection()
    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each row As DataGridViewRow In Dtglist.Rows

            ' retrieving the value if checkbox is selected
            Dim iSelected As Boolean = Convert.ToBoolean(row.Cells("Sel").Value)

            ' filling empty textboxes and values
            If NewPayroll.CmboxMonth.Text = "1.0" Then
                NewPayroll.TxtboxCalendarDays.Text = "22"
                NewPayroll.TxtboxTotalNoOfDaysServed.Text = "22"
            ElseIf NewPayroll.CmboxMonth.Text = "0.5" Then
                NewPayroll.TxtboxCalendarDays.Text = "22"
                NewPayroll.TxtboxTotalNoOfDaysServed.Text = "11"
            End If

            If NewPayroll.TxtboxCalendarDays.Text = "" Then
                NewPayroll.TxtboxCalendarDays.Text = "22"
            End If

            If NewPayroll.TxtboxTotalNoOfDaysServed.Text = "" Then
                NewPayroll.TxtboxTotalNoOfDaysServed.Text = "22"
            End If

            If NewPayroll.TxtboxAdjustmentAdd.Text = "" Then
                NewPayroll.TxtboxAdjustmentAdd.Text = "0"
            End If

            If NewPayroll.TxtboxAdjustmentSub.Text = "" Then
                NewPayroll.TxtboxAdjustmentSub.Text = "0"
            End If

            If NewPayroll.TxtboxAbsences.Text = "" Then
                NewPayroll.TxtboxAbsences.Text = "0"
            End If

            If NewPayroll.TxtboxTardiness.Text = "" Then
                NewPayroll.TxtboxTardiness.Text = "0"
            End If

            If NewPayroll.ChckboxHdmf.Checked = True And NewPayroll.TxtboxHdmf.Text = "" Then
                NewPayroll.TxtboxHdmf.Text = "0"
            End If

            If NewPayroll.ChckboxTax.Checked = True And NewPayroll.TxtboxTax.Text = "" Then
                NewPayroll.TxtboxTax.Text = "0"
            End If

            ' calendar days cannot be lower than total no of days served
            If CDbl(NewPayroll.TxtboxCalendarDays.Text) < CDbl(NewPayroll.TxtboxTotalNoOfDaysServed.Text) Then
                MessageBox.Show("Invalid digit variables")
                Exit Sub
            End If

            ' setting base variables
            Dim month As Double
            Dim calendarDays As Double
            Dim totalNoOfDaysServed As Double
            Dim monthlyRate As Double

            If NewPayroll.CmboxMonth.SelectedIndex = -1 Then
                month = 0
            Else
                month = CDbl(NewPayroll.CmboxMonth.Text)
            End If

            calendarDays = CDbl(NewPayroll.TxtboxCalendarDays.Text)
            totalNoOfDaysServed = CDbl(NewPayroll.TxtboxTotalNoOfDaysServed.Text)
            monthlyRate = CDbl(row.Cells("Salary").Value)

            ' setting base computations and grosspay
            Dim dailyRate As Double
            Dim basic As Double
            Dim absences As Double
            Dim tardiness As Double
            Dim absencesAmount As Double
            Dim tardinessAmount As Double
            Dim leaveWithoutPay As Double
            Dim adjustmentAdd As Double
            Dim adjustmentSub As Double
            Dim grosspay As Double

            dailyRate = Math.Round(monthlyRate / calendarDays, 2)
            basic = Math.Round((monthlyRate / calendarDays) * totalNoOfDaysServed, 2)
            absences = Math.Round(CDbl(NewPayroll.TxtboxAbsences.Text), 2)
            tardiness = Math.Round(CDbl(NewPayroll.TxtboxTardiness.Text), 2)
            absencesAmount = Math.Round((monthlyRate / 22) * absences, 2)
            tardinessAmount = Math.Round((monthlyRate / 22 / 8 / 60) * tardiness, 2)
            leaveWithoutPay = Math.Round(absencesAmount + tardinessAmount, 2)
            adjustmentAdd = Math.Round(CDbl(NewPayroll.TxtboxAdjustmentAdd.Text), 2)
            adjustmentSub = Math.Round(CDbl(NewPayroll.TxtboxAdjustmentSub.Text), 2)
            grosspay = (basic + adjustmentAdd) - (absencesAmount + tardinessAmount + adjustmentSub)

            ' setting deductions, tax, and net pay

            Dim sssPs As Double
            Dim sssEs As Double
            Dim phic As Double
            Dim hdmf As Double
            Dim tax As Double
            Dim netpay As Double

            ' Sss
            If NewPayroll.ChckboxSss.Checked = True Then
                sssPs = Math.Round(basic * 0.045, 2)
                sssEs = Math.Round(basic * 0.095, 2)

                If NewPayroll.CmboxMonth.SelectedIndex = -1 Then
                    sssPs = Math.Round(basic * 0.045, 2)
                    sssEs = Math.Round(basic * 0.095, 2)
                Else
                    sssPs = Math.Round(monthlyRate * 0.045, 2)
                    sssEs = Math.Round(monthlyRate * 0.095, 2)
                End If

            ElseIf NewPayroll.ChckboxSss.Checked = False Then
                sssPs = 0
                sssEs = 0
            End If

            'phic
            If NewPayroll.ChckboxPhic.Checked = True Then
                phic = Math.Round((monthlyRate / 2) * 0.05, 2)
            ElseIf NewPayroll.ChckboxPhic.Checked = False Then
                phic = 0
            End If

            'hdmf
            If NewPayroll.ChckboxHdmf.Checked = True Then
                hdmf = Math.Round(CDbl(NewPayroll.TxtboxHdmf.Text), 2)
            ElseIf NewPayroll.ChckboxHdmf.Checked = True Then
                hdmf = 0
            End If

            'tax
            If NewPayroll.ChckboxTax.Checked = True Then
                tax = Math.Round(CDbl(NewPayroll.TxtboxTax.Text), 2)
            ElseIf NewPayroll.ChckboxTax.Checked = False Then
                tax = 0
            End If

            netpay = Math.Round((grosspay) - (sssPs + phic + hdmf + tax), 2)

            ' basic information variables
            Dim remarks As String
            Dim coverage As String

            remarks = NewPayroll.TxtboxRemarks.Text.ToUpper

            'converting month digits to 3-lettered month
            Dim months As Dictionary(Of String, String) = New Dictionary(Of String, String)
            months.Add("01", "JAN")
            months.Add("02", "FEB")
            months.Add("03", "MAR")
            months.Add("04", "APR")
            months.Add("05", "MAY")
            months.Add("06", "JUN")
            months.Add("07", "JUL")
            months.Add("08", "AUG")
            months.Add("09", "SEP")
            months.Add("10", "OCT")
            months.Add("11", "NOV")
            months.Add("12", "DEC")

            'for setting the coverage value

            If NewPayroll.TxtboxCoverage.Text = "" Then 'if NewPayroll.TxtboxCoverage.Text is empty
                If NewPayroll.TxtboxPeriod.Text = "" Then 'if NewPayroll.TxtboxPeriod.Text is empty
                    coverage = months.Item(Format(Date.Today, "MM")) + " " + Date.Today.Year.ToString
                Else
                    coverage = NewPayroll.TxtboxPeriod.Text.ToString
                End If
            Else
                coverage = NewPayroll.TxtboxCoverage.Text.ToUpper
            End If


            'checking if the row is selected
            If iSelected Then
                'checking for duplicates in NewPayroll.Dtglist.Rows
                For Each row2 As DataGridViewRow In NewPayroll.Dtglist.Rows
                    'if a duplicate is found
                    If row.Cells("AcctNo").Value = row2.Cells("ACC NO").Value Then
                        MessageBox.Show("User already exists in the table sheet")
                        'unchecking all checkboxes in dtglist
                        For Each row3 As DataGridViewRow In Dtglist.Rows
                            row3.Cells(0) = New DataGridViewCheckBoxCell With {.Value = False}
                        Next
                        Exit Sub
                    End If
                Next
            End If

            If iSelected Then
                NewPayroll.tblNewPayroll.Rows.Add(row.Cells("EmployeeNo").Value,
                                                  row.Cells("AcctNo").Value,
                                                  row.Cells("FullName").Value,
                                                  row.Cells("Position").Value,
                                                  coverage,
                                                  remarks,
                                                  row.Cells("SssNum").Value,
                                                  row.Cells("HdmfNum").Value,
                                                  row.Cells("PhicNum").Value,
                                                  monthlyRate,
                                                  NewPayroll.CmboxMonth.Text,
                                                  calendarDays,
                                                  totalNoOfDaysServed,
                                                  dailyRate,
                                                  basic,
                                                  absences,
                                                  absencesAmount,
                                                  tardiness,
                                                  tardinessAmount,
                                                  adjustmentAdd,
                                                  adjustmentSub,
                                                  grosspay,
                                                  sssPs,
                                                  sssEs,
                                                  phic,
                                                  hdmf,
                                                  tax,
                                                  netpay
                                                  )
                NewPayroll.Dtglist.DataSource = NewPayroll.tblNewPayroll

            End If

        Next

        HighlightEmployees()
        NewPayroll.RefreshNewPayrollDtglist()

        Me.Close()
    End Sub

    Private Sub Dtglist_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dtglist.CellDoubleClick
        Dtglist.CurrentRow.Cells(0) = New DataGridViewCheckBoxCell With {.Value = True}
    End Sub

    Private Sub ChckboxSelectAll_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxSelectAll.CheckedChanged
        If ChckboxSelectAll.Checked = False Then
            For Each row As DataGridViewRow In Dtglist.Rows
                If row.DefaultCellStyle.BackColor <> Color.Yellow Then
                    row.Cells(0) = New DataGridViewCheckBoxCell With {.Value = False}
                End If
            Next
        ElseIf ChckboxSelectAll.Checked = True Then
            For Each row As DataGridViewRow In Dtglist.Rows
                If row.DefaultCellStyle.BackColor <> Color.Yellow Then
                    row.Cells(0) = New DataGridViewCheckBoxCell With {.Value = True}
                End If
            Next
        End If
    End Sub
End Class