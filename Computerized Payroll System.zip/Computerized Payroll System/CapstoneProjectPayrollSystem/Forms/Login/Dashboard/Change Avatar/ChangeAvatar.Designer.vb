﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ChangeAvatar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Pbox_man1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_man2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_man3 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_man4 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_man5 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_man6 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_man7 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Radio_man1 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_man2 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_man3 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_man4 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_man5 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_man6 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_man7 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_woman7 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_woman6 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_woman5 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_woman4 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_woman3 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_woman2 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_woman1 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Pbox_woman7 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_woman6 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_woman5 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_woman4 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_woman3 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_woman2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_woman1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Radio_animal7 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_animal6 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_animal5 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_animal4 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_animal3 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_animal2 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Radio_animal1 = New Guna.UI2.WinForms.Guna2CustomRadioButton()
        Me.Pbox_animal7 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_animal6 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_animal5 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_animal4 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_animal3 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_animal2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Pbox_animal1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.BtnSave = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        CType(Me.Pbox_man1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_man2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_man3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_man4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_man5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_man6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_man7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_woman7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_woman6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_woman5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_woman4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_woman3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_woman2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_woman1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_animal7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_animal6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_animal5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_animal4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_animal3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_animal2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbox_animal1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pbox_man1
        '
        Me.Pbox_man1.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.man_1
        Me.Pbox_man1.Location = New System.Drawing.Point(12, 62)
        Me.Pbox_man1.Name = "Pbox_man1"
        Me.Pbox_man1.ShadowDecoration.Parent = Me.Pbox_man1
        Me.Pbox_man1.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_man1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_man1.TabIndex = 1
        Me.Pbox_man1.TabStop = False
        '
        'Pbox_man2
        '
        Me.Pbox_man2.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.man_2
        Me.Pbox_man2.Location = New System.Drawing.Point(142, 62)
        Me.Pbox_man2.Name = "Pbox_man2"
        Me.Pbox_man2.ShadowDecoration.Parent = Me.Pbox_man2
        Me.Pbox_man2.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_man2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_man2.TabIndex = 2
        Me.Pbox_man2.TabStop = False
        '
        'Pbox_man3
        '
        Me.Pbox_man3.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.man_3
        Me.Pbox_man3.Location = New System.Drawing.Point(274, 62)
        Me.Pbox_man3.Name = "Pbox_man3"
        Me.Pbox_man3.ShadowDecoration.Parent = Me.Pbox_man3
        Me.Pbox_man3.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_man3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_man3.TabIndex = 3
        Me.Pbox_man3.TabStop = False
        '
        'Pbox_man4
        '
        Me.Pbox_man4.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.man_4
        Me.Pbox_man4.Location = New System.Drawing.Point(407, 62)
        Me.Pbox_man4.Name = "Pbox_man4"
        Me.Pbox_man4.ShadowDecoration.Parent = Me.Pbox_man4
        Me.Pbox_man4.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_man4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_man4.TabIndex = 4
        Me.Pbox_man4.TabStop = False
        '
        'Pbox_man5
        '
        Me.Pbox_man5.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.man_5
        Me.Pbox_man5.Location = New System.Drawing.Point(543, 62)
        Me.Pbox_man5.Name = "Pbox_man5"
        Me.Pbox_man5.ShadowDecoration.Parent = Me.Pbox_man5
        Me.Pbox_man5.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_man5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_man5.TabIndex = 5
        Me.Pbox_man5.TabStop = False
        '
        'Pbox_man6
        '
        Me.Pbox_man6.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.man_6
        Me.Pbox_man6.Location = New System.Drawing.Point(677, 62)
        Me.Pbox_man6.Name = "Pbox_man6"
        Me.Pbox_man6.ShadowDecoration.Parent = Me.Pbox_man6
        Me.Pbox_man6.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_man6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_man6.TabIndex = 6
        Me.Pbox_man6.TabStop = False
        '
        'Pbox_man7
        '
        Me.Pbox_man7.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.man_7
        Me.Pbox_man7.Location = New System.Drawing.Point(808, 62)
        Me.Pbox_man7.Name = "Pbox_man7"
        Me.Pbox_man7.ShadowDecoration.Parent = Me.Pbox_man7
        Me.Pbox_man7.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_man7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_man7.TabIndex = 7
        Me.Pbox_man7.TabStop = False
        '
        'Radio_man1
        '
        Me.Radio_man1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man1.CheckedState.BorderThickness = 0
        Me.Radio_man1.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man1.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_man1.CheckedState.Parent = Me.Radio_man1
        Me.Radio_man1.Location = New System.Drawing.Point(53, 169)
        Me.Radio_man1.Name = "Radio_man1"
        Me.Radio_man1.ShadowDecoration.Parent = Me.Radio_man1
        Me.Radio_man1.Size = New System.Drawing.Size(20, 20)
        Me.Radio_man1.TabIndex = 8
        Me.Radio_man1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_man1.UncheckedState.BorderThickness = 2
        Me.Radio_man1.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_man1.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_man1.UncheckedState.Parent = Me.Radio_man1
        '
        'Radio_man2
        '
        Me.Radio_man2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man2.CheckedState.BorderThickness = 0
        Me.Radio_man2.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man2.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_man2.CheckedState.Parent = Me.Radio_man2
        Me.Radio_man2.Location = New System.Drawing.Point(183, 169)
        Me.Radio_man2.Name = "Radio_man2"
        Me.Radio_man2.ShadowDecoration.Parent = Me.Radio_man2
        Me.Radio_man2.Size = New System.Drawing.Size(20, 20)
        Me.Radio_man2.TabIndex = 9
        Me.Radio_man2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_man2.UncheckedState.BorderThickness = 2
        Me.Radio_man2.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_man2.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_man2.UncheckedState.Parent = Me.Radio_man2
        '
        'Radio_man3
        '
        Me.Radio_man3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man3.CheckedState.BorderThickness = 0
        Me.Radio_man3.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man3.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_man3.CheckedState.Parent = Me.Radio_man3
        Me.Radio_man3.Location = New System.Drawing.Point(315, 169)
        Me.Radio_man3.Name = "Radio_man3"
        Me.Radio_man3.ShadowDecoration.Parent = Me.Radio_man3
        Me.Radio_man3.Size = New System.Drawing.Size(20, 20)
        Me.Radio_man3.TabIndex = 10
        Me.Radio_man3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_man3.UncheckedState.BorderThickness = 2
        Me.Radio_man3.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_man3.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_man3.UncheckedState.Parent = Me.Radio_man3
        '
        'Radio_man4
        '
        Me.Radio_man4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man4.CheckedState.BorderThickness = 0
        Me.Radio_man4.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man4.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_man4.CheckedState.Parent = Me.Radio_man4
        Me.Radio_man4.Location = New System.Drawing.Point(450, 169)
        Me.Radio_man4.Name = "Radio_man4"
        Me.Radio_man4.ShadowDecoration.Parent = Me.Radio_man4
        Me.Radio_man4.Size = New System.Drawing.Size(20, 20)
        Me.Radio_man4.TabIndex = 11
        Me.Radio_man4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_man4.UncheckedState.BorderThickness = 2
        Me.Radio_man4.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_man4.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_man4.UncheckedState.Parent = Me.Radio_man4
        '
        'Radio_man5
        '
        Me.Radio_man5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man5.CheckedState.BorderThickness = 0
        Me.Radio_man5.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man5.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_man5.CheckedState.Parent = Me.Radio_man5
        Me.Radio_man5.Location = New System.Drawing.Point(583, 168)
        Me.Radio_man5.Name = "Radio_man5"
        Me.Radio_man5.ShadowDecoration.Parent = Me.Radio_man5
        Me.Radio_man5.Size = New System.Drawing.Size(20, 20)
        Me.Radio_man5.TabIndex = 12
        Me.Radio_man5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_man5.UncheckedState.BorderThickness = 2
        Me.Radio_man5.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_man5.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_man5.UncheckedState.Parent = Me.Radio_man5
        '
        'Radio_man6
        '
        Me.Radio_man6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man6.CheckedState.BorderThickness = 0
        Me.Radio_man6.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man6.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_man6.CheckedState.Parent = Me.Radio_man6
        Me.Radio_man6.Location = New System.Drawing.Point(718, 169)
        Me.Radio_man6.Name = "Radio_man6"
        Me.Radio_man6.ShadowDecoration.Parent = Me.Radio_man6
        Me.Radio_man6.Size = New System.Drawing.Size(20, 20)
        Me.Radio_man6.TabIndex = 13
        Me.Radio_man6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_man6.UncheckedState.BorderThickness = 2
        Me.Radio_man6.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_man6.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_man6.UncheckedState.Parent = Me.Radio_man6
        '
        'Radio_man7
        '
        Me.Radio_man7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man7.CheckedState.BorderThickness = 0
        Me.Radio_man7.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_man7.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_man7.CheckedState.Parent = Me.Radio_man7
        Me.Radio_man7.Location = New System.Drawing.Point(851, 168)
        Me.Radio_man7.Name = "Radio_man7"
        Me.Radio_man7.ShadowDecoration.Parent = Me.Radio_man7
        Me.Radio_man7.Size = New System.Drawing.Size(20, 20)
        Me.Radio_man7.TabIndex = 14
        Me.Radio_man7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_man7.UncheckedState.BorderThickness = 2
        Me.Radio_man7.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_man7.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_man7.UncheckedState.Parent = Me.Radio_man7
        '
        'Radio_woman7
        '
        Me.Radio_woman7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman7.CheckedState.BorderThickness = 0
        Me.Radio_woman7.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman7.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_woman7.CheckedState.Parent = Me.Radio_woman7
        Me.Radio_woman7.Location = New System.Drawing.Point(851, 312)
        Me.Radio_woman7.Name = "Radio_woman7"
        Me.Radio_woman7.ShadowDecoration.Parent = Me.Radio_woman7
        Me.Radio_woman7.Size = New System.Drawing.Size(20, 20)
        Me.Radio_woman7.TabIndex = 28
        Me.Radio_woman7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_woman7.UncheckedState.BorderThickness = 2
        Me.Radio_woman7.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_woman7.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_woman7.UncheckedState.Parent = Me.Radio_woman7
        '
        'Radio_woman6
        '
        Me.Radio_woman6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman6.CheckedState.BorderThickness = 0
        Me.Radio_woman6.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman6.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_woman6.CheckedState.Parent = Me.Radio_woman6
        Me.Radio_woman6.Location = New System.Drawing.Point(718, 313)
        Me.Radio_woman6.Name = "Radio_woman6"
        Me.Radio_woman6.ShadowDecoration.Parent = Me.Radio_woman6
        Me.Radio_woman6.Size = New System.Drawing.Size(20, 20)
        Me.Radio_woman6.TabIndex = 27
        Me.Radio_woman6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_woman6.UncheckedState.BorderThickness = 2
        Me.Radio_woman6.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_woman6.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_woman6.UncheckedState.Parent = Me.Radio_woman6
        '
        'Radio_woman5
        '
        Me.Radio_woman5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman5.CheckedState.BorderThickness = 0
        Me.Radio_woman5.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman5.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_woman5.CheckedState.Parent = Me.Radio_woman5
        Me.Radio_woman5.Location = New System.Drawing.Point(583, 312)
        Me.Radio_woman5.Name = "Radio_woman5"
        Me.Radio_woman5.ShadowDecoration.Parent = Me.Radio_woman5
        Me.Radio_woman5.Size = New System.Drawing.Size(20, 20)
        Me.Radio_woman5.TabIndex = 26
        Me.Radio_woman5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_woman5.UncheckedState.BorderThickness = 2
        Me.Radio_woman5.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_woman5.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_woman5.UncheckedState.Parent = Me.Radio_woman5
        '
        'Radio_woman4
        '
        Me.Radio_woman4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman4.CheckedState.BorderThickness = 0
        Me.Radio_woman4.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman4.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_woman4.CheckedState.Parent = Me.Radio_woman4
        Me.Radio_woman4.Location = New System.Drawing.Point(450, 313)
        Me.Radio_woman4.Name = "Radio_woman4"
        Me.Radio_woman4.ShadowDecoration.Parent = Me.Radio_woman4
        Me.Radio_woman4.Size = New System.Drawing.Size(20, 20)
        Me.Radio_woman4.TabIndex = 25
        Me.Radio_woman4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_woman4.UncheckedState.BorderThickness = 2
        Me.Radio_woman4.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_woman4.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_woman4.UncheckedState.Parent = Me.Radio_woman4
        '
        'Radio_woman3
        '
        Me.Radio_woman3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman3.CheckedState.BorderThickness = 0
        Me.Radio_woman3.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman3.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_woman3.CheckedState.Parent = Me.Radio_woman3
        Me.Radio_woman3.Location = New System.Drawing.Point(315, 313)
        Me.Radio_woman3.Name = "Radio_woman3"
        Me.Radio_woman3.ShadowDecoration.Parent = Me.Radio_woman3
        Me.Radio_woman3.Size = New System.Drawing.Size(20, 20)
        Me.Radio_woman3.TabIndex = 24
        Me.Radio_woman3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_woman3.UncheckedState.BorderThickness = 2
        Me.Radio_woman3.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_woman3.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_woman3.UncheckedState.Parent = Me.Radio_woman3
        '
        'Radio_woman2
        '
        Me.Radio_woman2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman2.CheckedState.BorderThickness = 0
        Me.Radio_woman2.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman2.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_woman2.CheckedState.Parent = Me.Radio_woman2
        Me.Radio_woman2.Location = New System.Drawing.Point(183, 313)
        Me.Radio_woman2.Name = "Radio_woman2"
        Me.Radio_woman2.ShadowDecoration.Parent = Me.Radio_woman2
        Me.Radio_woman2.Size = New System.Drawing.Size(20, 20)
        Me.Radio_woman2.TabIndex = 23
        Me.Radio_woman2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_woman2.UncheckedState.BorderThickness = 2
        Me.Radio_woman2.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_woman2.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_woman2.UncheckedState.Parent = Me.Radio_woman2
        '
        'Radio_woman1
        '
        Me.Radio_woman1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman1.CheckedState.BorderThickness = 0
        Me.Radio_woman1.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_woman1.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_woman1.CheckedState.Parent = Me.Radio_woman1
        Me.Radio_woman1.Location = New System.Drawing.Point(53, 313)
        Me.Radio_woman1.Name = "Radio_woman1"
        Me.Radio_woman1.ShadowDecoration.Parent = Me.Radio_woman1
        Me.Radio_woman1.Size = New System.Drawing.Size(20, 20)
        Me.Radio_woman1.TabIndex = 22
        Me.Radio_woman1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_woman1.UncheckedState.BorderThickness = 2
        Me.Radio_woman1.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_woman1.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_woman1.UncheckedState.Parent = Me.Radio_woman1
        '
        'Pbox_woman7
        '
        Me.Pbox_woman7.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.woman_7
        Me.Pbox_woman7.Location = New System.Drawing.Point(808, 206)
        Me.Pbox_woman7.Name = "Pbox_woman7"
        Me.Pbox_woman7.ShadowDecoration.Parent = Me.Pbox_woman7
        Me.Pbox_woman7.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_woman7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_woman7.TabIndex = 21
        Me.Pbox_woman7.TabStop = False
        '
        'Pbox_woman6
        '
        Me.Pbox_woman6.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.woman_6
        Me.Pbox_woman6.Location = New System.Drawing.Point(677, 206)
        Me.Pbox_woman6.Name = "Pbox_woman6"
        Me.Pbox_woman6.ShadowDecoration.Parent = Me.Pbox_woman6
        Me.Pbox_woman6.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_woman6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_woman6.TabIndex = 20
        Me.Pbox_woman6.TabStop = False
        '
        'Pbox_woman5
        '
        Me.Pbox_woman5.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.woman_5
        Me.Pbox_woman5.Location = New System.Drawing.Point(543, 206)
        Me.Pbox_woman5.Name = "Pbox_woman5"
        Me.Pbox_woman5.ShadowDecoration.Parent = Me.Pbox_woman5
        Me.Pbox_woman5.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_woman5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_woman5.TabIndex = 19
        Me.Pbox_woman5.TabStop = False
        '
        'Pbox_woman4
        '
        Me.Pbox_woman4.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.woman_4
        Me.Pbox_woman4.Location = New System.Drawing.Point(407, 206)
        Me.Pbox_woman4.Name = "Pbox_woman4"
        Me.Pbox_woman4.ShadowDecoration.Parent = Me.Pbox_woman4
        Me.Pbox_woman4.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_woman4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_woman4.TabIndex = 18
        Me.Pbox_woman4.TabStop = False
        '
        'Pbox_woman3
        '
        Me.Pbox_woman3.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.woman_3
        Me.Pbox_woman3.Location = New System.Drawing.Point(274, 206)
        Me.Pbox_woman3.Name = "Pbox_woman3"
        Me.Pbox_woman3.ShadowDecoration.Parent = Me.Pbox_woman3
        Me.Pbox_woman3.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_woman3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_woman3.TabIndex = 17
        Me.Pbox_woman3.TabStop = False
        '
        'Pbox_woman2
        '
        Me.Pbox_woman2.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.woman_2
        Me.Pbox_woman2.Location = New System.Drawing.Point(142, 206)
        Me.Pbox_woman2.Name = "Pbox_woman2"
        Me.Pbox_woman2.ShadowDecoration.Parent = Me.Pbox_woman2
        Me.Pbox_woman2.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_woman2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_woman2.TabIndex = 16
        Me.Pbox_woman2.TabStop = False
        '
        'Pbox_woman1
        '
        Me.Pbox_woman1.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.woman_1
        Me.Pbox_woman1.Location = New System.Drawing.Point(12, 206)
        Me.Pbox_woman1.Name = "Pbox_woman1"
        Me.Pbox_woman1.ShadowDecoration.Parent = Me.Pbox_woman1
        Me.Pbox_woman1.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_woman1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_woman1.TabIndex = 15
        Me.Pbox_woman1.TabStop = False
        '
        'Radio_animal7
        '
        Me.Radio_animal7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal7.CheckedState.BorderThickness = 0
        Me.Radio_animal7.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal7.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_animal7.CheckedState.Parent = Me.Radio_animal7
        Me.Radio_animal7.Location = New System.Drawing.Point(851, 459)
        Me.Radio_animal7.Name = "Radio_animal7"
        Me.Radio_animal7.ShadowDecoration.Parent = Me.Radio_animal7
        Me.Radio_animal7.Size = New System.Drawing.Size(20, 20)
        Me.Radio_animal7.TabIndex = 42
        Me.Radio_animal7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_animal7.UncheckedState.BorderThickness = 2
        Me.Radio_animal7.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_animal7.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_animal7.UncheckedState.Parent = Me.Radio_animal7
        '
        'Radio_animal6
        '
        Me.Radio_animal6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal6.CheckedState.BorderThickness = 0
        Me.Radio_animal6.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal6.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_animal6.CheckedState.Parent = Me.Radio_animal6
        Me.Radio_animal6.Location = New System.Drawing.Point(718, 460)
        Me.Radio_animal6.Name = "Radio_animal6"
        Me.Radio_animal6.ShadowDecoration.Parent = Me.Radio_animal6
        Me.Radio_animal6.Size = New System.Drawing.Size(20, 20)
        Me.Radio_animal6.TabIndex = 41
        Me.Radio_animal6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_animal6.UncheckedState.BorderThickness = 2
        Me.Radio_animal6.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_animal6.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_animal6.UncheckedState.Parent = Me.Radio_animal6
        '
        'Radio_animal5
        '
        Me.Radio_animal5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal5.CheckedState.BorderThickness = 0
        Me.Radio_animal5.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal5.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_animal5.CheckedState.Parent = Me.Radio_animal5
        Me.Radio_animal5.Location = New System.Drawing.Point(583, 459)
        Me.Radio_animal5.Name = "Radio_animal5"
        Me.Radio_animal5.ShadowDecoration.Parent = Me.Radio_animal5
        Me.Radio_animal5.Size = New System.Drawing.Size(20, 20)
        Me.Radio_animal5.TabIndex = 40
        Me.Radio_animal5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_animal5.UncheckedState.BorderThickness = 2
        Me.Radio_animal5.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_animal5.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_animal5.UncheckedState.Parent = Me.Radio_animal5
        '
        'Radio_animal4
        '
        Me.Radio_animal4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal4.CheckedState.BorderThickness = 0
        Me.Radio_animal4.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal4.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_animal4.CheckedState.Parent = Me.Radio_animal4
        Me.Radio_animal4.Location = New System.Drawing.Point(450, 460)
        Me.Radio_animal4.Name = "Radio_animal4"
        Me.Radio_animal4.ShadowDecoration.Parent = Me.Radio_animal4
        Me.Radio_animal4.Size = New System.Drawing.Size(20, 20)
        Me.Radio_animal4.TabIndex = 39
        Me.Radio_animal4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_animal4.UncheckedState.BorderThickness = 2
        Me.Radio_animal4.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_animal4.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_animal4.UncheckedState.Parent = Me.Radio_animal4
        '
        'Radio_animal3
        '
        Me.Radio_animal3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal3.CheckedState.BorderThickness = 0
        Me.Radio_animal3.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal3.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_animal3.CheckedState.Parent = Me.Radio_animal3
        Me.Radio_animal3.Location = New System.Drawing.Point(315, 460)
        Me.Radio_animal3.Name = "Radio_animal3"
        Me.Radio_animal3.ShadowDecoration.Parent = Me.Radio_animal3
        Me.Radio_animal3.Size = New System.Drawing.Size(20, 20)
        Me.Radio_animal3.TabIndex = 38
        Me.Radio_animal3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_animal3.UncheckedState.BorderThickness = 2
        Me.Radio_animal3.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_animal3.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_animal3.UncheckedState.Parent = Me.Radio_animal3
        '
        'Radio_animal2
        '
        Me.Radio_animal2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal2.CheckedState.BorderThickness = 0
        Me.Radio_animal2.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal2.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_animal2.CheckedState.Parent = Me.Radio_animal2
        Me.Radio_animal2.Location = New System.Drawing.Point(183, 460)
        Me.Radio_animal2.Name = "Radio_animal2"
        Me.Radio_animal2.ShadowDecoration.Parent = Me.Radio_animal2
        Me.Radio_animal2.Size = New System.Drawing.Size(20, 20)
        Me.Radio_animal2.TabIndex = 37
        Me.Radio_animal2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_animal2.UncheckedState.BorderThickness = 2
        Me.Radio_animal2.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_animal2.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_animal2.UncheckedState.Parent = Me.Radio_animal2
        '
        'Radio_animal1
        '
        Me.Radio_animal1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal1.CheckedState.BorderThickness = 0
        Me.Radio_animal1.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Radio_animal1.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Radio_animal1.CheckedState.Parent = Me.Radio_animal1
        Me.Radio_animal1.Location = New System.Drawing.Point(53, 460)
        Me.Radio_animal1.Name = "Radio_animal1"
        Me.Radio_animal1.ShadowDecoration.Parent = Me.Radio_animal1
        Me.Radio_animal1.Size = New System.Drawing.Size(20, 20)
        Me.Radio_animal1.TabIndex = 36
        Me.Radio_animal1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Radio_animal1.UncheckedState.BorderThickness = 2
        Me.Radio_animal1.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.Radio_animal1.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        Me.Radio_animal1.UncheckedState.Parent = Me.Radio_animal1
        '
        'Pbox_animal7
        '
        Me.Pbox_animal7.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.animal_7
        Me.Pbox_animal7.Location = New System.Drawing.Point(808, 353)
        Me.Pbox_animal7.Name = "Pbox_animal7"
        Me.Pbox_animal7.ShadowDecoration.Parent = Me.Pbox_animal7
        Me.Pbox_animal7.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_animal7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_animal7.TabIndex = 35
        Me.Pbox_animal7.TabStop = False
        '
        'Pbox_animal6
        '
        Me.Pbox_animal6.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.animal_6
        Me.Pbox_animal6.Location = New System.Drawing.Point(677, 353)
        Me.Pbox_animal6.Name = "Pbox_animal6"
        Me.Pbox_animal6.ShadowDecoration.Parent = Me.Pbox_animal6
        Me.Pbox_animal6.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_animal6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_animal6.TabIndex = 34
        Me.Pbox_animal6.TabStop = False
        '
        'Pbox_animal5
        '
        Me.Pbox_animal5.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.animal_5
        Me.Pbox_animal5.Location = New System.Drawing.Point(543, 353)
        Me.Pbox_animal5.Name = "Pbox_animal5"
        Me.Pbox_animal5.ShadowDecoration.Parent = Me.Pbox_animal5
        Me.Pbox_animal5.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_animal5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_animal5.TabIndex = 33
        Me.Pbox_animal5.TabStop = False
        '
        'Pbox_animal4
        '
        Me.Pbox_animal4.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.animal_4
        Me.Pbox_animal4.Location = New System.Drawing.Point(407, 353)
        Me.Pbox_animal4.Name = "Pbox_animal4"
        Me.Pbox_animal4.ShadowDecoration.Parent = Me.Pbox_animal4
        Me.Pbox_animal4.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_animal4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_animal4.TabIndex = 32
        Me.Pbox_animal4.TabStop = False
        '
        'Pbox_animal3
        '
        Me.Pbox_animal3.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.animal_3
        Me.Pbox_animal3.Location = New System.Drawing.Point(274, 353)
        Me.Pbox_animal3.Name = "Pbox_animal3"
        Me.Pbox_animal3.ShadowDecoration.Parent = Me.Pbox_animal3
        Me.Pbox_animal3.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_animal3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_animal3.TabIndex = 31
        Me.Pbox_animal3.TabStop = False
        '
        'Pbox_animal2
        '
        Me.Pbox_animal2.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.animal_2
        Me.Pbox_animal2.Location = New System.Drawing.Point(142, 353)
        Me.Pbox_animal2.Name = "Pbox_animal2"
        Me.Pbox_animal2.ShadowDecoration.Parent = Me.Pbox_animal2
        Me.Pbox_animal2.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_animal2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_animal2.TabIndex = 30
        Me.Pbox_animal2.TabStop = False
        '
        'Pbox_animal1
        '
        Me.Pbox_animal1.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.animal_1
        Me.Pbox_animal1.Location = New System.Drawing.Point(12, 353)
        Me.Pbox_animal1.Name = "Pbox_animal1"
        Me.Pbox_animal1.ShadowDecoration.Parent = Me.Pbox_animal1
        Me.Pbox_animal1.Size = New System.Drawing.Size(100, 100)
        Me.Pbox_animal1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbox_animal1.TabIndex = 29
        Me.Pbox_animal1.TabStop = False
        '
        'BtnSave
        '
        Me.BtnSave.CheckedState.Parent = Me.BtnSave
        Me.BtnSave.CustomImages.Parent = Me.BtnSave
        Me.BtnSave.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSave.ForeColor = System.Drawing.Color.White
        Me.BtnSave.HoverState.Parent = Me.BtnSave
        Me.BtnSave.Location = New System.Drawing.Point(368, 529)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.ShadowDecoration.Parent = Me.BtnSave
        Me.BtnSave.Size = New System.Drawing.Size(180, 45)
        Me.BtnSave.TabIndex = 43
        Me.BtnSave.Text = "SAVE"
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(920, 56)
        Me.Guna2Panel1.TabIndex = 44
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(12, 15)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(133, 23)
        Me.Guna2HtmlLabel1.TabIndex = 0
        Me.Guna2HtmlLabel1.Text = "CHANGE AVATAR"
        '
        'ChangeAvatar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Lavender
        Me.ClientSize = New System.Drawing.Size(920, 601)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.Radio_animal7)
        Me.Controls.Add(Me.Radio_animal6)
        Me.Controls.Add(Me.Radio_animal5)
        Me.Controls.Add(Me.Radio_animal4)
        Me.Controls.Add(Me.Radio_animal3)
        Me.Controls.Add(Me.Radio_animal2)
        Me.Controls.Add(Me.Radio_animal1)
        Me.Controls.Add(Me.Pbox_animal7)
        Me.Controls.Add(Me.Pbox_animal6)
        Me.Controls.Add(Me.Pbox_animal5)
        Me.Controls.Add(Me.Pbox_animal4)
        Me.Controls.Add(Me.Pbox_animal3)
        Me.Controls.Add(Me.Pbox_animal2)
        Me.Controls.Add(Me.Pbox_animal1)
        Me.Controls.Add(Me.Radio_woman7)
        Me.Controls.Add(Me.Radio_woman6)
        Me.Controls.Add(Me.Radio_woman5)
        Me.Controls.Add(Me.Radio_woman4)
        Me.Controls.Add(Me.Radio_woman3)
        Me.Controls.Add(Me.Radio_woman2)
        Me.Controls.Add(Me.Radio_woman1)
        Me.Controls.Add(Me.Pbox_woman7)
        Me.Controls.Add(Me.Pbox_woman6)
        Me.Controls.Add(Me.Pbox_woman5)
        Me.Controls.Add(Me.Pbox_woman4)
        Me.Controls.Add(Me.Pbox_woman3)
        Me.Controls.Add(Me.Pbox_woman2)
        Me.Controls.Add(Me.Pbox_woman1)
        Me.Controls.Add(Me.Radio_man7)
        Me.Controls.Add(Me.Radio_man6)
        Me.Controls.Add(Me.Radio_man5)
        Me.Controls.Add(Me.Radio_man4)
        Me.Controls.Add(Me.Radio_man3)
        Me.Controls.Add(Me.Radio_man2)
        Me.Controls.Add(Me.Radio_man1)
        Me.Controls.Add(Me.Pbox_man7)
        Me.Controls.Add(Me.Pbox_man6)
        Me.Controls.Add(Me.Pbox_man5)
        Me.Controls.Add(Me.Pbox_man4)
        Me.Controls.Add(Me.Pbox_man3)
        Me.Controls.Add(Me.Pbox_man2)
        Me.Controls.Add(Me.Pbox_man1)
        Me.Name = "ChangeAvatar"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ChangeAvatar"
        CType(Me.Pbox_man1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_man2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_man3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_man4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_man5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_man6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_man7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_woman7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_woman6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_woman5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_woman4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_woman3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_woman2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_woman1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_animal7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_animal6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_animal5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_animal4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_animal3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_animal2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbox_animal1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pbox_man1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_man2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_man3 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_man4 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_man5 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_man6 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_man7 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Radio_man1 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_man2 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_man3 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_man4 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_man5 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_man6 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_man7 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_woman7 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_woman6 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_woman5 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_woman4 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_woman3 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_woman2 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_woman1 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Pbox_woman7 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_woman6 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_woman5 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_woman4 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_woman3 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_woman2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_woman1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Radio_animal7 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_animal6 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_animal5 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_animal4 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_animal3 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_animal2 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Radio_animal1 As Guna.UI2.WinForms.Guna2CustomRadioButton
    Friend WithEvents Pbox_animal7 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_animal6 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_animal5 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_animal4 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_animal3 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_animal2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Pbox_animal1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents BtnSave As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
End Class
