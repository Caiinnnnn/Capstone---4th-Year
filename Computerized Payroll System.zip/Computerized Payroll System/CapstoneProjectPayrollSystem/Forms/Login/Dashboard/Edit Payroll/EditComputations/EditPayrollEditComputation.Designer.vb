﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditPayrollEditComputation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtboxTotalAbsencesCount = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxTotalTax = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel23 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalHdmf = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel22 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalPhic = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2VSeparator1 = New Guna.UI2.WinForms.Guna2VSeparator()
        Me.TxtboxTax = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxHdmf = New Guna.UI2.WinForms.Guna2TextBox()
        Me.ChckboxPhic = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.ChckboxSss = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.ChckboxTax = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.ChckboxHdmf = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.TxtboxTardiness = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxAbsences = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel26 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel25 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalNetPay = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel24 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel21 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalSssEs = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel20 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.BtnSave = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnCompute = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnClearField = New Guna.UI2.WinForms.Guna2Button()
        Me.TxtboxTotalSssPs = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel19 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalAdjustmentSub = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel18 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalAdjustmentAdd = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel17 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalGrossPay = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel16 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalTardinessAmount = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel15 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalAbsencesAmount = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel14 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalBasic = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel13 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalDailyRate = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel12 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxSalary = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxPosition = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxAcctNo = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxFullName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GroupBox2 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxRemarks = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox3 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxCoverage = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox4 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxTotalNoOfDaysServed = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel8 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxCalendarDays = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.CmboxMonth = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalTardinessCount = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox5 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2HtmlLabel10 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxAdjustmentSub = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel9 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxAdjustmentAdd = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox6 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2HtmlLabel11 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Panel2.SuspendLayout()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.Guna2GroupBox2.SuspendLayout()
        Me.Guna2GroupBox3.SuspendLayout()
        Me.Guna2GroupBox4.SuspendLayout()
        Me.Guna2GroupBox5.SuspendLayout()
        Me.Guna2GroupBox6.SuspendLayout()
        Me.Guna2Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TxtboxTotalAbsencesCount
        '
        Me.TxtboxTotalAbsencesCount.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalAbsencesCount.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalAbsencesCount.DefaultText = ""
        Me.TxtboxTotalAbsencesCount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalAbsencesCount.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalAbsencesCount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalAbsencesCount.DisabledState.Parent = Me.TxtboxTotalAbsencesCount
        Me.TxtboxTotalAbsencesCount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalAbsencesCount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalAbsencesCount.FocusedState.Parent = Me.TxtboxTotalAbsencesCount
        Me.TxtboxTotalAbsencesCount.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalAbsencesCount.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalAbsencesCount.HoverState.Parent = Me.TxtboxTotalAbsencesCount
        Me.TxtboxTotalAbsencesCount.Location = New System.Drawing.Point(81, 60)
        Me.TxtboxTotalAbsencesCount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalAbsencesCount.Name = "TxtboxTotalAbsencesCount"
        Me.TxtboxTotalAbsencesCount.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalAbsencesCount.PlaceholderText = ""
        Me.TxtboxTotalAbsencesCount.ReadOnly = True
        Me.TxtboxTotalAbsencesCount.SelectedText = ""
        Me.TxtboxTotalAbsencesCount.ShadowDecoration.Parent = Me.TxtboxTotalAbsencesCount
        Me.TxtboxTotalAbsencesCount.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalAbsencesCount.TabIndex = 35
        Me.TxtboxTotalAbsencesCount.TabStop = False
        '
        'TxtboxTotalTax
        '
        Me.TxtboxTotalTax.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalTax.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalTax.DefaultText = ""
        Me.TxtboxTotalTax.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalTax.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalTax.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalTax.DisabledState.Parent = Me.TxtboxTotalTax
        Me.TxtboxTotalTax.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalTax.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalTax.FocusedState.Parent = Me.TxtboxTotalTax
        Me.TxtboxTotalTax.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalTax.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalTax.HoverState.Parent = Me.TxtboxTotalTax
        Me.TxtboxTotalTax.Location = New System.Drawing.Point(622, 112)
        Me.TxtboxTotalTax.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalTax.Name = "TxtboxTotalTax"
        Me.TxtboxTotalTax.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalTax.PlaceholderText = ""
        Me.TxtboxTotalTax.ReadOnly = True
        Me.TxtboxTotalTax.SelectedText = ""
        Me.TxtboxTotalTax.ShadowDecoration.Parent = Me.TxtboxTotalTax
        Me.TxtboxTotalTax.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalTax.TabIndex = 31
        Me.TxtboxTotalTax.TabStop = False
        '
        'Guna2HtmlLabel23
        '
        Me.Guna2HtmlLabel23.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel23.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel23.Location = New System.Drawing.Point(591, 117)
        Me.Guna2HtmlLabel23.Name = "Guna2HtmlLabel23"
        Me.Guna2HtmlLabel23.Size = New System.Drawing.Size(24, 15)
        Me.Guna2HtmlLabel23.TabIndex = 30
        Me.Guna2HtmlLabel23.Text = "TAX"
        '
        'TxtboxTotalHdmf
        '
        Me.TxtboxTotalHdmf.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalHdmf.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalHdmf.DefaultText = ""
        Me.TxtboxTotalHdmf.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalHdmf.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalHdmf.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalHdmf.DisabledState.Parent = Me.TxtboxTotalHdmf
        Me.TxtboxTotalHdmf.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalHdmf.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalHdmf.FocusedState.Parent = Me.TxtboxTotalHdmf
        Me.TxtboxTotalHdmf.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalHdmf.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalHdmf.HoverState.Parent = Me.TxtboxTotalHdmf
        Me.TxtboxTotalHdmf.Location = New System.Drawing.Point(622, 86)
        Me.TxtboxTotalHdmf.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalHdmf.Name = "TxtboxTotalHdmf"
        Me.TxtboxTotalHdmf.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalHdmf.PlaceholderText = ""
        Me.TxtboxTotalHdmf.ReadOnly = True
        Me.TxtboxTotalHdmf.SelectedText = ""
        Me.TxtboxTotalHdmf.ShadowDecoration.Parent = Me.TxtboxTotalHdmf
        Me.TxtboxTotalHdmf.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalHdmf.TabIndex = 29
        Me.TxtboxTotalHdmf.TabStop = False
        '
        'Guna2HtmlLabel22
        '
        Me.Guna2HtmlLabel22.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel22.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel22.Location = New System.Drawing.Point(581, 91)
        Me.Guna2HtmlLabel22.Name = "Guna2HtmlLabel22"
        Me.Guna2HtmlLabel22.Size = New System.Drawing.Size(34, 15)
        Me.Guna2HtmlLabel22.TabIndex = 28
        Me.Guna2HtmlLabel22.Text = "HDMF"
        '
        'TxtboxTotalPhic
        '
        Me.TxtboxTotalPhic.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalPhic.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalPhic.DefaultText = ""
        Me.TxtboxTotalPhic.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalPhic.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalPhic.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalPhic.DisabledState.Parent = Me.TxtboxTotalPhic
        Me.TxtboxTotalPhic.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalPhic.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalPhic.FocusedState.Parent = Me.TxtboxTotalPhic
        Me.TxtboxTotalPhic.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalPhic.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalPhic.HoverState.Parent = Me.TxtboxTotalPhic
        Me.TxtboxTotalPhic.Location = New System.Drawing.Point(622, 60)
        Me.TxtboxTotalPhic.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalPhic.Name = "TxtboxTotalPhic"
        Me.TxtboxTotalPhic.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalPhic.PlaceholderText = ""
        Me.TxtboxTotalPhic.ReadOnly = True
        Me.TxtboxTotalPhic.SelectedText = ""
        Me.TxtboxTotalPhic.ShadowDecoration.Parent = Me.TxtboxTotalPhic
        Me.TxtboxTotalPhic.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalPhic.TabIndex = 27
        Me.TxtboxTotalPhic.TabStop = False
        '
        'Guna2VSeparator1
        '
        Me.Guna2VSeparator1.BackColor = System.Drawing.Color.White
        Me.Guna2VSeparator1.Location = New System.Drawing.Point(145, 23)
        Me.Guna2VSeparator1.Name = "Guna2VSeparator1"
        Me.Guna2VSeparator1.Size = New System.Drawing.Size(10, 128)
        Me.Guna2VSeparator1.TabIndex = 23
        '
        'TxtboxTax
        '
        Me.TxtboxTax.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTax.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTax.DefaultText = ""
        Me.TxtboxTax.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTax.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTax.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTax.DisabledState.Parent = Me.TxtboxTax
        Me.TxtboxTax.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTax.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTax.FocusedState.Parent = Me.TxtboxTax
        Me.TxtboxTax.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTax.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTax.HoverState.Parent = Me.TxtboxTax
        Me.TxtboxTax.Location = New System.Drawing.Point(166, 55)
        Me.TxtboxTax.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.TxtboxTax.Name = "TxtboxTax"
        Me.TxtboxTax.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTax.PlaceholderText = ""
        Me.TxtboxTax.SelectedText = ""
        Me.TxtboxTax.ShadowDecoration.Parent = Me.TxtboxTax
        Me.TxtboxTax.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxTax.TabIndex = 20
        '
        'TxtboxHdmf
        '
        Me.TxtboxHdmf.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxHdmf.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxHdmf.DefaultText = ""
        Me.TxtboxHdmf.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxHdmf.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxHdmf.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxHdmf.DisabledState.Parent = Me.TxtboxHdmf
        Me.TxtboxHdmf.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxHdmf.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxHdmf.FocusedState.Parent = Me.TxtboxHdmf
        Me.TxtboxHdmf.ForeColor = System.Drawing.Color.Black
        Me.TxtboxHdmf.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxHdmf.HoverState.Parent = Me.TxtboxHdmf
        Me.TxtboxHdmf.Location = New System.Drawing.Point(166, 29)
        Me.TxtboxHdmf.Margin = New System.Windows.Forms.Padding(9, 3, 9, 3)
        Me.TxtboxHdmf.Name = "TxtboxHdmf"
        Me.TxtboxHdmf.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxHdmf.PlaceholderText = ""
        Me.TxtboxHdmf.SelectedText = ""
        Me.TxtboxHdmf.ShadowDecoration.Parent = Me.TxtboxHdmf
        Me.TxtboxHdmf.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxHdmf.TabIndex = 18
        '
        'ChckboxPhic
        '
        Me.ChckboxPhic.AutoSize = True
        Me.ChckboxPhic.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxPhic.CheckedState.BorderRadius = 2
        Me.ChckboxPhic.CheckedState.BorderThickness = 0
        Me.ChckboxPhic.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxPhic.ForeColor = System.Drawing.Color.Black
        Me.ChckboxPhic.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChckboxPhic.Location = New System.Drawing.Point(228, 109)
        Me.ChckboxPhic.Name = "ChckboxPhic"
        Me.ChckboxPhic.Size = New System.Drawing.Size(53, 19)
        Me.ChckboxPhic.TabIndex = 22
        Me.ChckboxPhic.Text = "PHIC"
        Me.ChckboxPhic.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxPhic.UncheckedState.BorderRadius = 2
        Me.ChckboxPhic.UncheckedState.BorderThickness = 0
        Me.ChckboxPhic.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxPhic.UseVisualStyleBackColor = True
        '
        'ChckboxSss
        '
        Me.ChckboxSss.AutoSize = True
        Me.ChckboxSss.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxSss.CheckedState.BorderRadius = 2
        Me.ChckboxSss.CheckedState.BorderThickness = 0
        Me.ChckboxSss.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxSss.ForeColor = System.Drawing.Color.Black
        Me.ChckboxSss.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChckboxSss.Location = New System.Drawing.Point(228, 83)
        Me.ChckboxSss.Name = "ChckboxSss"
        Me.ChckboxSss.Size = New System.Drawing.Size(44, 19)
        Me.ChckboxSss.TabIndex = 21
        Me.ChckboxSss.Text = "SSS"
        Me.ChckboxSss.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxSss.UncheckedState.BorderRadius = 2
        Me.ChckboxSss.UncheckedState.BorderThickness = 0
        Me.ChckboxSss.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxSss.UseVisualStyleBackColor = True
        '
        'ChckboxTax
        '
        Me.ChckboxTax.AutoSize = True
        Me.ChckboxTax.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxTax.CheckedState.BorderRadius = 2
        Me.ChckboxTax.CheckedState.BorderThickness = 0
        Me.ChckboxTax.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxTax.ForeColor = System.Drawing.Color.Black
        Me.ChckboxTax.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChckboxTax.Location = New System.Drawing.Point(228, 56)
        Me.ChckboxTax.Name = "ChckboxTax"
        Me.ChckboxTax.Size = New System.Drawing.Size(46, 19)
        Me.ChckboxTax.TabIndex = 19
        Me.ChckboxTax.Text = "TAX"
        Me.ChckboxTax.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxTax.UncheckedState.BorderRadius = 2
        Me.ChckboxTax.UncheckedState.BorderThickness = 0
        Me.ChckboxTax.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxTax.UseVisualStyleBackColor = True
        '
        'ChckboxHdmf
        '
        Me.ChckboxHdmf.AutoSize = True
        Me.ChckboxHdmf.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxHdmf.CheckedState.BorderRadius = 2
        Me.ChckboxHdmf.CheckedState.BorderThickness = 0
        Me.ChckboxHdmf.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxHdmf.ForeColor = System.Drawing.Color.Black
        Me.ChckboxHdmf.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChckboxHdmf.Location = New System.Drawing.Point(228, 31)
        Me.ChckboxHdmf.Name = "ChckboxHdmf"
        Me.ChckboxHdmf.Size = New System.Drawing.Size(60, 19)
        Me.ChckboxHdmf.TabIndex = 17
        Me.ChckboxHdmf.Text = "HDMF"
        Me.ChckboxHdmf.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxHdmf.UncheckedState.BorderRadius = 2
        Me.ChckboxHdmf.UncheckedState.BorderThickness = 0
        Me.ChckboxHdmf.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxHdmf.UseVisualStyleBackColor = True
        '
        'TxtboxTardiness
        '
        Me.TxtboxTardiness.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTardiness.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTardiness.DefaultText = ""
        Me.TxtboxTardiness.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTardiness.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTardiness.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTardiness.DisabledState.Parent = Me.TxtboxTardiness
        Me.TxtboxTardiness.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTardiness.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTardiness.FocusedState.Parent = Me.TxtboxTardiness
        Me.TxtboxTardiness.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTardiness.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTardiness.HoverState.Parent = Me.TxtboxTardiness
        Me.TxtboxTardiness.Location = New System.Drawing.Point(83, 55)
        Me.TxtboxTardiness.Margin = New System.Windows.Forms.Padding(9, 3, 9, 3)
        Me.TxtboxTardiness.Name = "TxtboxTardiness"
        Me.TxtboxTardiness.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTardiness.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTardiness.PlaceholderText = "Mins"
        Me.TxtboxTardiness.SelectedText = ""
        Me.TxtboxTardiness.ShadowDecoration.Parent = Me.TxtboxTardiness
        Me.TxtboxTardiness.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxTardiness.TabIndex = 16
        '
        'TxtboxAbsences
        '
        Me.TxtboxAbsences.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAbsences.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAbsences.DefaultText = ""
        Me.TxtboxAbsences.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAbsences.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAbsences.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAbsences.DisabledState.Parent = Me.TxtboxAbsences
        Me.TxtboxAbsences.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAbsences.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAbsences.FocusedState.Parent = Me.TxtboxAbsences
        Me.TxtboxAbsences.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAbsences.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAbsences.HoverState.Parent = Me.TxtboxAbsences
        Me.TxtboxAbsences.Location = New System.Drawing.Point(83, 29)
        Me.TxtboxAbsences.Margin = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.TxtboxAbsences.Name = "TxtboxAbsences"
        Me.TxtboxAbsences.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAbsences.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAbsences.PlaceholderText = "Days"
        Me.TxtboxAbsences.SelectedText = ""
        Me.TxtboxAbsences.ShadowDecoration.Parent = Me.TxtboxAbsences
        Me.TxtboxAbsences.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxAbsences.TabIndex = 15
        '
        'Guna2HtmlLabel26
        '
        Me.Guna2HtmlLabel26.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel26.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel26.Location = New System.Drawing.Point(9, 91)
        Me.Guna2HtmlLabel26.Name = "Guna2HtmlLabel26"
        Me.Guna2HtmlLabel26.Size = New System.Drawing.Size(65, 15)
        Me.Guna2HtmlLabel26.TabIndex = 36
        Me.Guna2HtmlLabel26.Text = "TARDINESS"
        '
        'Guna2HtmlLabel25
        '
        Me.Guna2HtmlLabel25.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel25.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel25.Location = New System.Drawing.Point(14, 65)
        Me.Guna2HtmlLabel25.Name = "Guna2HtmlLabel25"
        Me.Guna2HtmlLabel25.Size = New System.Drawing.Size(60, 15)
        Me.Guna2HtmlLabel25.TabIndex = 34
        Me.Guna2HtmlLabel25.Text = "ABSENCES"
        '
        'TxtboxTotalNetPay
        '
        Me.TxtboxTotalNetPay.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalNetPay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalNetPay.DefaultText = ""
        Me.TxtboxTotalNetPay.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalNetPay.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalNetPay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalNetPay.DisabledState.Parent = Me.TxtboxTotalNetPay
        Me.TxtboxTotalNetPay.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalNetPay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalNetPay.FocusedState.Parent = Me.TxtboxTotalNetPay
        Me.TxtboxTotalNetPay.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalNetPay.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalNetPay.HoverState.Parent = Me.TxtboxTotalNetPay
        Me.TxtboxTotalNetPay.Location = New System.Drawing.Point(776, 8)
        Me.TxtboxTotalNetPay.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalNetPay.Name = "TxtboxTotalNetPay"
        Me.TxtboxTotalNetPay.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalNetPay.PlaceholderText = ""
        Me.TxtboxTotalNetPay.ReadOnly = True
        Me.TxtboxTotalNetPay.SelectedText = ""
        Me.TxtboxTotalNetPay.ShadowDecoration.Parent = Me.TxtboxTotalNetPay
        Me.TxtboxTotalNetPay.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalNetPay.TabIndex = 33
        Me.TxtboxTotalNetPay.TabStop = False
        '
        'Guna2HtmlLabel24
        '
        Me.Guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel24.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel24.Location = New System.Drawing.Point(720, 13)
        Me.Guna2HtmlLabel24.Name = "Guna2HtmlLabel24"
        Me.Guna2HtmlLabel24.Size = New System.Drawing.Size(49, 15)
        Me.Guna2HtmlLabel24.TabIndex = 32
        Me.Guna2HtmlLabel24.Text = "NET PAY"
        '
        'Guna2HtmlLabel21
        '
        Me.Guna2HtmlLabel21.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel21.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel21.Location = New System.Drawing.Point(586, 65)
        Me.Guna2HtmlLabel21.Name = "Guna2HtmlLabel21"
        Me.Guna2HtmlLabel21.Size = New System.Drawing.Size(28, 15)
        Me.Guna2HtmlLabel21.TabIndex = 26
        Me.Guna2HtmlLabel21.Text = "PHIC"
        '
        'TxtboxTotalSssEs
        '
        Me.TxtboxTotalSssEs.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalSssEs.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalSssEs.DefaultText = ""
        Me.TxtboxTotalSssEs.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalSssEs.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalSssEs.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSssEs.DisabledState.Parent = Me.TxtboxTotalSssEs
        Me.TxtboxTotalSssEs.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSssEs.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSssEs.FocusedState.Parent = Me.TxtboxTotalSssEs
        Me.TxtboxTotalSssEs.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalSssEs.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSssEs.HoverState.Parent = Me.TxtboxTotalSssEs
        Me.TxtboxTotalSssEs.Location = New System.Drawing.Point(622, 34)
        Me.TxtboxTotalSssEs.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalSssEs.Name = "TxtboxTotalSssEs"
        Me.TxtboxTotalSssEs.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalSssEs.PlaceholderText = ""
        Me.TxtboxTotalSssEs.ReadOnly = True
        Me.TxtboxTotalSssEs.SelectedText = ""
        Me.TxtboxTotalSssEs.ShadowDecoration.Parent = Me.TxtboxTotalSssEs
        Me.TxtboxTotalSssEs.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalSssEs.TabIndex = 25
        Me.TxtboxTotalSssEs.TabStop = False
        '
        'Guna2HtmlLabel20
        '
        Me.Guna2HtmlLabel20.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel20.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel20.Location = New System.Drawing.Point(574, 39)
        Me.Guna2HtmlLabel20.Name = "Guna2HtmlLabel20"
        Me.Guna2HtmlLabel20.Size = New System.Drawing.Size(41, 15)
        Me.Guna2HtmlLabel20.TabIndex = 24
        Me.Guna2HtmlLabel20.Text = "SSS ES"
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.White
        Me.Guna2Panel2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel2.BorderThickness = 1
        Me.Guna2Panel2.Controls.Add(Me.BtnSave)
        Me.Guna2Panel2.Controls.Add(Me.BtnCompute)
        Me.Guna2Panel2.Controls.Add(Me.BtnClearField)
        Me.Guna2Panel2.Location = New System.Drawing.Point(12, 172)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(308, 154)
        Me.Guna2Panel2.TabIndex = 28
        '
        'BtnSave
        '
        Me.BtnSave.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSave.BorderThickness = 1
        Me.BtnSave.CheckedState.Parent = Me.BtnSave
        Me.BtnSave.CustomImages.Parent = Me.BtnSave
        Me.BtnSave.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSave.ForeColor = System.Drawing.Color.White
        Me.BtnSave.HoverState.Parent = Me.BtnSave
        Me.BtnSave.Location = New System.Drawing.Point(8, 102)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.ShadowDecoration.Parent = Me.BtnSave
        Me.BtnSave.Size = New System.Drawing.Size(294, 40)
        Me.BtnSave.TabIndex = 18
        Me.BtnSave.Text = "SAVE"
        '
        'BtnCompute
        '
        Me.BtnCompute.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnCompute.BorderThickness = 1
        Me.BtnCompute.CheckedState.Parent = Me.BtnCompute
        Me.BtnCompute.CustomImages.Parent = Me.BtnCompute
        Me.BtnCompute.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnCompute.ForeColor = System.Drawing.Color.White
        Me.BtnCompute.HoverState.Parent = Me.BtnCompute
        Me.BtnCompute.Location = New System.Drawing.Point(8, 56)
        Me.BtnCompute.Name = "BtnCompute"
        Me.BtnCompute.ShadowDecoration.Parent = Me.BtnCompute
        Me.BtnCompute.Size = New System.Drawing.Size(294, 40)
        Me.BtnCompute.TabIndex = 17
        Me.BtnCompute.Text = "COMPUTE"
        '
        'BtnClearField
        '
        Me.BtnClearField.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnClearField.BorderThickness = 1
        Me.BtnClearField.CheckedState.Parent = Me.BtnClearField
        Me.BtnClearField.CustomImages.Parent = Me.BtnClearField
        Me.BtnClearField.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnClearField.ForeColor = System.Drawing.Color.White
        Me.BtnClearField.HoverState.Parent = Me.BtnClearField
        Me.BtnClearField.Location = New System.Drawing.Point(8, 10)
        Me.BtnClearField.Name = "BtnClearField"
        Me.BtnClearField.ShadowDecoration.Parent = Me.BtnClearField
        Me.BtnClearField.Size = New System.Drawing.Size(294, 40)
        Me.BtnClearField.TabIndex = 16
        Me.BtnClearField.Text = "CLEAR FIELD"
        '
        'TxtboxTotalSssPs
        '
        Me.TxtboxTotalSssPs.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalSssPs.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalSssPs.DefaultText = ""
        Me.TxtboxTotalSssPs.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalSssPs.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalSssPs.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSssPs.DisabledState.Parent = Me.TxtboxTotalSssPs
        Me.TxtboxTotalSssPs.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSssPs.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSssPs.FocusedState.Parent = Me.TxtboxTotalSssPs
        Me.TxtboxTotalSssPs.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalSssPs.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSssPs.HoverState.Parent = Me.TxtboxTotalSssPs
        Me.TxtboxTotalSssPs.Location = New System.Drawing.Point(622, 8)
        Me.TxtboxTotalSssPs.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalSssPs.Name = "TxtboxTotalSssPs"
        Me.TxtboxTotalSssPs.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalSssPs.PlaceholderText = ""
        Me.TxtboxTotalSssPs.ReadOnly = True
        Me.TxtboxTotalSssPs.SelectedText = ""
        Me.TxtboxTotalSssPs.ShadowDecoration.Parent = Me.TxtboxTotalSssPs
        Me.TxtboxTotalSssPs.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalSssPs.TabIndex = 23
        Me.TxtboxTotalSssPs.TabStop = False
        '
        'Guna2HtmlLabel19
        '
        Me.Guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel19.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel19.Location = New System.Drawing.Point(574, 13)
        Me.Guna2HtmlLabel19.Name = "Guna2HtmlLabel19"
        Me.Guna2HtmlLabel19.Size = New System.Drawing.Size(41, 15)
        Me.Guna2HtmlLabel19.TabIndex = 22
        Me.Guna2HtmlLabel19.Text = "SSS PS"
        '
        'TxtboxTotalAdjustmentSub
        '
        Me.TxtboxTotalAdjustmentSub.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalAdjustmentSub.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalAdjustmentSub.DefaultText = ""
        Me.TxtboxTotalAdjustmentSub.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalAdjustmentSub.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalAdjustmentSub.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalAdjustmentSub.DisabledState.Parent = Me.TxtboxTotalAdjustmentSub
        Me.TxtboxTotalAdjustmentSub.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalAdjustmentSub.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalAdjustmentSub.FocusedState.Parent = Me.TxtboxTotalAdjustmentSub
        Me.TxtboxTotalAdjustmentSub.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalAdjustmentSub.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalAdjustmentSub.HoverState.Parent = Me.TxtboxTotalAdjustmentSub
        Me.TxtboxTotalAdjustmentSub.Location = New System.Drawing.Point(302, 86)
        Me.TxtboxTotalAdjustmentSub.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalAdjustmentSub.Name = "TxtboxTotalAdjustmentSub"
        Me.TxtboxTotalAdjustmentSub.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalAdjustmentSub.PlaceholderText = ""
        Me.TxtboxTotalAdjustmentSub.ReadOnly = True
        Me.TxtboxTotalAdjustmentSub.SelectedText = ""
        Me.TxtboxTotalAdjustmentSub.ShadowDecoration.Parent = Me.TxtboxTotalAdjustmentSub
        Me.TxtboxTotalAdjustmentSub.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalAdjustmentSub.TabIndex = 21
        Me.TxtboxTotalAdjustmentSub.TabStop = False
        '
        'Guna2HtmlLabel18
        '
        Me.Guna2HtmlLabel18.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel18.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel18.Location = New System.Drawing.Point(194, 91)
        Me.Guna2HtmlLabel18.Name = "Guna2HtmlLabel18"
        Me.Guna2HtmlLabel18.Size = New System.Drawing.Size(101, 15)
        Me.Guna2HtmlLabel18.TabIndex = 20
        Me.Guna2HtmlLabel18.Text = "ADJUSTMENT SUB"
        '
        'TxtboxTotalAdjustmentAdd
        '
        Me.TxtboxTotalAdjustmentAdd.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalAdjustmentAdd.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalAdjustmentAdd.DefaultText = ""
        Me.TxtboxTotalAdjustmentAdd.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalAdjustmentAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalAdjustmentAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalAdjustmentAdd.DisabledState.Parent = Me.TxtboxTotalAdjustmentAdd
        Me.TxtboxTotalAdjustmentAdd.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalAdjustmentAdd.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalAdjustmentAdd.FocusedState.Parent = Me.TxtboxTotalAdjustmentAdd
        Me.TxtboxTotalAdjustmentAdd.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalAdjustmentAdd.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalAdjustmentAdd.HoverState.Parent = Me.TxtboxTotalAdjustmentAdd
        Me.TxtboxTotalAdjustmentAdd.Location = New System.Drawing.Point(302, 60)
        Me.TxtboxTotalAdjustmentAdd.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalAdjustmentAdd.Name = "TxtboxTotalAdjustmentAdd"
        Me.TxtboxTotalAdjustmentAdd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalAdjustmentAdd.PlaceholderText = ""
        Me.TxtboxTotalAdjustmentAdd.ReadOnly = True
        Me.TxtboxTotalAdjustmentAdd.SelectedText = ""
        Me.TxtboxTotalAdjustmentAdd.ShadowDecoration.Parent = Me.TxtboxTotalAdjustmentAdd
        Me.TxtboxTotalAdjustmentAdd.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalAdjustmentAdd.TabIndex = 19
        Me.TxtboxTotalAdjustmentAdd.TabStop = False
        '
        'Guna2HtmlLabel17
        '
        Me.Guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel17.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel17.Location = New System.Drawing.Point(193, 65)
        Me.Guna2HtmlLabel17.Name = "Guna2HtmlLabel17"
        Me.Guna2HtmlLabel17.Size = New System.Drawing.Size(102, 15)
        Me.Guna2HtmlLabel17.TabIndex = 18
        Me.Guna2HtmlLabel17.Text = "ADJUSTMENT ADD"
        '
        'TxtboxTotalGrossPay
        '
        Me.TxtboxTotalGrossPay.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalGrossPay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalGrossPay.DefaultText = ""
        Me.TxtboxTotalGrossPay.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalGrossPay.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalGrossPay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalGrossPay.DisabledState.Parent = Me.TxtboxTotalGrossPay
        Me.TxtboxTotalGrossPay.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalGrossPay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalGrossPay.FocusedState.Parent = Me.TxtboxTotalGrossPay
        Me.TxtboxTotalGrossPay.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalGrossPay.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalGrossPay.HoverState.Parent = Me.TxtboxTotalGrossPay
        Me.TxtboxTotalGrossPay.Location = New System.Drawing.Point(473, 8)
        Me.TxtboxTotalGrossPay.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalGrossPay.Name = "TxtboxTotalGrossPay"
        Me.TxtboxTotalGrossPay.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalGrossPay.PlaceholderText = ""
        Me.TxtboxTotalGrossPay.ReadOnly = True
        Me.TxtboxTotalGrossPay.SelectedText = ""
        Me.TxtboxTotalGrossPay.ShadowDecoration.Parent = Me.TxtboxTotalGrossPay
        Me.TxtboxTotalGrossPay.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalGrossPay.TabIndex = 17
        Me.TxtboxTotalGrossPay.TabStop = False
        '
        'Guna2HtmlLabel16
        '
        Me.Guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel16.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel16.Location = New System.Drawing.Point(401, 13)
        Me.Guna2HtmlLabel16.Name = "Guna2HtmlLabel16"
        Me.Guna2HtmlLabel16.Size = New System.Drawing.Size(65, 15)
        Me.Guna2HtmlLabel16.TabIndex = 16
        Me.Guna2HtmlLabel16.Text = "GROSS PAY"
        '
        'TxtboxTotalTardinessAmount
        '
        Me.TxtboxTotalTardinessAmount.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalTardinessAmount.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalTardinessAmount.DefaultText = ""
        Me.TxtboxTotalTardinessAmount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalTardinessAmount.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalTardinessAmount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalTardinessAmount.DisabledState.Parent = Me.TxtboxTotalTardinessAmount
        Me.TxtboxTotalTardinessAmount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalTardinessAmount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalTardinessAmount.FocusedState.Parent = Me.TxtboxTotalTardinessAmount
        Me.TxtboxTotalTardinessAmount.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalTardinessAmount.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalTardinessAmount.HoverState.Parent = Me.TxtboxTotalTardinessAmount
        Me.TxtboxTotalTardinessAmount.Location = New System.Drawing.Point(302, 34)
        Me.TxtboxTotalTardinessAmount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalTardinessAmount.Name = "TxtboxTotalTardinessAmount"
        Me.TxtboxTotalTardinessAmount.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalTardinessAmount.PlaceholderText = ""
        Me.TxtboxTotalTardinessAmount.ReadOnly = True
        Me.TxtboxTotalTardinessAmount.SelectedText = ""
        Me.TxtboxTotalTardinessAmount.ShadowDecoration.Parent = Me.TxtboxTotalTardinessAmount
        Me.TxtboxTotalTardinessAmount.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalTardinessAmount.TabIndex = 15
        Me.TxtboxTotalTardinessAmount.TabStop = False
        '
        'Guna2HtmlLabel15
        '
        Me.Guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel15.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel15.Location = New System.Drawing.Point(180, 39)
        Me.Guna2HtmlLabel15.Name = "Guna2HtmlLabel15"
        Me.Guna2HtmlLabel15.Size = New System.Drawing.Size(115, 15)
        Me.Guna2HtmlLabel15.TabIndex = 14
        Me.Guna2HtmlLabel15.Text = "TARDINESS AMOUNT"
        '
        'TxtboxTotalAbsencesAmount
        '
        Me.TxtboxTotalAbsencesAmount.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalAbsencesAmount.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalAbsencesAmount.DefaultText = ""
        Me.TxtboxTotalAbsencesAmount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalAbsencesAmount.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalAbsencesAmount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalAbsencesAmount.DisabledState.Parent = Me.TxtboxTotalAbsencesAmount
        Me.TxtboxTotalAbsencesAmount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalAbsencesAmount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalAbsencesAmount.FocusedState.Parent = Me.TxtboxTotalAbsencesAmount
        Me.TxtboxTotalAbsencesAmount.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalAbsencesAmount.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalAbsencesAmount.HoverState.Parent = Me.TxtboxTotalAbsencesAmount
        Me.TxtboxTotalAbsencesAmount.Location = New System.Drawing.Point(302, 8)
        Me.TxtboxTotalAbsencesAmount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalAbsencesAmount.Name = "TxtboxTotalAbsencesAmount"
        Me.TxtboxTotalAbsencesAmount.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalAbsencesAmount.PlaceholderText = ""
        Me.TxtboxTotalAbsencesAmount.ReadOnly = True
        Me.TxtboxTotalAbsencesAmount.SelectedText = ""
        Me.TxtboxTotalAbsencesAmount.ShadowDecoration.Parent = Me.TxtboxTotalAbsencesAmount
        Me.TxtboxTotalAbsencesAmount.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalAbsencesAmount.TabIndex = 13
        Me.TxtboxTotalAbsencesAmount.TabStop = False
        '
        'Guna2HtmlLabel14
        '
        Me.Guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel14.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel14.Location = New System.Drawing.Point(185, 13)
        Me.Guna2HtmlLabel14.Name = "Guna2HtmlLabel14"
        Me.Guna2HtmlLabel14.Size = New System.Drawing.Size(110, 15)
        Me.Guna2HtmlLabel14.TabIndex = 12
        Me.Guna2HtmlLabel14.Text = "ABSENCES AMOUNT"
        '
        'TxtboxTotalBasic
        '
        Me.TxtboxTotalBasic.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalBasic.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalBasic.DefaultText = ""
        Me.TxtboxTotalBasic.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalBasic.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalBasic.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalBasic.DisabledState.Parent = Me.TxtboxTotalBasic
        Me.TxtboxTotalBasic.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalBasic.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalBasic.FocusedState.Parent = Me.TxtboxTotalBasic
        Me.TxtboxTotalBasic.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalBasic.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalBasic.HoverState.Parent = Me.TxtboxTotalBasic
        Me.TxtboxTotalBasic.Location = New System.Drawing.Point(81, 34)
        Me.TxtboxTotalBasic.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalBasic.Name = "TxtboxTotalBasic"
        Me.TxtboxTotalBasic.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalBasic.PlaceholderText = ""
        Me.TxtboxTotalBasic.ReadOnly = True
        Me.TxtboxTotalBasic.SelectedText = ""
        Me.TxtboxTotalBasic.ShadowDecoration.Parent = Me.TxtboxTotalBasic
        Me.TxtboxTotalBasic.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalBasic.TabIndex = 11
        Me.TxtboxTotalBasic.TabStop = False
        '
        'Guna2HtmlLabel13
        '
        Me.Guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel13.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel13.Location = New System.Drawing.Point(40, 39)
        Me.Guna2HtmlLabel13.Name = "Guna2HtmlLabel13"
        Me.Guna2HtmlLabel13.Size = New System.Drawing.Size(34, 15)
        Me.Guna2HtmlLabel13.TabIndex = 10
        Me.Guna2HtmlLabel13.Text = "BASIC"
        '
        'TxtboxTotalDailyRate
        '
        Me.TxtboxTotalDailyRate.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalDailyRate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalDailyRate.DefaultText = ""
        Me.TxtboxTotalDailyRate.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalDailyRate.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalDailyRate.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalDailyRate.DisabledState.Parent = Me.TxtboxTotalDailyRate
        Me.TxtboxTotalDailyRate.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalDailyRate.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalDailyRate.FocusedState.Parent = Me.TxtboxTotalDailyRate
        Me.TxtboxTotalDailyRate.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalDailyRate.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalDailyRate.HoverState.Parent = Me.TxtboxTotalDailyRate
        Me.TxtboxTotalDailyRate.Location = New System.Drawing.Point(81, 8)
        Me.TxtboxTotalDailyRate.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalDailyRate.Name = "TxtboxTotalDailyRate"
        Me.TxtboxTotalDailyRate.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalDailyRate.PlaceholderText = ""
        Me.TxtboxTotalDailyRate.ReadOnly = True
        Me.TxtboxTotalDailyRate.SelectedText = ""
        Me.TxtboxTotalDailyRate.ShadowDecoration.Parent = Me.TxtboxTotalDailyRate
        Me.TxtboxTotalDailyRate.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalDailyRate.TabIndex = 9
        Me.TxtboxTotalDailyRate.TabStop = False
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(8, 13)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(66, 15)
        Me.Guna2HtmlLabel5.TabIndex = 8
        Me.Guna2HtmlLabel5.Text = "DAILY RATE"
        '
        'Guna2HtmlLabel12
        '
        Me.Guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel12.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel12.Location = New System.Drawing.Point(20, 56)
        Me.Guna2HtmlLabel12.Name = "Guna2HtmlLabel12"
        Me.Guna2HtmlLabel12.Size = New System.Drawing.Size(49, 15)
        Me.Guna2HtmlLabel12.TabIndex = 11
        Me.Guna2HtmlLabel12.TabStop = False
        Me.Guna2HtmlLabel12.Text = "Tardiness"
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxSalary)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxPosition)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxAcctNo)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxFullName)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(308, 154)
        Me.Guna2GroupBox1.TabIndex = 21
        Me.Guna2GroupBox1.Text = "EMPLOYEE"
        Me.Guna2GroupBox1.TextOffset = New System.Drawing.Point(0, -10)
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(21, 113)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(45, 15)
        Me.Guna2HtmlLabel4.TabIndex = 7
        Me.Guna2HtmlLabel4.Text = "SALARY"
        '
        'TxtboxSalary
        '
        Me.TxtboxSalary.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxSalary.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxSalary.DefaultText = ""
        Me.TxtboxSalary.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxSalary.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxSalary.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSalary.DisabledState.Parent = Me.TxtboxSalary
        Me.TxtboxSalary.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSalary.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSalary.FocusedState.Parent = Me.TxtboxSalary
        Me.TxtboxSalary.ForeColor = System.Drawing.Color.Black
        Me.TxtboxSalary.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSalary.HoverState.Parent = Me.TxtboxSalary
        Me.TxtboxSalary.Location = New System.Drawing.Point(74, 107)
        Me.TxtboxSalary.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxSalary.Name = "TxtboxSalary"
        Me.TxtboxSalary.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxSalary.PlaceholderText = ""
        Me.TxtboxSalary.ReadOnly = True
        Me.TxtboxSalary.SelectedText = ""
        Me.TxtboxSalary.ShadowDecoration.Parent = Me.TxtboxSalary
        Me.TxtboxSalary.Size = New System.Drawing.Size(223, 23)
        Me.TxtboxSalary.TabIndex = 6
        Me.TxtboxSalary.TabStop = False
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(11, 84)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(54, 15)
        Me.Guna2HtmlLabel3.TabIndex = 5
        Me.Guna2HtmlLabel3.Text = "POSITION"
        '
        'TxtboxPosition
        '
        Me.TxtboxPosition.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxPosition.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPosition.DefaultText = ""
        Me.TxtboxPosition.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPosition.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPosition.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPosition.DisabledState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPosition.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPosition.FocusedState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPosition.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPosition.HoverState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.Location = New System.Drawing.Point(74, 81)
        Me.TxtboxPosition.Margin = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.TxtboxPosition.Name = "TxtboxPosition"
        Me.TxtboxPosition.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPosition.PlaceholderText = ""
        Me.TxtboxPosition.ReadOnly = True
        Me.TxtboxPosition.SelectedText = ""
        Me.TxtboxPosition.ShadowDecoration.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.Size = New System.Drawing.Size(223, 20)
        Me.TxtboxPosition.TabIndex = 4
        Me.TxtboxPosition.TabStop = False
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(18, 58)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(43, 15)
        Me.Guna2HtmlLabel2.TabIndex = 3
        Me.Guna2HtmlLabel2.Text = "ACC NO"
        '
        'TxtboxAcctNo
        '
        Me.TxtboxAcctNo.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAcctNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAcctNo.DefaultText = ""
        Me.TxtboxAcctNo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAcctNo.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAcctNo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAcctNo.DisabledState.Parent = Me.TxtboxAcctNo
        Me.TxtboxAcctNo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAcctNo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAcctNo.FocusedState.Parent = Me.TxtboxAcctNo
        Me.TxtboxAcctNo.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAcctNo.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAcctNo.HoverState.Parent = Me.TxtboxAcctNo
        Me.TxtboxAcctNo.Location = New System.Drawing.Point(74, 55)
        Me.TxtboxAcctNo.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxAcctNo.Name = "TxtboxAcctNo"
        Me.TxtboxAcctNo.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAcctNo.PlaceholderText = ""
        Me.TxtboxAcctNo.ReadOnly = True
        Me.TxtboxAcctNo.SelectedText = ""
        Me.TxtboxAcctNo.ShadowDecoration.Parent = Me.TxtboxAcctNo
        Me.TxtboxAcctNo.Size = New System.Drawing.Size(223, 20)
        Me.TxtboxAcctNo.TabIndex = 2
        Me.TxtboxAcctNo.TabStop = False
        '
        'TxtboxFullName
        '
        Me.TxtboxFullName.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxFullName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxFullName.DefaultText = ""
        Me.TxtboxFullName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxFullName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxFullName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxFullName.DisabledState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxFullName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxFullName.FocusedState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.ForeColor = System.Drawing.Color.Black
        Me.TxtboxFullName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxFullName.HoverState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.Location = New System.Drawing.Point(74, 29)
        Me.TxtboxFullName.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxFullName.Name = "TxtboxFullName"
        Me.TxtboxFullName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxFullName.PlaceholderText = ""
        Me.TxtboxFullName.ReadOnly = True
        Me.TxtboxFullName.SelectedText = ""
        Me.TxtboxFullName.ShadowDecoration.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.Size = New System.Drawing.Size(223, 20)
        Me.TxtboxFullName.TabIndex = 1
        Me.TxtboxFullName.TabStop = False
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(3, 32)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(60, 15)
        Me.Guna2HtmlLabel1.TabIndex = 0
        Me.Guna2HtmlLabel1.Text = "FULLNAME"
        '
        'Guna2GroupBox2
        '
        Me.Guna2GroupBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox2.Controls.Add(Me.TxtboxRemarks)
        Me.Guna2GroupBox2.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox2.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox2.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox2.Location = New System.Drawing.Point(326, 12)
        Me.Guna2GroupBox2.Name = "Guna2GroupBox2"
        Me.Guna2GroupBox2.ShadowDecoration.Parent = Me.Guna2GroupBox2
        Me.Guna2GroupBox2.Size = New System.Drawing.Size(190, 50)
        Me.Guna2GroupBox2.TabIndex = 22
        Me.Guna2GroupBox2.Text = "REMARKS"
        Me.Guna2GroupBox2.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxRemarks
        '
        Me.TxtboxRemarks.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxRemarks.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxRemarks.DefaultText = ""
        Me.TxtboxRemarks.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxRemarks.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxRemarks.FocusedState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.ForeColor = System.Drawing.Color.Black
        Me.TxtboxRemarks.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxRemarks.HoverState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.Location = New System.Drawing.Point(5, 23)
        Me.TxtboxRemarks.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxRemarks.Name = "TxtboxRemarks"
        Me.TxtboxRemarks.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxRemarks.PlaceholderText = ""
        Me.TxtboxRemarks.SelectedText = ""
        Me.TxtboxRemarks.ShadowDecoration.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.Size = New System.Drawing.Size(180, 20)
        Me.TxtboxRemarks.TabIndex = 4
        '
        'Guna2GroupBox3
        '
        Me.Guna2GroupBox3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox3.Controls.Add(Me.TxtboxCoverage)
        Me.Guna2GroupBox3.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox3.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox3.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox3.Location = New System.Drawing.Point(326, 68)
        Me.Guna2GroupBox3.Name = "Guna2GroupBox3"
        Me.Guna2GroupBox3.ShadowDecoration.Parent = Me.Guna2GroupBox3
        Me.Guna2GroupBox3.Size = New System.Drawing.Size(190, 50)
        Me.Guna2GroupBox3.TabIndex = 23
        Me.Guna2GroupBox3.Text = "COVERAGE"
        Me.Guna2GroupBox3.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxCoverage
        '
        Me.TxtboxCoverage.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxCoverage.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxCoverage.DefaultText = ""
        Me.TxtboxCoverage.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxCoverage.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxCoverage.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCoverage.DisabledState.Parent = Me.TxtboxCoverage
        Me.TxtboxCoverage.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCoverage.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCoverage.FocusedState.Parent = Me.TxtboxCoverage
        Me.TxtboxCoverage.ForeColor = System.Drawing.Color.Black
        Me.TxtboxCoverage.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCoverage.HoverState.Parent = Me.TxtboxCoverage
        Me.TxtboxCoverage.Location = New System.Drawing.Point(5, 23)
        Me.TxtboxCoverage.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxCoverage.Name = "TxtboxCoverage"
        Me.TxtboxCoverage.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxCoverage.PlaceholderText = ""
        Me.TxtboxCoverage.SelectedText = ""
        Me.TxtboxCoverage.ShadowDecoration.Parent = Me.TxtboxCoverage
        Me.TxtboxCoverage.Size = New System.Drawing.Size(180, 20)
        Me.TxtboxCoverage.TabIndex = 6
        '
        'Guna2GroupBox4
        '
        Me.Guna2GroupBox4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox4.Controls.Add(Me.TxtboxTotalNoOfDaysServed)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2HtmlLabel8)
        Me.Guna2GroupBox4.Controls.Add(Me.TxtboxCalendarDays)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2HtmlLabel7)
        Me.Guna2GroupBox4.Controls.Add(Me.CmboxMonth)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Guna2GroupBox4.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox4.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox4.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox4.Location = New System.Drawing.Point(522, 12)
        Me.Guna2GroupBox4.Name = "Guna2GroupBox4"
        Me.Guna2GroupBox4.ShadowDecoration.Parent = Me.Guna2GroupBox4
        Me.Guna2GroupBox4.Size = New System.Drawing.Size(250, 154)
        Me.Guna2GroupBox4.TabIndex = 24
        Me.Guna2GroupBox4.Text = "BASIC PAY"
        Me.Guna2GroupBox4.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxTotalNoOfDaysServed
        '
        Me.TxtboxTotalNoOfDaysServed.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalNoOfDaysServed.DefaultText = ""
        Me.TxtboxTotalNoOfDaysServed.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.DisabledState.Parent = Me.TxtboxTotalNoOfDaysServed
        Me.TxtboxTotalNoOfDaysServed.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.FocusedState.Parent = Me.TxtboxTotalNoOfDaysServed
        Me.TxtboxTotalNoOfDaysServed.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalNoOfDaysServed.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.HoverState.Parent = Me.TxtboxTotalNoOfDaysServed
        Me.TxtboxTotalNoOfDaysServed.Location = New System.Drawing.Point(172, 81)
        Me.TxtboxTotalNoOfDaysServed.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxTotalNoOfDaysServed.Name = "TxtboxTotalNoOfDaysServed"
        Me.TxtboxTotalNoOfDaysServed.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalNoOfDaysServed.PlaceholderText = ""
        Me.TxtboxTotalNoOfDaysServed.SelectedText = ""
        Me.TxtboxTotalNoOfDaysServed.ShadowDecoration.Parent = Me.TxtboxTotalNoOfDaysServed
        Me.TxtboxTotalNoOfDaysServed.Size = New System.Drawing.Size(65, 20)
        Me.TxtboxTotalNoOfDaysServed.TabIndex = 10
        '
        'Guna2HtmlLabel8
        '
        Me.Guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel8.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel8.Location = New System.Drawing.Point(14, 84)
        Me.Guna2HtmlLabel8.Name = "Guna2HtmlLabel8"
        Me.Guna2HtmlLabel8.Size = New System.Drawing.Size(153, 15)
        Me.Guna2HtmlLabel8.TabIndex = 5
        Me.Guna2HtmlLabel8.TabStop = False
        Me.Guna2HtmlLabel8.Text = "TOTAL NO OF DAYS SERVED"
        '
        'TxtboxCalendarDays
        '
        Me.TxtboxCalendarDays.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxCalendarDays.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxCalendarDays.DefaultText = ""
        Me.TxtboxCalendarDays.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxCalendarDays.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxCalendarDays.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCalendarDays.DisabledState.Parent = Me.TxtboxCalendarDays
        Me.TxtboxCalendarDays.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCalendarDays.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCalendarDays.FocusedState.Parent = Me.TxtboxCalendarDays
        Me.TxtboxCalendarDays.ForeColor = System.Drawing.Color.Black
        Me.TxtboxCalendarDays.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCalendarDays.HoverState.Parent = Me.TxtboxCalendarDays
        Me.TxtboxCalendarDays.Location = New System.Drawing.Point(172, 56)
        Me.TxtboxCalendarDays.Margin = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.TxtboxCalendarDays.Name = "TxtboxCalendarDays"
        Me.TxtboxCalendarDays.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxCalendarDays.PlaceholderText = ""
        Me.TxtboxCalendarDays.SelectedText = ""
        Me.TxtboxCalendarDays.ShadowDecoration.Parent = Me.TxtboxCalendarDays
        Me.TxtboxCalendarDays.Size = New System.Drawing.Size(65, 20)
        Me.TxtboxCalendarDays.TabIndex = 9
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(71, 61)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(93, 15)
        Me.Guna2HtmlLabel7.TabIndex = 2
        Me.Guna2HtmlLabel7.TabStop = False
        Me.Guna2HtmlLabel7.Text = "CALENDAR DAYS"
        '
        'CmboxMonth
        '
        Me.CmboxMonth.BackColor = System.Drawing.Color.Transparent
        Me.CmboxMonth.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.CmboxMonth.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxMonth.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxMonth.FocusedState.Parent = Me.CmboxMonth
        Me.CmboxMonth.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxMonth.ForeColor = System.Drawing.Color.Black
        Me.CmboxMonth.FormattingEnabled = True
        Me.CmboxMonth.HoverState.Parent = Me.CmboxMonth
        Me.CmboxMonth.ItemHeight = 15
        Me.CmboxMonth.Items.AddRange(New Object() {"1.0", "0.5"})
        Me.CmboxMonth.ItemsAppearance.Parent = Me.CmboxMonth
        Me.CmboxMonth.Location = New System.Drawing.Point(172, 29)
        Me.CmboxMonth.Name = "CmboxMonth"
        Me.CmboxMonth.ShadowDecoration.Parent = Me.CmboxMonth
        Me.CmboxMonth.Size = New System.Drawing.Size(65, 21)
        Me.CmboxMonth.TabIndex = 8
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(123, 35)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(43, 15)
        Me.Guna2HtmlLabel6.TabIndex = 0
        Me.Guna2HtmlLabel6.TabStop = False
        Me.Guna2HtmlLabel6.Text = "MONTH"
        '
        'TxtboxTotalTardinessCount
        '
        Me.TxtboxTotalTardinessCount.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalTardinessCount.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalTardinessCount.DefaultText = ""
        Me.TxtboxTotalTardinessCount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalTardinessCount.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalTardinessCount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalTardinessCount.DisabledState.Parent = Me.TxtboxTotalTardinessCount
        Me.TxtboxTotalTardinessCount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalTardinessCount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalTardinessCount.FocusedState.Parent = Me.TxtboxTotalTardinessCount
        Me.TxtboxTotalTardinessCount.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalTardinessCount.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalTardinessCount.HoverState.Parent = Me.TxtboxTotalTardinessCount
        Me.TxtboxTotalTardinessCount.Location = New System.Drawing.Point(81, 86)
        Me.TxtboxTotalTardinessCount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxTotalTardinessCount.Name = "TxtboxTotalTardinessCount"
        Me.TxtboxTotalTardinessCount.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalTardinessCount.PlaceholderText = ""
        Me.TxtboxTotalTardinessCount.ReadOnly = True
        Me.TxtboxTotalTardinessCount.SelectedText = ""
        Me.TxtboxTotalTardinessCount.ShadowDecoration.Parent = Me.TxtboxTotalTardinessCount
        Me.TxtboxTotalTardinessCount.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxTotalTardinessCount.TabIndex = 37
        Me.TxtboxTotalTardinessCount.TabStop = False
        '
        'Guna2GroupBox5
        '
        Me.Guna2GroupBox5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox5.Controls.Add(Me.Guna2HtmlLabel10)
        Me.Guna2GroupBox5.Controls.Add(Me.TxtboxAdjustmentSub)
        Me.Guna2GroupBox5.Controls.Add(Me.Guna2HtmlLabel9)
        Me.Guna2GroupBox5.Controls.Add(Me.TxtboxAdjustmentAdd)
        Me.Guna2GroupBox5.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox5.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox5.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox5.Location = New System.Drawing.Point(778, 12)
        Me.Guna2GroupBox5.Name = "Guna2GroupBox5"
        Me.Guna2GroupBox5.ShadowDecoration.Parent = Me.Guna2GroupBox5
        Me.Guna2GroupBox5.Size = New System.Drawing.Size(102, 154)
        Me.Guna2GroupBox5.TabIndex = 25
        Me.Guna2GroupBox5.Text = "ADJUSTMENT"
        Me.Guna2GroupBox5.TextOffset = New System.Drawing.Point(0, -10)
        '
        'Guna2HtmlLabel10
        '
        Me.Guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel10.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel10.Location = New System.Drawing.Point(9, 56)
        Me.Guna2HtmlLabel10.Name = "Guna2HtmlLabel10"
        Me.Guna2HtmlLabel10.Size = New System.Drawing.Size(18, 15)
        Me.Guna2HtmlLabel10.TabIndex = 9
        Me.Guna2HtmlLabel10.TabStop = False
        Me.Guna2HtmlLabel10.Text = "( - )"
        '
        'TxtboxAdjustmentSub
        '
        Me.TxtboxAdjustmentSub.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAdjustmentSub.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAdjustmentSub.DefaultText = ""
        Me.TxtboxAdjustmentSub.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAdjustmentSub.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAdjustmentSub.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAdjustmentSub.DisabledState.Parent = Me.TxtboxAdjustmentSub
        Me.TxtboxAdjustmentSub.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAdjustmentSub.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAdjustmentSub.FocusedState.Parent = Me.TxtboxAdjustmentSub
        Me.TxtboxAdjustmentSub.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAdjustmentSub.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAdjustmentSub.HoverState.Parent = Me.TxtboxAdjustmentSub
        Me.TxtboxAdjustmentSub.Location = New System.Drawing.Point(40, 55)
        Me.TxtboxAdjustmentSub.Margin = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.TxtboxAdjustmentSub.Name = "TxtboxAdjustmentSub"
        Me.TxtboxAdjustmentSub.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAdjustmentSub.PlaceholderText = ""
        Me.TxtboxAdjustmentSub.SelectedText = ""
        Me.TxtboxAdjustmentSub.ShadowDecoration.Parent = Me.TxtboxAdjustmentSub
        Me.TxtboxAdjustmentSub.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxAdjustmentSub.TabIndex = 13
        '
        'Guna2HtmlLabel9
        '
        Me.Guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel9.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel9.Location = New System.Drawing.Point(9, 31)
        Me.Guna2HtmlLabel9.Name = "Guna2HtmlLabel9"
        Me.Guna2HtmlLabel9.Size = New System.Drawing.Size(21, 15)
        Me.Guna2HtmlLabel9.TabIndex = 7
        Me.Guna2HtmlLabel9.TabStop = False
        Me.Guna2HtmlLabel9.Text = "( + )"
        '
        'TxtboxAdjustmentAdd
        '
        Me.TxtboxAdjustmentAdd.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAdjustmentAdd.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAdjustmentAdd.DefaultText = ""
        Me.TxtboxAdjustmentAdd.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAdjustmentAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAdjustmentAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAdjustmentAdd.DisabledState.Parent = Me.TxtboxAdjustmentAdd
        Me.TxtboxAdjustmentAdd.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAdjustmentAdd.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAdjustmentAdd.FocusedState.Parent = Me.TxtboxAdjustmentAdd
        Me.TxtboxAdjustmentAdd.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAdjustmentAdd.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAdjustmentAdd.HoverState.Parent = Me.TxtboxAdjustmentAdd
        Me.TxtboxAdjustmentAdd.Location = New System.Drawing.Point(40, 29)
        Me.TxtboxAdjustmentAdd.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxAdjustmentAdd.Name = "TxtboxAdjustmentAdd"
        Me.TxtboxAdjustmentAdd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAdjustmentAdd.PlaceholderText = ""
        Me.TxtboxAdjustmentAdd.SelectedText = ""
        Me.TxtboxAdjustmentAdd.ShadowDecoration.Parent = Me.TxtboxAdjustmentAdd
        Me.TxtboxAdjustmentAdd.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxAdjustmentAdd.TabIndex = 12
        '
        'Guna2GroupBox6
        '
        Me.Guna2GroupBox6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox6.Controls.Add(Me.Guna2VSeparator1)
        Me.Guna2GroupBox6.Controls.Add(Me.TxtboxTax)
        Me.Guna2GroupBox6.Controls.Add(Me.TxtboxHdmf)
        Me.Guna2GroupBox6.Controls.Add(Me.ChckboxPhic)
        Me.Guna2GroupBox6.Controls.Add(Me.ChckboxSss)
        Me.Guna2GroupBox6.Controls.Add(Me.ChckboxTax)
        Me.Guna2GroupBox6.Controls.Add(Me.ChckboxHdmf)
        Me.Guna2GroupBox6.Controls.Add(Me.TxtboxTardiness)
        Me.Guna2GroupBox6.Controls.Add(Me.TxtboxAbsences)
        Me.Guna2GroupBox6.Controls.Add(Me.Guna2HtmlLabel12)
        Me.Guna2GroupBox6.Controls.Add(Me.Guna2HtmlLabel11)
        Me.Guna2GroupBox6.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox6.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox6.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox6.Location = New System.Drawing.Point(522, 172)
        Me.Guna2GroupBox6.Name = "Guna2GroupBox6"
        Me.Guna2GroupBox6.ShadowDecoration.Parent = Me.Guna2GroupBox6
        Me.Guna2GroupBox6.Size = New System.Drawing.Size(358, 154)
        Me.Guna2GroupBox6.TabIndex = 26
        Me.Guna2GroupBox6.Text = "DEDUCTIONS"
        Me.Guna2GroupBox6.TextOffset = New System.Drawing.Point(0, -10)
        '
        'Guna2HtmlLabel11
        '
        Me.Guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel11.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel11.Location = New System.Drawing.Point(19, 31)
        Me.Guna2HtmlLabel11.Name = "Guna2HtmlLabel11"
        Me.Guna2HtmlLabel11.Size = New System.Drawing.Size(50, 15)
        Me.Guna2HtmlLabel11.TabIndex = 10
        Me.Guna2HtmlLabel11.TabStop = False
        Me.Guna2HtmlLabel11.Text = "Absences"
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BackColor = System.Drawing.Color.White
        Me.Guna2Panel1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel1.BorderThickness = 1
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalTardinessCount)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel26)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalAbsencesCount)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel25)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalNetPay)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel24)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalTax)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel23)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalHdmf)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel22)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalPhic)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel21)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalSssEs)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel20)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalSssPs)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel19)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalAdjustmentSub)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel18)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalAdjustmentAdd)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel17)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalGrossPay)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel16)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalTardinessAmount)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel15)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalAbsencesAmount)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel14)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalBasic)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel13)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalDailyRate)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Guna2Panel1.Location = New System.Drawing.Point(12, 336)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(868, 146)
        Me.Guna2Panel1.TabIndex = 27
        '
        'EditPayrollEditComputation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(892, 494)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.Controls.Add(Me.Guna2GroupBox2)
        Me.Controls.Add(Me.Guna2GroupBox3)
        Me.Controls.Add(Me.Guna2GroupBox4)
        Me.Controls.Add(Me.Guna2GroupBox5)
        Me.Controls.Add(Me.Guna2GroupBox6)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(908, 533)
        Me.MinimumSize = New System.Drawing.Size(908, 533)
        Me.Name = "EditPayrollEditComputation"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EditPayrollEditComputation"
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox1.PerformLayout()
        Me.Guna2GroupBox2.ResumeLayout(False)
        Me.Guna2GroupBox3.ResumeLayout(False)
        Me.Guna2GroupBox4.ResumeLayout(False)
        Me.Guna2GroupBox4.PerformLayout()
        Me.Guna2GroupBox5.ResumeLayout(False)
        Me.Guna2GroupBox5.PerformLayout()
        Me.Guna2GroupBox6.ResumeLayout(False)
        Me.Guna2GroupBox6.PerformLayout()
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TxtboxTotalAbsencesCount As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxTotalTax As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel23 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalHdmf As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel22 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalPhic As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2VSeparator1 As Guna.UI2.WinForms.Guna2VSeparator
    Friend WithEvents TxtboxTax As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxHdmf As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents ChckboxPhic As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents ChckboxSss As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents ChckboxTax As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents ChckboxHdmf As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents TxtboxTardiness As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxAbsences As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel26 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel25 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalNetPay As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel24 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel21 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalSssEs As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel20 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents BtnSave As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnCompute As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnClearField As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents TxtboxTotalSssPs As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel19 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalAdjustmentSub As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel18 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalAdjustmentAdd As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel17 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalGrossPay As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel16 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalTardinessAmount As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel15 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalAbsencesAmount As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel14 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalBasic As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel13 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalDailyRate As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel12 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxSalary As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxPosition As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxAcctNo As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxFullName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GroupBox2 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxRemarks As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox3 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxCoverage As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox4 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxTotalNoOfDaysServed As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel8 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxCalendarDays As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents CmboxMonth As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalTardinessCount As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox5 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2HtmlLabel10 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxAdjustmentSub As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel9 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxAdjustmentAdd As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox6 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2HtmlLabel11 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
End Class
