﻿Public Class EditPayrollSelectEmployees

    Private Sub HighlightEmployees()
        ' for checking if the employee is added to payroll
        For Each row As DataGridViewRow In Dtglist.Rows
            ' iterating dtglist rows
            For Each row2 As DataGridViewRow In EditPayroll.Dtglist.Rows
                'checking for duplicates in multipleAdd.dtglist.Rows via AcctNo
                If row.Cells("acctNo").Value = row2.Cells("ACC NO").Value Then

                    row.DefaultCellStyle.BackColor = Color.Yellow
                    row.DefaultCellStyle.ForeColor = Color.Black
                End If
            Next
        Next
    End Sub
    Private Sub EditPayrollSelectEmployees_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload("SELECT employeesnums.EmployeeNo,
                       employees.AcctNo,
                       FullName,
                       LastName,
                       Suffix,
                       Appellation,
                       FirstName,
                       MiddleName,
                       BirthDate,
                       Salary,
                       Position,
                       Remarks,
                       SssNum,
                       HdmfNum,
                       PhicNum
                FROM employeesnums INNER JOIN employees
                ON employeesnums.AcctNo = employees.AcctNo
                WHERE
                Status = 'ACTIVE' AND Type = '" & GlobalVariables.loginType & "'",
                Dtglist, strCon)

        HighlightEmployees()
        Dtglist.ClearSelection()
    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each row As DataGridViewRow In Dtglist.Rows

            ' retrieving the value if checkbox is selected
            Dim iSelected As Boolean = Convert.ToBoolean(row.Cells("Sel").Value)

            ' filling empty textboxes and values
            If EditPayroll.CmboxMonth.Text = "1.0" Then
                EditPayroll.TxtboxCalendarDays.Text = "22"
                EditPayroll.TxtboxTotalNoOfDaysServed.Text = "22"
            ElseIf EditPayroll.CmboxMonth.Text = "0.5" Then
                EditPayroll.TxtboxCalendarDays.Text = "22"
                EditPayroll.TxtboxTotalNoOfDaysServed.Text = "11"
            End If

            If EditPayroll.TxtboxCalendarDays.Text = "" Then
                EditPayroll.TxtboxCalendarDays.Text = "22"
            End If

            If EditPayroll.TxtboxTotalNoOfDaysServed.Text = "" Then
                EditPayroll.TxtboxTotalNoOfDaysServed.Text = "22"
            End If

            If EditPayroll.TxtboxAdjustmentAdd.Text = "" Then
                EditPayroll.TxtboxAdjustmentAdd.Text = "0"
            End If

            If EditPayroll.TxtboxAdjustmentSub.Text = "" Then
                EditPayroll.TxtboxAdjustmentSub.Text = "0"
            End If

            If EditPayroll.TxtboxAbsences.Text = "" Then
                EditPayroll.TxtboxAbsences.Text = "0"
            End If

            If EditPayroll.TxtboxTardiness.Text = "" Then
                EditPayroll.TxtboxTardiness.Text = "0"
            End If

            If EditPayroll.ChckboxHdmf.Checked = True And EditPayroll.TxtboxHdmf.Text = "" Then
                EditPayroll.TxtboxHdmf.Text = "0"
            End If

            If EditPayroll.ChckboxTax.Checked = True And EditPayroll.TxtboxTax.Text = "" Then
                EditPayroll.TxtboxTax.Text = "0"
            End If

            ' calendar days cannot be lower than total no of days served
            If CDbl(EditPayroll.TxtboxCalendarDays.Text) < CDbl(EditPayroll.TxtboxTotalNoOfDaysServed.Text) Then
                MessageBox.Show("Invalid digit variables")
                Exit Sub
            End If

            ' setting base variables
            Dim month As Double
            Dim calendarDays As Double
            Dim totalNoOfDaysServed As Double
            Dim monthlyRate As Double

            If EditPayroll.CmboxMonth.SelectedIndex = -1 Then
                month = 0
            Else
                month = CDbl(EditPayroll.CmboxMonth.Text)
            End If

            calendarDays = CDbl(EditPayroll.TxtboxCalendarDays.Text)
            totalNoOfDaysServed = CDbl(EditPayroll.TxtboxTotalNoOfDaysServed.Text)
            monthlyRate = CDbl(row.Cells("Salary").Value)

            ' setting base computations and grosspay
            Dim dailyRate As Double
            Dim basic As Double
            Dim absences As Double
            Dim tardiness As Double
            Dim absencesAmount As Double
            Dim tardinessAmount As Double
            Dim leaveWithoutPay As Double
            Dim adjustmentAdd As Double
            Dim adjustmentSub As Double
            Dim grosspay As Double

            dailyRate = Math.Round(monthlyRate / calendarDays, 2)
            basic = Math.Round((monthlyRate / calendarDays) * totalNoOfDaysServed, 2)
            absences = Math.Round(CDbl(EditPayroll.TxtboxAbsences.Text), 2)
            tardiness = Math.Round(CDbl(EditPayroll.TxtboxTardiness.Text), 2)
            absencesAmount = Math.Round((monthlyRate / 22) * absences, 2)
            tardinessAmount = Math.Round((monthlyRate / 22 / 8 / 60) * tardiness, 2)
            leaveWithoutPay = Math.Round(absencesAmount + tardinessAmount, 2)
            adjustmentAdd = Math.Round(CDbl(EditPayroll.TxtboxAdjustmentAdd.Text), 2)
            adjustmentSub = Math.Round(CDbl(EditPayroll.TxtboxAdjustmentSub.Text), 2)
            grosspay = (basic + adjustmentAdd) - (absencesAmount + tardinessAmount + adjustmentSub)

            ' setting deductions, tax, and net pay

            Dim sssPs As Double
            Dim sssEs As Double
            Dim phic As Double
            Dim hdmf As Double
            Dim tax As Double
            Dim netpay As Double

            ' Sss
            If EditPayroll.ChckboxSss.Checked = True Then
                sssPs = Math.Round(basic * 0.045, 2)
                sssEs = Math.Round(basic * 0.095, 2)

                If EditPayroll.CmboxMonth.SelectedIndex = -1 Then
                    sssPs = Math.Round(basic * 0.045, 2)
                    sssEs = Math.Round(basic * 0.095, 2)
                Else
                    sssPs = Math.Round(monthlyRate * 0.045, 2)
                    sssEs = Math.Round(monthlyRate * 0.095, 2)
                End If

            ElseIf EditPayroll.ChckboxSss.Checked = False Then
                sssPs = 0
                sssEs = 0
            End If

            'phic
            If EditPayroll.ChckboxPhic.Checked = True Then
                phic = Math.Round((monthlyRate / 2) * 0.05, 2)
            ElseIf EditPayroll.ChckboxPhic.Checked = False Then
                phic = 0
            End If

            'hdmf
            If EditPayroll.ChckboxHdmf.Checked = True Then
                hdmf = Math.Round(CDbl(EditPayroll.TxtboxHdmf.Text), 2)
            ElseIf EditPayroll.ChckboxHdmf.Checked = True Then
                hdmf = 0
            End If

            'tax
            If EditPayroll.ChckboxTax.Checked = True Then
                tax = Math.Round(CDbl(EditPayroll.TxtboxTax.Text), 2)
            ElseIf EditPayroll.ChckboxTax.Checked = False Then
                tax = 0
            End If

            netpay = Math.Round((grosspay) - (sssPs + phic + hdmf + tax), 2)

            ' basic information variables
            Dim remarks As String
            Dim coverage As String

            remarks = EditPayroll.TxtboxRemarks.Text.ToUpper

            'converting month digits to 3-lettered month
            Dim months As Dictionary(Of String, String) = New Dictionary(Of String, String)
            months.Add("01", "JAN")
            months.Add("02", "FEB")
            months.Add("03", "MAR")
            months.Add("04", "APR")
            months.Add("05", "MAY")
            months.Add("06", "JUN")
            months.Add("07", "JUL")
            months.Add("08", "AUG")
            months.Add("09", "SEP")
            months.Add("10", "OCT")
            months.Add("11", "NOV")
            months.Add("12", "DEC")

            'for setting the coverage value

            If EditPayroll.TxtboxCoverage.Text = "" Then 'if EditPayroll.TxtboxCoverage.Text is empty
                If EditPayroll.TxtboxPeriod.Text = "" Then 'if EditPayroll.TxtboxPeriod.Text is empty
                    coverage = months.Item(Format(Date.Today, "MM")) + " " + Date.Today.Year.ToString
                Else
                    coverage = EditPayroll.TxtboxPeriod.Text.ToString
                End If
            Else
                coverage = EditPayroll.TxtboxCoverage.Text.ToUpper
            End If


            'checking if the row is selected
            If iSelected Then
                'checking for duplicates in EditPayroll.Dtglist.Rows
                For Each row2 As DataGridViewRow In EditPayroll.Dtglist.Rows
                    'if a duplicate is found
                    If row.Cells("AcctNo").Value = row2.Cells("ACC NO").Value Then
                        MessageBox.Show("User already exists in the table sheet")
                        'unchecking all checkboxes in dtglist
                        For Each row3 As DataGridViewRow In Dtglist.Rows
                            row3.Cells(0) = New DataGridViewCheckBoxCell With {.Value = False}
                        Next
                        Exit Sub
                    End If
                Next
            End If

            If iSelected Then
                EditPayroll.tblEditPayroll.Rows.Add(row.Cells("EmployeeNo").Value,
                                                  row.Cells("AcctNo").Value,
                                                  row.Cells("FullName").Value,
                                                  row.Cells("Position").Value,
                                                  coverage,
                                                  remarks,
                                                  row.Cells("SssNum").Value,
                                                  row.Cells("HdmfNum").Value,
                                                  row.Cells("PhicNum").Value,
                                                  monthlyRate,
                                                  EditPayroll.CmboxMonth.Text,
                                                  calendarDays,
                                                  totalNoOfDaysServed,
                                                  dailyRate,
                                                  basic,
                                                  absences,
                                                  absencesAmount,
                                                  tardiness,
                                                  tardinessAmount,
                                                  adjustmentAdd,
                                                  adjustmentSub,
                                                  grosspay,
                                                  sssPs,
                                                  sssEs,
                                                  phic,
                                                  hdmf,
                                                  tax,
                                                  netpay
                                                  )
                EditPayroll.Dtglist.DataSource = EditPayroll.tblEditPayroll

            End If

        Next

        HighlightEmployees()
        EditPayroll.RefreshEditPayrollDtglist()

        Me.Close()
    End Sub

    Private Sub Dtglist_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dtglist.CellDoubleClick
        Dtglist.CurrentRow.Cells(0) = New DataGridViewCheckBoxCell With {.Value = True}
    End Sub

    Private Sub ChckboxSelectAll_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxSelectAll.CheckedChanged
        If ChckboxSelectAll.Checked = False Then
            For Each row As DataGridViewRow In Dtglist.Rows
                If row.DefaultCellStyle.BackColor <> Color.Yellow Then
                    row.Cells(0) = New DataGridViewCheckBoxCell With {.Value = False}
                End If
            Next
        ElseIf ChckboxSelectAll.Checked = True Then
            For Each row As DataGridViewRow In Dtglist.Rows
                If row.DefaultCellStyle.BackColor <> Color.Yellow Then
                    row.Cells(0) = New DataGridViewCheckBoxCell With {.Value = True}
                End If
            Next
        End If
    End Sub
End Class