﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EditPayrollSelectEmployees
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.BtnAdd = New Guna.UI2.WinForms.Guna2Button()
        Me.ChckboxSelectAll = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Dtglist = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.Sel = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.EmployeeNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AcctNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FullName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Suffix = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Appellation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MiddleName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BirthDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Salary = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Position = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Remarks = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SssNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HdmfNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhicNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Guna2Panel1.SuspendLayout()
        CType(Me.Dtglist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnAdd
        '
        Me.BtnAdd.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnAdd.BorderThickness = 1
        Me.BtnAdd.CheckedState.Parent = Me.BtnAdd
        Me.BtnAdd.CustomImages.Parent = Me.BtnAdd
        Me.BtnAdd.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnAdd.ForeColor = System.Drawing.Color.White
        Me.BtnAdd.HoverState.Parent = Me.BtnAdd
        Me.BtnAdd.Location = New System.Drawing.Point(658, 9)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.ShadowDecoration.Parent = Me.BtnAdd
        Me.BtnAdd.Size = New System.Drawing.Size(130, 26)
        Me.BtnAdd.TabIndex = 2
        Me.BtnAdd.Text = "ADD"
        '
        'ChckboxSelectAll
        '
        Me.ChckboxSelectAll.AutoSize = True
        Me.ChckboxSelectAll.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxSelectAll.CheckedState.BorderRadius = 2
        Me.ChckboxSelectAll.CheckedState.BorderThickness = 0
        Me.ChckboxSelectAll.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxSelectAll.Location = New System.Drawing.Point(562, 12)
        Me.ChckboxSelectAll.Name = "ChckboxSelectAll"
        Me.ChckboxSelectAll.Size = New System.Drawing.Size(69, 17)
        Me.ChckboxSelectAll.TabIndex = 0
        Me.ChckboxSelectAll.Text = "Select all"
        Me.ChckboxSelectAll.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxSelectAll.UncheckedState.BorderRadius = 2
        Me.ChckboxSelectAll.UncheckedState.BorderThickness = 0
        Me.ChckboxSelectAll.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxSelectAll.UseVisualStyleBackColor = True
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel1.BorderThickness = 1
        Me.Guna2Panel1.Controls.Add(Me.BtnAdd)
        Me.Guna2Panel1.Controls.Add(Me.ChckboxSelectAll)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(800, 42)
        Me.Guna2Panel1.TabIndex = 2
        '
        'Dtglist
        '
        Me.Dtglist.AllowUserToAddRows = False
        Me.Dtglist.AllowUserToDeleteRows = False
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.Dtglist.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle13
        Me.Dtglist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Dtglist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Dtglist.BackgroundColor = System.Drawing.Color.White
        Me.Dtglist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dtglist.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Dtglist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle14.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dtglist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.Dtglist.ColumnHeadersHeight = 21
        Me.Dtglist.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Sel, Me.EmployeeNo, Me.AcctNo, Me.FullName, Me.LastName, Me.Suffix, Me.Appellation, Me.FirstName, Me.MiddleName, Me.BirthDate, Me.Salary, Me.Position, Me.Remarks, Me.SssNum, Me.HdmfNum, Me.PhicNum})
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Dtglist.DefaultCellStyle = DataGridViewCellStyle15
        Me.Dtglist.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dtglist.EnableHeadersVisualStyles = False
        Me.Dtglist.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Dtglist.Location = New System.Drawing.Point(0, 42)
        Me.Dtglist.Name = "Dtglist"
        Me.Dtglist.ReadOnly = True
        Me.Dtglist.RowHeadersVisible = False
        Me.Dtglist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dtglist.Size = New System.Drawing.Size(800, 408)
        Me.Dtglist.TabIndex = 3
        Me.Dtglist.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.Dtglist.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Dtglist.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.Dtglist.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.Dtglist.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Dtglist.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.Dtglist.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.Dtglist.ThemeStyle.HeaderStyle.Height = 21
        Me.Dtglist.ThemeStyle.ReadOnly = True
        Me.Dtglist.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Dtglist.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Dtglist.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Dtglist.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.Dtglist.ThemeStyle.RowsStyle.Height = 22
        Me.Dtglist.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        Me.Dtglist.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'Sel
        '
        Me.Sel.HeaderText = "SEL"
        Me.Sel.Name = "Sel"
        Me.Sel.ReadOnly = True
        Me.Sel.Width = 34
        '
        'EmployeeNo
        '
        Me.EmployeeNo.DataPropertyName = "EmployeeNo"
        Me.EmployeeNo.HeaderText = "EMP NO"
        Me.EmployeeNo.Name = "EmployeeNo"
        Me.EmployeeNo.ReadOnly = True
        Me.EmployeeNo.Width = 85
        '
        'AcctNo
        '
        Me.AcctNo.DataPropertyName = "AcctNo"
        Me.AcctNo.HeaderText = "ACC NO"
        Me.AcctNo.Name = "AcctNo"
        Me.AcctNo.ReadOnly = True
        Me.AcctNo.Width = 84
        '
        'FullName
        '
        Me.FullName.DataPropertyName = "FullName"
        Me.FullName.HeaderText = "FULL NAME"
        Me.FullName.Name = "FullName"
        Me.FullName.ReadOnly = True
        Me.FullName.Width = 106
        '
        'LastName
        '
        Me.LastName.DataPropertyName = "LastName"
        Me.LastName.HeaderText = "LAST NAME"
        Me.LastName.Name = "LastName"
        Me.LastName.ReadOnly = True
        Me.LastName.Width = 105
        '
        'Suffix
        '
        Me.Suffix.DataPropertyName = "Suffix"
        Me.Suffix.HeaderText = "SUFFIX"
        Me.Suffix.Name = "Suffix"
        Me.Suffix.ReadOnly = True
        Me.Suffix.Width = 75
        '
        'Appellation
        '
        Me.Appellation.DataPropertyName = "Appellation"
        Me.Appellation.HeaderText = "APPELLATION"
        Me.Appellation.Name = "Appellation"
        Me.Appellation.ReadOnly = True
        Me.Appellation.Width = 118
        '
        'FirstName
        '
        Me.FirstName.DataPropertyName = "FirstName"
        Me.FirstName.HeaderText = "FIRST NAME"
        Me.FirstName.Name = "FirstName"
        Me.FirstName.ReadOnly = True
        Me.FirstName.Width = 108
        '
        'MiddleName
        '
        Me.MiddleName.DataPropertyName = "MiddleName"
        Me.MiddleName.HeaderText = "MIDDLE NAME"
        Me.MiddleName.Name = "MiddleName"
        Me.MiddleName.ReadOnly = True
        Me.MiddleName.Width = 126
        '
        'BirthDate
        '
        Me.BirthDate.DataPropertyName = "BirthDate"
        Me.BirthDate.HeaderText = "BIRTH DATE"
        Me.BirthDate.Name = "BirthDate"
        Me.BirthDate.ReadOnly = True
        Me.BirthDate.Width = 104
        '
        'Salary
        '
        Me.Salary.DataPropertyName = "Salary"
        Me.Salary.HeaderText = "SALARY"
        Me.Salary.Name = "Salary"
        Me.Salary.ReadOnly = True
        Me.Salary.Width = 80
        '
        'Position
        '
        Me.Position.DataPropertyName = "Position"
        Me.Position.HeaderText = "POSITION"
        Me.Position.Name = "Position"
        Me.Position.ReadOnly = True
        Me.Position.Width = 94
        '
        'Remarks
        '
        Me.Remarks.DataPropertyName = "Remarks"
        Me.Remarks.HeaderText = "REMARKS"
        Me.Remarks.Name = "Remarks"
        Me.Remarks.ReadOnly = True
        Me.Remarks.Width = 92
        '
        'SssNum
        '
        Me.SssNum.DataPropertyName = "SssNum"
        Me.SssNum.HeaderText = "SSS NUM"
        Me.SssNum.Name = "SssNum"
        Me.SssNum.ReadOnly = True
        Me.SssNum.Width = 90
        '
        'HdmfNum
        '
        Me.HdmfNum.DataPropertyName = "HdmfNum"
        Me.HdmfNum.HeaderText = "HDMF NUM"
        Me.HdmfNum.Name = "HdmfNum"
        Me.HdmfNum.ReadOnly = True
        Me.HdmfNum.Width = 109
        '
        'PhicNum
        '
        Me.PhicNum.DataPropertyName = "PhicNum"
        Me.PhicNum.HeaderText = "PHIC NUM"
        Me.PhicNum.Name = "PhicNum"
        Me.PhicNum.ReadOnly = True
        '
        'EditPayrollSelectEmployees
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Dtglist)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(816, 489)
        Me.MinimumSize = New System.Drawing.Size(816, 489)
        Me.Name = "EditPayrollSelectEmployees"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EditPayrollSelectEmployees"
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        CType(Me.Dtglist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BtnAdd As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ChckboxSelectAll As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Dtglist As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents Sel As DataGridViewCheckBoxColumn
    Friend WithEvents EmployeeNo As DataGridViewTextBoxColumn
    Friend WithEvents AcctNo As DataGridViewTextBoxColumn
    Friend WithEvents FullName As DataGridViewTextBoxColumn
    Friend WithEvents LastName As DataGridViewTextBoxColumn
    Friend WithEvents Suffix As DataGridViewTextBoxColumn
    Friend WithEvents Appellation As DataGridViewTextBoxColumn
    Friend WithEvents FirstName As DataGridViewTextBoxColumn
    Friend WithEvents MiddleName As DataGridViewTextBoxColumn
    Friend WithEvents BirthDate As DataGridViewTextBoxColumn
    Friend WithEvents Salary As DataGridViewTextBoxColumn
    Friend WithEvents Position As DataGridViewTextBoxColumn
    Friend WithEvents Remarks As DataGridViewTextBoxColumn
    Friend WithEvents SssNum As DataGridViewTextBoxColumn
    Friend WithEvents HdmfNum As DataGridViewTextBoxColumn
    Friend WithEvents PhicNum As DataGridViewTextBoxColumn
End Class
