﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EditPayroll
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.TxtboxTotalTax = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Tax = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalNetPay = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel22 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalHdmf = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel21 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalPhic = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel20 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalSssEs = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel19 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalSssPs = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel18 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalGrossPay = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel17 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalLeaveWithoutPay = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel16 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalBasic = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel15 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalSalary = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel14 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxTotalRecords = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel13 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.BtnSave = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2GroupBox4 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxTotalNoOfDaysServed = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel8 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxCalendarDays = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.CmboxMonth = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GroupBox3 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxCoverage = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox2 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxRemarks = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2VSeparator1 = New Guna.UI2.WinForms.Guna2VSeparator()
        Me.RemoveRowsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.BtnClearField = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnSelectEmployees = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2GroupBox6 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxTax = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxHdmf = New Guna.UI2.WinForms.Guna2TextBox()
        Me.ChckboxPhic = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.ChckboxSss = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.ChckboxTax = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.ChckboxHdmf = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.TxtboxTardiness = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxAbsences = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel12 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel11 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GroupBox5 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2HtmlLabel10 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxAdjustmentSub = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel9 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxAdjustmentAdd = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxPayrollNo = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxCreatedBy = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxPeriod = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxPayrollTitle = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxPayrollType = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Dtglist = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.Guna2Panel1.SuspendLayout()
        Me.Guna2GroupBox4.SuspendLayout()
        Me.Guna2GroupBox3.SuspendLayout()
        Me.Guna2GroupBox2.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.Guna2GroupBox6.SuspendLayout()
        Me.Guna2GroupBox5.SuspendLayout()
        Me.Guna2GroupBox1.SuspendLayout()
        CType(Me.Dtglist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel1.BorderThickness = 1
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalTax)
        Me.Guna2Panel1.Controls.Add(Me.Tax)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalNetPay)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel22)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalHdmf)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel21)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalPhic)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel20)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalSssEs)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel19)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalSssPs)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel18)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalGrossPay)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel17)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalLeaveWithoutPay)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel16)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalBasic)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel15)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalSalary)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel14)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxTotalRecords)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel13)
        Me.Guna2Panel1.Controls.Add(Me.BtnSave)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 603)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(1350, 126)
        Me.Guna2Panel1.TabIndex = 28
        '
        'TxtboxTotalTax
        '
        Me.TxtboxTotalTax.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalTax.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalTax.DefaultText = ""
        Me.TxtboxTotalTax.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalTax.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalTax.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalTax.DisabledState.Parent = Me.TxtboxTotalTax
        Me.TxtboxTotalTax.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalTax.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalTax.FocusedState.Parent = Me.TxtboxTotalTax
        Me.TxtboxTotalTax.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalTax.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalTax.HoverState.Parent = Me.TxtboxTotalTax
        Me.TxtboxTotalTax.Location = New System.Drawing.Point(902, 13)
        Me.TxtboxTotalTax.Name = "TxtboxTotalTax"
        Me.TxtboxTotalTax.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalTax.PlaceholderText = ""
        Me.TxtboxTotalTax.ReadOnly = True
        Me.TxtboxTotalTax.SelectedText = ""
        Me.TxtboxTotalTax.ShadowDecoration.Parent = Me.TxtboxTotalTax
        Me.TxtboxTotalTax.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalTax.TabIndex = 27
        Me.TxtboxTotalTax.TabStop = False
        '
        'Tax
        '
        Me.Tax.BackColor = System.Drawing.Color.Transparent
        Me.Tax.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tax.Location = New System.Drawing.Point(875, 16)
        Me.Tax.Name = "Tax"
        Me.Tax.Size = New System.Drawing.Size(21, 17)
        Me.Tax.TabIndex = 26
        Me.Tax.TabStop = False
        Me.Tax.Text = "Tax"
        '
        'TxtboxTotalNetPay
        '
        Me.TxtboxTotalNetPay.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalNetPay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalNetPay.DefaultText = ""
        Me.TxtboxTotalNetPay.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalNetPay.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalNetPay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalNetPay.DisabledState.Parent = Me.TxtboxTotalNetPay
        Me.TxtboxTotalNetPay.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalNetPay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalNetPay.FocusedState.Parent = Me.TxtboxTotalNetPay
        Me.TxtboxTotalNetPay.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalNetPay.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalNetPay.HoverState.Parent = Me.TxtboxTotalNetPay
        Me.TxtboxTotalNetPay.Location = New System.Drawing.Point(902, 39)
        Me.TxtboxTotalNetPay.Name = "TxtboxTotalNetPay"
        Me.TxtboxTotalNetPay.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalNetPay.PlaceholderText = ""
        Me.TxtboxTotalNetPay.ReadOnly = True
        Me.TxtboxTotalNetPay.SelectedText = ""
        Me.TxtboxTotalNetPay.ShadowDecoration.Parent = Me.TxtboxTotalNetPay
        Me.TxtboxTotalNetPay.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalNetPay.TabIndex = 20
        Me.TxtboxTotalNetPay.TabStop = False
        '
        'Guna2HtmlLabel22
        '
        Me.Guna2HtmlLabel22.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel22.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel22.Location = New System.Drawing.Point(852, 42)
        Me.Guna2HtmlLabel22.Name = "Guna2HtmlLabel22"
        Me.Guna2HtmlLabel22.Size = New System.Drawing.Size(44, 17)
        Me.Guna2HtmlLabel22.TabIndex = 19
        Me.Guna2HtmlLabel22.TabStop = False
        Me.Guna2HtmlLabel22.Text = "Net pay"
        '
        'TxtboxTotalHdmf
        '
        Me.TxtboxTotalHdmf.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalHdmf.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalHdmf.DefaultText = ""
        Me.TxtboxTotalHdmf.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalHdmf.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalHdmf.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalHdmf.DisabledState.Parent = Me.TxtboxTotalHdmf
        Me.TxtboxTotalHdmf.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalHdmf.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalHdmf.FocusedState.Parent = Me.TxtboxTotalHdmf
        Me.TxtboxTotalHdmf.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalHdmf.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalHdmf.HoverState.Parent = Me.TxtboxTotalHdmf
        Me.TxtboxTotalHdmf.Location = New System.Drawing.Point(695, 91)
        Me.TxtboxTotalHdmf.Name = "TxtboxTotalHdmf"
        Me.TxtboxTotalHdmf.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalHdmf.PlaceholderText = ""
        Me.TxtboxTotalHdmf.ReadOnly = True
        Me.TxtboxTotalHdmf.SelectedText = ""
        Me.TxtboxTotalHdmf.ShadowDecoration.Parent = Me.TxtboxTotalHdmf
        Me.TxtboxTotalHdmf.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalHdmf.TabIndex = 18
        Me.TxtboxTotalHdmf.TabStop = False
        '
        'Guna2HtmlLabel21
        '
        Me.Guna2HtmlLabel21.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel21.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel21.Location = New System.Drawing.Point(652, 94)
        Me.Guna2HtmlLabel21.Name = "Guna2HtmlLabel21"
        Me.Guna2HtmlLabel21.Size = New System.Drawing.Size(37, 17)
        Me.Guna2HtmlLabel21.TabIndex = 17
        Me.Guna2HtmlLabel21.TabStop = False
        Me.Guna2HtmlLabel21.Text = "HDMF"
        '
        'TxtboxTotalPhic
        '
        Me.TxtboxTotalPhic.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalPhic.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalPhic.DefaultText = ""
        Me.TxtboxTotalPhic.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalPhic.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalPhic.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalPhic.DisabledState.Parent = Me.TxtboxTotalPhic
        Me.TxtboxTotalPhic.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalPhic.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalPhic.FocusedState.Parent = Me.TxtboxTotalPhic
        Me.TxtboxTotalPhic.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalPhic.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalPhic.HoverState.Parent = Me.TxtboxTotalPhic
        Me.TxtboxTotalPhic.Location = New System.Drawing.Point(695, 65)
        Me.TxtboxTotalPhic.Name = "TxtboxTotalPhic"
        Me.TxtboxTotalPhic.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalPhic.PlaceholderText = ""
        Me.TxtboxTotalPhic.ReadOnly = True
        Me.TxtboxTotalPhic.SelectedText = ""
        Me.TxtboxTotalPhic.ShadowDecoration.Parent = Me.TxtboxTotalPhic
        Me.TxtboxTotalPhic.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalPhic.TabIndex = 16
        Me.TxtboxTotalPhic.TabStop = False
        '
        'Guna2HtmlLabel20
        '
        Me.Guna2HtmlLabel20.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel20.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel20.Location = New System.Drawing.Point(659, 68)
        Me.Guna2HtmlLabel20.Name = "Guna2HtmlLabel20"
        Me.Guna2HtmlLabel20.Size = New System.Drawing.Size(30, 17)
        Me.Guna2HtmlLabel20.TabIndex = 15
        Me.Guna2HtmlLabel20.TabStop = False
        Me.Guna2HtmlLabel20.Text = "PHIC"
        '
        'TxtboxTotalSssEs
        '
        Me.TxtboxTotalSssEs.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalSssEs.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalSssEs.DefaultText = ""
        Me.TxtboxTotalSssEs.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalSssEs.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalSssEs.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSssEs.DisabledState.Parent = Me.TxtboxTotalSssEs
        Me.TxtboxTotalSssEs.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSssEs.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSssEs.FocusedState.Parent = Me.TxtboxTotalSssEs
        Me.TxtboxTotalSssEs.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalSssEs.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSssEs.HoverState.Parent = Me.TxtboxTotalSssEs
        Me.TxtboxTotalSssEs.Location = New System.Drawing.Point(695, 39)
        Me.TxtboxTotalSssEs.Name = "TxtboxTotalSssEs"
        Me.TxtboxTotalSssEs.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalSssEs.PlaceholderText = ""
        Me.TxtboxTotalSssEs.ReadOnly = True
        Me.TxtboxTotalSssEs.SelectedText = ""
        Me.TxtboxTotalSssEs.ShadowDecoration.Parent = Me.TxtboxTotalSssEs
        Me.TxtboxTotalSssEs.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalSssEs.TabIndex = 14
        Me.TxtboxTotalSssEs.TabStop = False
        '
        'Guna2HtmlLabel19
        '
        Me.Guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel19.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel19.Location = New System.Drawing.Point(653, 42)
        Me.Guna2HtmlLabel19.Name = "Guna2HtmlLabel19"
        Me.Guna2HtmlLabel19.Size = New System.Drawing.Size(36, 17)
        Me.Guna2HtmlLabel19.TabIndex = 13
        Me.Guna2HtmlLabel19.TabStop = False
        Me.Guna2HtmlLabel19.Text = "SSS ES"
        '
        'TxtboxTotalSssPs
        '
        Me.TxtboxTotalSssPs.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalSssPs.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalSssPs.DefaultText = ""
        Me.TxtboxTotalSssPs.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalSssPs.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalSssPs.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSssPs.DisabledState.Parent = Me.TxtboxTotalSssPs
        Me.TxtboxTotalSssPs.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSssPs.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSssPs.FocusedState.Parent = Me.TxtboxTotalSssPs
        Me.TxtboxTotalSssPs.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalSssPs.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSssPs.HoverState.Parent = Me.TxtboxTotalSssPs
        Me.TxtboxTotalSssPs.Location = New System.Drawing.Point(695, 13)
        Me.TxtboxTotalSssPs.Name = "TxtboxTotalSssPs"
        Me.TxtboxTotalSssPs.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalSssPs.PlaceholderText = ""
        Me.TxtboxTotalSssPs.ReadOnly = True
        Me.TxtboxTotalSssPs.SelectedText = ""
        Me.TxtboxTotalSssPs.ShadowDecoration.Parent = Me.TxtboxTotalSssPs
        Me.TxtboxTotalSssPs.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalSssPs.TabIndex = 12
        Me.TxtboxTotalSssPs.TabStop = False
        '
        'Guna2HtmlLabel18
        '
        Me.Guna2HtmlLabel18.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel18.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel18.Location = New System.Drawing.Point(652, 16)
        Me.Guna2HtmlLabel18.Name = "Guna2HtmlLabel18"
        Me.Guna2HtmlLabel18.Size = New System.Drawing.Size(37, 17)
        Me.Guna2HtmlLabel18.TabIndex = 11
        Me.Guna2HtmlLabel18.TabStop = False
        Me.Guna2HtmlLabel18.Text = "SSS PS"
        '
        'TxtboxTotalGrossPay
        '
        Me.TxtboxTotalGrossPay.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalGrossPay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalGrossPay.DefaultText = ""
        Me.TxtboxTotalGrossPay.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalGrossPay.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalGrossPay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalGrossPay.DisabledState.Parent = Me.TxtboxTotalGrossPay
        Me.TxtboxTotalGrossPay.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalGrossPay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalGrossPay.FocusedState.Parent = Me.TxtboxTotalGrossPay
        Me.TxtboxTotalGrossPay.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalGrossPay.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalGrossPay.HoverState.Parent = Me.TxtboxTotalGrossPay
        Me.TxtboxTotalGrossPay.Location = New System.Drawing.Point(517, 39)
        Me.TxtboxTotalGrossPay.Name = "TxtboxTotalGrossPay"
        Me.TxtboxTotalGrossPay.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalGrossPay.PlaceholderText = ""
        Me.TxtboxTotalGrossPay.ReadOnly = True
        Me.TxtboxTotalGrossPay.SelectedText = ""
        Me.TxtboxTotalGrossPay.ShadowDecoration.Parent = Me.TxtboxTotalGrossPay
        Me.TxtboxTotalGrossPay.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalGrossPay.TabIndex = 10
        Me.TxtboxTotalGrossPay.TabStop = False
        '
        'Guna2HtmlLabel17
        '
        Me.Guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel17.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel17.Location = New System.Drawing.Point(457, 42)
        Me.Guna2HtmlLabel17.Name = "Guna2HtmlLabel17"
        Me.Guna2HtmlLabel17.Size = New System.Drawing.Size(54, 17)
        Me.Guna2HtmlLabel17.TabIndex = 9
        Me.Guna2HtmlLabel17.TabStop = False
        Me.Guna2HtmlLabel17.Text = "Gross pay"
        '
        'TxtboxTotalLeaveWithoutPay
        '
        Me.TxtboxTotalLeaveWithoutPay.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalLeaveWithoutPay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalLeaveWithoutPay.DefaultText = ""
        Me.TxtboxTotalLeaveWithoutPay.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalLeaveWithoutPay.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalLeaveWithoutPay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalLeaveWithoutPay.DisabledState.Parent = Me.TxtboxTotalLeaveWithoutPay
        Me.TxtboxTotalLeaveWithoutPay.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalLeaveWithoutPay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalLeaveWithoutPay.FocusedState.Parent = Me.TxtboxTotalLeaveWithoutPay
        Me.TxtboxTotalLeaveWithoutPay.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalLeaveWithoutPay.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalLeaveWithoutPay.HoverState.Parent = Me.TxtboxTotalLeaveWithoutPay
        Me.TxtboxTotalLeaveWithoutPay.Location = New System.Drawing.Point(517, 13)
        Me.TxtboxTotalLeaveWithoutPay.Name = "TxtboxTotalLeaveWithoutPay"
        Me.TxtboxTotalLeaveWithoutPay.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalLeaveWithoutPay.PlaceholderText = ""
        Me.TxtboxTotalLeaveWithoutPay.ReadOnly = True
        Me.TxtboxTotalLeaveWithoutPay.SelectedText = ""
        Me.TxtboxTotalLeaveWithoutPay.ShadowDecoration.Parent = Me.TxtboxTotalLeaveWithoutPay
        Me.TxtboxTotalLeaveWithoutPay.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalLeaveWithoutPay.TabIndex = 8
        Me.TxtboxTotalLeaveWithoutPay.TabStop = False
        '
        'Guna2HtmlLabel16
        '
        Me.Guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel16.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel16.Location = New System.Drawing.Point(412, 16)
        Me.Guna2HtmlLabel16.Name = "Guna2HtmlLabel16"
        Me.Guna2HtmlLabel16.Size = New System.Drawing.Size(99, 17)
        Me.Guna2HtmlLabel16.TabIndex = 7
        Me.Guna2HtmlLabel16.TabStop = False
        Me.Guna2HtmlLabel16.Text = "Leave without pay"
        '
        'TxtboxTotalBasic
        '
        Me.TxtboxTotalBasic.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalBasic.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalBasic.DefaultText = ""
        Me.TxtboxTotalBasic.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalBasic.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalBasic.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalBasic.DisabledState.Parent = Me.TxtboxTotalBasic
        Me.TxtboxTotalBasic.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalBasic.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalBasic.FocusedState.Parent = Me.TxtboxTotalBasic
        Me.TxtboxTotalBasic.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalBasic.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalBasic.HoverState.Parent = Me.TxtboxTotalBasic
        Me.TxtboxTotalBasic.Location = New System.Drawing.Point(278, 39)
        Me.TxtboxTotalBasic.Name = "TxtboxTotalBasic"
        Me.TxtboxTotalBasic.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalBasic.PlaceholderText = ""
        Me.TxtboxTotalBasic.ReadOnly = True
        Me.TxtboxTotalBasic.SelectedText = ""
        Me.TxtboxTotalBasic.ShadowDecoration.Parent = Me.TxtboxTotalBasic
        Me.TxtboxTotalBasic.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalBasic.TabIndex = 6
        Me.TxtboxTotalBasic.TabStop = False
        '
        'Guna2HtmlLabel15
        '
        Me.Guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel15.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel15.Location = New System.Drawing.Point(242, 42)
        Me.Guna2HtmlLabel15.Name = "Guna2HtmlLabel15"
        Me.Guna2HtmlLabel15.Size = New System.Drawing.Size(30, 17)
        Me.Guna2HtmlLabel15.TabIndex = 5
        Me.Guna2HtmlLabel15.TabStop = False
        Me.Guna2HtmlLabel15.Text = "Basic"
        '
        'TxtboxTotalSalary
        '
        Me.TxtboxTotalSalary.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalSalary.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalSalary.DefaultText = ""
        Me.TxtboxTotalSalary.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalSalary.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalSalary.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSalary.DisabledState.Parent = Me.TxtboxTotalSalary
        Me.TxtboxTotalSalary.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalSalary.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSalary.FocusedState.Parent = Me.TxtboxTotalSalary
        Me.TxtboxTotalSalary.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalSalary.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalSalary.HoverState.Parent = Me.TxtboxTotalSalary
        Me.TxtboxTotalSalary.Location = New System.Drawing.Point(278, 13)
        Me.TxtboxTotalSalary.Name = "TxtboxTotalSalary"
        Me.TxtboxTotalSalary.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalSalary.PlaceholderText = ""
        Me.TxtboxTotalSalary.ReadOnly = True
        Me.TxtboxTotalSalary.SelectedText = ""
        Me.TxtboxTotalSalary.ShadowDecoration.Parent = Me.TxtboxTotalSalary
        Me.TxtboxTotalSalary.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalSalary.TabIndex = 4
        Me.TxtboxTotalSalary.TabStop = False
        '
        'Guna2HtmlLabel14
        '
        Me.Guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel14.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel14.Location = New System.Drawing.Point(238, 16)
        Me.Guna2HtmlLabel14.Name = "Guna2HtmlLabel14"
        Me.Guna2HtmlLabel14.Size = New System.Drawing.Size(34, 17)
        Me.Guna2HtmlLabel14.TabIndex = 3
        Me.Guna2HtmlLabel14.TabStop = False
        Me.Guna2HtmlLabel14.Text = "Salary"
        '
        'TxtboxTotalRecords
        '
        Me.TxtboxTotalRecords.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalRecords.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalRecords.DefaultText = ""
        Me.TxtboxTotalRecords.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalRecords.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalRecords.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalRecords.DisabledState.Parent = Me.TxtboxTotalRecords
        Me.TxtboxTotalRecords.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalRecords.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalRecords.FocusedState.Parent = Me.TxtboxTotalRecords
        Me.TxtboxTotalRecords.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalRecords.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalRecords.HoverState.Parent = Me.TxtboxTotalRecords
        Me.TxtboxTotalRecords.Location = New System.Drawing.Point(97, 13)
        Me.TxtboxTotalRecords.Name = "TxtboxTotalRecords"
        Me.TxtboxTotalRecords.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalRecords.PlaceholderText = ""
        Me.TxtboxTotalRecords.ReadOnly = True
        Me.TxtboxTotalRecords.SelectedText = ""
        Me.TxtboxTotalRecords.ShadowDecoration.Parent = Me.TxtboxTotalRecords
        Me.TxtboxTotalRecords.Size = New System.Drawing.Size(120, 20)
        Me.TxtboxTotalRecords.TabIndex = 2
        Me.TxtboxTotalRecords.TabStop = False
        '
        'Guna2HtmlLabel13
        '
        Me.Guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel13.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel13.Location = New System.Drawing.Point(12, 16)
        Me.Guna2HtmlLabel13.Name = "Guna2HtmlLabel13"
        Me.Guna2HtmlLabel13.Size = New System.Drawing.Size(79, 17)
        Me.Guna2HtmlLabel13.TabIndex = 1
        Me.Guna2HtmlLabel13.TabStop = False
        Me.Guna2HtmlLabel13.Text = "Total record(s)"
        '
        'BtnSave
        '
        Me.BtnSave.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSave.BorderThickness = 1
        Me.BtnSave.CheckedState.Parent = Me.BtnSave
        Me.BtnSave.CustomImages.Parent = Me.BtnSave
        Me.BtnSave.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSave.ForeColor = System.Drawing.Color.White
        Me.BtnSave.HoverState.Parent = Me.BtnSave
        Me.BtnSave.Location = New System.Drawing.Point(1158, 16)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.ShadowDecoration.Parent = Me.BtnSave
        Me.BtnSave.Size = New System.Drawing.Size(180, 45)
        Me.BtnSave.TabIndex = 25
        Me.BtnSave.Text = "SAVE"
        '
        'Guna2GroupBox4
        '
        Me.Guna2GroupBox4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox4.Controls.Add(Me.TxtboxTotalNoOfDaysServed)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2HtmlLabel8)
        Me.Guna2GroupBox4.Controls.Add(Me.TxtboxCalendarDays)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2HtmlLabel7)
        Me.Guna2GroupBox4.Controls.Add(Me.CmboxMonth)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Guna2GroupBox4.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox4.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox4.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox4.Location = New System.Drawing.Point(486, 30)
        Me.Guna2GroupBox4.Name = "Guna2GroupBox4"
        Me.Guna2GroupBox4.ShadowDecoration.Parent = Me.Guna2GroupBox4
        Me.Guna2GroupBox4.Size = New System.Drawing.Size(250, 154)
        Me.Guna2GroupBox4.TabIndex = 7
        Me.Guna2GroupBox4.Text = "BASIC PAY"
        Me.Guna2GroupBox4.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxTotalNoOfDaysServed
        '
        Me.TxtboxTotalNoOfDaysServed.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTotalNoOfDaysServed.DefaultText = ""
        Me.TxtboxTotalNoOfDaysServed.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.DisabledState.Parent = Me.TxtboxTotalNoOfDaysServed
        Me.TxtboxTotalNoOfDaysServed.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.FocusedState.Parent = Me.TxtboxTotalNoOfDaysServed
        Me.TxtboxTotalNoOfDaysServed.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTotalNoOfDaysServed.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTotalNoOfDaysServed.HoverState.Parent = Me.TxtboxTotalNoOfDaysServed
        Me.TxtboxTotalNoOfDaysServed.Location = New System.Drawing.Point(172, 81)
        Me.TxtboxTotalNoOfDaysServed.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxTotalNoOfDaysServed.Name = "TxtboxTotalNoOfDaysServed"
        Me.TxtboxTotalNoOfDaysServed.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTotalNoOfDaysServed.PlaceholderText = ""
        Me.TxtboxTotalNoOfDaysServed.SelectedText = ""
        Me.TxtboxTotalNoOfDaysServed.ShadowDecoration.Parent = Me.TxtboxTotalNoOfDaysServed
        Me.TxtboxTotalNoOfDaysServed.Size = New System.Drawing.Size(65, 20)
        Me.TxtboxTotalNoOfDaysServed.TabIndex = 10
        '
        'Guna2HtmlLabel8
        '
        Me.Guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel8.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel8.Location = New System.Drawing.Point(14, 84)
        Me.Guna2HtmlLabel8.Name = "Guna2HtmlLabel8"
        Me.Guna2HtmlLabel8.Size = New System.Drawing.Size(153, 15)
        Me.Guna2HtmlLabel8.TabIndex = 5
        Me.Guna2HtmlLabel8.TabStop = False
        Me.Guna2HtmlLabel8.Text = "TOTAL NO OF DAYS SERVED"
        '
        'TxtboxCalendarDays
        '
        Me.TxtboxCalendarDays.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxCalendarDays.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxCalendarDays.DefaultText = ""
        Me.TxtboxCalendarDays.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxCalendarDays.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxCalendarDays.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCalendarDays.DisabledState.Parent = Me.TxtboxCalendarDays
        Me.TxtboxCalendarDays.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCalendarDays.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCalendarDays.FocusedState.Parent = Me.TxtboxCalendarDays
        Me.TxtboxCalendarDays.ForeColor = System.Drawing.Color.Black
        Me.TxtboxCalendarDays.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCalendarDays.HoverState.Parent = Me.TxtboxCalendarDays
        Me.TxtboxCalendarDays.Location = New System.Drawing.Point(172, 56)
        Me.TxtboxCalendarDays.Margin = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.TxtboxCalendarDays.Name = "TxtboxCalendarDays"
        Me.TxtboxCalendarDays.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxCalendarDays.PlaceholderText = ""
        Me.TxtboxCalendarDays.SelectedText = ""
        Me.TxtboxCalendarDays.ShadowDecoration.Parent = Me.TxtboxCalendarDays
        Me.TxtboxCalendarDays.Size = New System.Drawing.Size(65, 20)
        Me.TxtboxCalendarDays.TabIndex = 9
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(71, 61)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(93, 15)
        Me.Guna2HtmlLabel7.TabIndex = 2
        Me.Guna2HtmlLabel7.TabStop = False
        Me.Guna2HtmlLabel7.Text = "CALENDAR DAYS"
        '
        'CmboxMonth
        '
        Me.CmboxMonth.BackColor = System.Drawing.Color.Transparent
        Me.CmboxMonth.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.CmboxMonth.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxMonth.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxMonth.FocusedState.Parent = Me.CmboxMonth
        Me.CmboxMonth.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxMonth.ForeColor = System.Drawing.Color.Black
        Me.CmboxMonth.FormattingEnabled = True
        Me.CmboxMonth.HoverState.Parent = Me.CmboxMonth
        Me.CmboxMonth.ItemHeight = 15
        Me.CmboxMonth.Items.AddRange(New Object() {"1.0", "0.5"})
        Me.CmboxMonth.ItemsAppearance.Parent = Me.CmboxMonth
        Me.CmboxMonth.Location = New System.Drawing.Point(172, 29)
        Me.CmboxMonth.Name = "CmboxMonth"
        Me.CmboxMonth.ShadowDecoration.Parent = Me.CmboxMonth
        Me.CmboxMonth.Size = New System.Drawing.Size(65, 21)
        Me.CmboxMonth.TabIndex = 8
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(123, 35)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(43, 15)
        Me.Guna2HtmlLabel6.TabIndex = 0
        Me.Guna2HtmlLabel6.TabStop = False
        Me.Guna2HtmlLabel6.Text = "MONTH"
        '
        'Guna2GroupBox3
        '
        Me.Guna2GroupBox3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox3.Controls.Add(Me.TxtboxCoverage)
        Me.Guna2GroupBox3.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox3.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox3.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox3.Location = New System.Drawing.Point(290, 86)
        Me.Guna2GroupBox3.Name = "Guna2GroupBox3"
        Me.Guna2GroupBox3.ShadowDecoration.Parent = Me.Guna2GroupBox3
        Me.Guna2GroupBox3.Size = New System.Drawing.Size(190, 50)
        Me.Guna2GroupBox3.TabIndex = 5
        Me.Guna2GroupBox3.Text = "COVERAGE"
        Me.Guna2GroupBox3.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxCoverage
        '
        Me.TxtboxCoverage.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxCoverage.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxCoverage.DefaultText = ""
        Me.TxtboxCoverage.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxCoverage.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxCoverage.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCoverage.DisabledState.Parent = Me.TxtboxCoverage
        Me.TxtboxCoverage.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCoverage.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCoverage.FocusedState.Parent = Me.TxtboxCoverage
        Me.TxtboxCoverage.ForeColor = System.Drawing.Color.Black
        Me.TxtboxCoverage.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCoverage.HoverState.Parent = Me.TxtboxCoverage
        Me.TxtboxCoverage.Location = New System.Drawing.Point(5, 23)
        Me.TxtboxCoverage.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxCoverage.Name = "TxtboxCoverage"
        Me.TxtboxCoverage.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxCoverage.PlaceholderText = ""
        Me.TxtboxCoverage.SelectedText = ""
        Me.TxtboxCoverage.ShadowDecoration.Parent = Me.TxtboxCoverage
        Me.TxtboxCoverage.Size = New System.Drawing.Size(180, 20)
        Me.TxtboxCoverage.TabIndex = 6
        '
        'Guna2GroupBox2
        '
        Me.Guna2GroupBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox2.Controls.Add(Me.TxtboxRemarks)
        Me.Guna2GroupBox2.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox2.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox2.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox2.Location = New System.Drawing.Point(290, 30)
        Me.Guna2GroupBox2.Name = "Guna2GroupBox2"
        Me.Guna2GroupBox2.ShadowDecoration.Parent = Me.Guna2GroupBox2
        Me.Guna2GroupBox2.Size = New System.Drawing.Size(190, 50)
        Me.Guna2GroupBox2.TabIndex = 3
        Me.Guna2GroupBox2.Text = "REMARKS"
        Me.Guna2GroupBox2.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxRemarks
        '
        Me.TxtboxRemarks.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxRemarks.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxRemarks.DefaultText = ""
        Me.TxtboxRemarks.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxRemarks.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxRemarks.FocusedState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.ForeColor = System.Drawing.Color.Black
        Me.TxtboxRemarks.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxRemarks.HoverState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.Location = New System.Drawing.Point(5, 23)
        Me.TxtboxRemarks.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxRemarks.Name = "TxtboxRemarks"
        Me.TxtboxRemarks.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxRemarks.PlaceholderText = ""
        Me.TxtboxRemarks.SelectedText = ""
        Me.TxtboxRemarks.ShadowDecoration.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.Size = New System.Drawing.Size(180, 20)
        Me.TxtboxRemarks.TabIndex = 4
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(4, 167)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(87, 15)
        Me.Guna2HtmlLabel5.TabIndex = 9
        Me.Guna2HtmlLabel5.TabStop = False
        Me.Guna2HtmlLabel5.Text = "To be created by:"
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(23, 141)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(71, 15)
        Me.Guna2HtmlLabel4.TabIndex = 7
        Me.Guna2HtmlLabel4.TabStop = False
        Me.Guna2HtmlLabel4.Text = "PAYROLL NO"
        '
        'Guna2VSeparator1
        '
        Me.Guna2VSeparator1.BackColor = System.Drawing.Color.White
        Me.Guna2VSeparator1.Location = New System.Drawing.Point(994, 53)
        Me.Guna2VSeparator1.Name = "Guna2VSeparator1"
        Me.Guna2VSeparator1.Size = New System.Drawing.Size(10, 128)
        Me.Guna2VSeparator1.TabIndex = 26
        '
        'RemoveRowsToolStripMenuItem
        '
        Me.RemoveRowsToolStripMenuItem.Name = "RemoveRowsToolStripMenuItem"
        Me.RemoveRowsToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.RemoveRowsToolStripMenuItem.Text = "Remove rows"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RemoveRowsToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(146, 26)
        '
        'BtnClearField
        '
        Me.BtnClearField.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnClearField.BorderThickness = 1
        Me.BtnClearField.CheckedState.Parent = Me.BtnClearField
        Me.BtnClearField.CustomImages.Parent = Me.BtnClearField
        Me.BtnClearField.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnClearField.ForeColor = System.Drawing.Color.White
        Me.BtnClearField.HoverState.Parent = Me.BtnClearField
        Me.BtnClearField.Location = New System.Drawing.Point(1203, 154)
        Me.BtnClearField.Name = "BtnClearField"
        Me.BtnClearField.ShadowDecoration.Parent = Me.BtnClearField
        Me.BtnClearField.Size = New System.Drawing.Size(135, 30)
        Me.BtnClearField.TabIndex = 26
        Me.BtnClearField.Text = "CLEAR FIELD"
        '
        'BtnSelectEmployees
        '
        Me.BtnSelectEmployees.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSelectEmployees.BorderThickness = 1
        Me.BtnSelectEmployees.CheckedState.Parent = Me.BtnSelectEmployees
        Me.BtnSelectEmployees.CustomImages.Parent = Me.BtnSelectEmployees
        Me.BtnSelectEmployees.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSelectEmployees.ForeColor = System.Drawing.Color.White
        Me.BtnSelectEmployees.HoverState.Parent = Me.BtnSelectEmployees
        Me.BtnSelectEmployees.Location = New System.Drawing.Point(1203, 30)
        Me.BtnSelectEmployees.Name = "BtnSelectEmployees"
        Me.BtnSelectEmployees.ShadowDecoration.Parent = Me.BtnSelectEmployees
        Me.BtnSelectEmployees.Size = New System.Drawing.Size(135, 30)
        Me.BtnSelectEmployees.TabIndex = 23
        Me.BtnSelectEmployees.Text = "SELECT EMPLOYEES"
        '
        'Guna2GroupBox6
        '
        Me.Guna2GroupBox6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox6.Controls.Add(Me.TxtboxTax)
        Me.Guna2GroupBox6.Controls.Add(Me.TxtboxHdmf)
        Me.Guna2GroupBox6.Controls.Add(Me.ChckboxPhic)
        Me.Guna2GroupBox6.Controls.Add(Me.ChckboxSss)
        Me.Guna2GroupBox6.Controls.Add(Me.ChckboxTax)
        Me.Guna2GroupBox6.Controls.Add(Me.ChckboxHdmf)
        Me.Guna2GroupBox6.Controls.Add(Me.TxtboxTardiness)
        Me.Guna2GroupBox6.Controls.Add(Me.TxtboxAbsences)
        Me.Guna2GroupBox6.Controls.Add(Me.Guna2HtmlLabel12)
        Me.Guna2GroupBox6.Controls.Add(Me.Guna2HtmlLabel11)
        Me.Guna2GroupBox6.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox6.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox6.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox6.Location = New System.Drawing.Point(850, 30)
        Me.Guna2GroupBox6.Name = "Guna2GroupBox6"
        Me.Guna2GroupBox6.ShadowDecoration.Parent = Me.Guna2GroupBox6
        Me.Guna2GroupBox6.Size = New System.Drawing.Size(344, 154)
        Me.Guna2GroupBox6.TabIndex = 14
        Me.Guna2GroupBox6.Text = "DEDUCTIONS"
        Me.Guna2GroupBox6.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxTax
        '
        Me.TxtboxTax.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTax.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTax.DefaultText = ""
        Me.TxtboxTax.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTax.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTax.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTax.DisabledState.Parent = Me.TxtboxTax
        Me.TxtboxTax.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTax.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTax.FocusedState.Parent = Me.TxtboxTax
        Me.TxtboxTax.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTax.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTax.HoverState.Parent = Me.TxtboxTax
        Me.TxtboxTax.Location = New System.Drawing.Point(166, 55)
        Me.TxtboxTax.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.TxtboxTax.Name = "TxtboxTax"
        Me.TxtboxTax.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTax.PlaceholderText = ""
        Me.TxtboxTax.SelectedText = ""
        Me.TxtboxTax.ShadowDecoration.Parent = Me.TxtboxTax
        Me.TxtboxTax.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxTax.TabIndex = 20
        '
        'TxtboxHdmf
        '
        Me.TxtboxHdmf.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxHdmf.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxHdmf.DefaultText = ""
        Me.TxtboxHdmf.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxHdmf.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxHdmf.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxHdmf.DisabledState.Parent = Me.TxtboxHdmf
        Me.TxtboxHdmf.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxHdmf.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxHdmf.FocusedState.Parent = Me.TxtboxHdmf
        Me.TxtboxHdmf.ForeColor = System.Drawing.Color.Black
        Me.TxtboxHdmf.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxHdmf.HoverState.Parent = Me.TxtboxHdmf
        Me.TxtboxHdmf.Location = New System.Drawing.Point(166, 29)
        Me.TxtboxHdmf.Margin = New System.Windows.Forms.Padding(9, 3, 9, 3)
        Me.TxtboxHdmf.Name = "TxtboxHdmf"
        Me.TxtboxHdmf.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxHdmf.PlaceholderText = ""
        Me.TxtboxHdmf.SelectedText = ""
        Me.TxtboxHdmf.ShadowDecoration.Parent = Me.TxtboxHdmf
        Me.TxtboxHdmf.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxHdmf.TabIndex = 18
        '
        'ChckboxPhic
        '
        Me.ChckboxPhic.AutoSize = True
        Me.ChckboxPhic.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxPhic.CheckedState.BorderRadius = 2
        Me.ChckboxPhic.CheckedState.BorderThickness = 0
        Me.ChckboxPhic.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxPhic.ForeColor = System.Drawing.Color.Black
        Me.ChckboxPhic.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChckboxPhic.Location = New System.Drawing.Point(228, 109)
        Me.ChckboxPhic.Name = "ChckboxPhic"
        Me.ChckboxPhic.Size = New System.Drawing.Size(53, 19)
        Me.ChckboxPhic.TabIndex = 22
        Me.ChckboxPhic.Text = "PHIC"
        Me.ChckboxPhic.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxPhic.UncheckedState.BorderRadius = 2
        Me.ChckboxPhic.UncheckedState.BorderThickness = 0
        Me.ChckboxPhic.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxPhic.UseVisualStyleBackColor = True
        '
        'ChckboxSss
        '
        Me.ChckboxSss.AutoSize = True
        Me.ChckboxSss.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxSss.CheckedState.BorderRadius = 2
        Me.ChckboxSss.CheckedState.BorderThickness = 0
        Me.ChckboxSss.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxSss.ForeColor = System.Drawing.Color.Black
        Me.ChckboxSss.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChckboxSss.Location = New System.Drawing.Point(228, 83)
        Me.ChckboxSss.Name = "ChckboxSss"
        Me.ChckboxSss.Size = New System.Drawing.Size(44, 19)
        Me.ChckboxSss.TabIndex = 21
        Me.ChckboxSss.Text = "SSS"
        Me.ChckboxSss.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxSss.UncheckedState.BorderRadius = 2
        Me.ChckboxSss.UncheckedState.BorderThickness = 0
        Me.ChckboxSss.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxSss.UseVisualStyleBackColor = True
        '
        'ChckboxTax
        '
        Me.ChckboxTax.AutoSize = True
        Me.ChckboxTax.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxTax.CheckedState.BorderRadius = 2
        Me.ChckboxTax.CheckedState.BorderThickness = 0
        Me.ChckboxTax.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxTax.ForeColor = System.Drawing.Color.Black
        Me.ChckboxTax.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChckboxTax.Location = New System.Drawing.Point(228, 56)
        Me.ChckboxTax.Name = "ChckboxTax"
        Me.ChckboxTax.Size = New System.Drawing.Size(46, 19)
        Me.ChckboxTax.TabIndex = 19
        Me.ChckboxTax.Text = "TAX"
        Me.ChckboxTax.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxTax.UncheckedState.BorderRadius = 2
        Me.ChckboxTax.UncheckedState.BorderThickness = 0
        Me.ChckboxTax.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxTax.UseVisualStyleBackColor = True
        '
        'ChckboxHdmf
        '
        Me.ChckboxHdmf.AutoSize = True
        Me.ChckboxHdmf.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxHdmf.CheckedState.BorderRadius = 2
        Me.ChckboxHdmf.CheckedState.BorderThickness = 0
        Me.ChckboxHdmf.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxHdmf.ForeColor = System.Drawing.Color.Black
        Me.ChckboxHdmf.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChckboxHdmf.Location = New System.Drawing.Point(228, 31)
        Me.ChckboxHdmf.Name = "ChckboxHdmf"
        Me.ChckboxHdmf.Size = New System.Drawing.Size(60, 19)
        Me.ChckboxHdmf.TabIndex = 17
        Me.ChckboxHdmf.Text = "HDMF"
        Me.ChckboxHdmf.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxHdmf.UncheckedState.BorderRadius = 2
        Me.ChckboxHdmf.UncheckedState.BorderThickness = 0
        Me.ChckboxHdmf.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxHdmf.UseVisualStyleBackColor = True
        '
        'TxtboxTardiness
        '
        Me.TxtboxTardiness.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTardiness.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxTardiness.DefaultText = ""
        Me.TxtboxTardiness.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxTardiness.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxTardiness.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTardiness.DisabledState.Parent = Me.TxtboxTardiness
        Me.TxtboxTardiness.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxTardiness.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTardiness.FocusedState.Parent = Me.TxtboxTardiness
        Me.TxtboxTardiness.ForeColor = System.Drawing.Color.Black
        Me.TxtboxTardiness.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxTardiness.HoverState.Parent = Me.TxtboxTardiness
        Me.TxtboxTardiness.Location = New System.Drawing.Point(83, 55)
        Me.TxtboxTardiness.Margin = New System.Windows.Forms.Padding(9, 3, 9, 3)
        Me.TxtboxTardiness.Name = "TxtboxTardiness"
        Me.TxtboxTardiness.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxTardiness.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxTardiness.PlaceholderText = "Mins"
        Me.TxtboxTardiness.SelectedText = ""
        Me.TxtboxTardiness.ShadowDecoration.Parent = Me.TxtboxTardiness
        Me.TxtboxTardiness.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxTardiness.TabIndex = 16
        '
        'TxtboxAbsences
        '
        Me.TxtboxAbsences.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAbsences.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAbsences.DefaultText = ""
        Me.TxtboxAbsences.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAbsences.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAbsences.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAbsences.DisabledState.Parent = Me.TxtboxAbsences
        Me.TxtboxAbsences.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAbsences.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAbsences.FocusedState.Parent = Me.TxtboxAbsences
        Me.TxtboxAbsences.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAbsences.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAbsences.HoverState.Parent = Me.TxtboxAbsences
        Me.TxtboxAbsences.Location = New System.Drawing.Point(83, 29)
        Me.TxtboxAbsences.Margin = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.TxtboxAbsences.Name = "TxtboxAbsences"
        Me.TxtboxAbsences.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAbsences.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAbsences.PlaceholderText = "Days"
        Me.TxtboxAbsences.SelectedText = ""
        Me.TxtboxAbsences.ShadowDecoration.Parent = Me.TxtboxAbsences
        Me.TxtboxAbsences.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxAbsences.TabIndex = 15
        '
        'Guna2HtmlLabel12
        '
        Me.Guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel12.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel12.Location = New System.Drawing.Point(20, 56)
        Me.Guna2HtmlLabel12.Name = "Guna2HtmlLabel12"
        Me.Guna2HtmlLabel12.Size = New System.Drawing.Size(49, 15)
        Me.Guna2HtmlLabel12.TabIndex = 11
        Me.Guna2HtmlLabel12.TabStop = False
        Me.Guna2HtmlLabel12.Text = "Tardiness"
        '
        'Guna2HtmlLabel11
        '
        Me.Guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel11.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel11.Location = New System.Drawing.Point(19, 31)
        Me.Guna2HtmlLabel11.Name = "Guna2HtmlLabel11"
        Me.Guna2HtmlLabel11.Size = New System.Drawing.Size(50, 15)
        Me.Guna2HtmlLabel11.TabIndex = 10
        Me.Guna2HtmlLabel11.TabStop = False
        Me.Guna2HtmlLabel11.Text = "Absences"
        '
        'Guna2GroupBox5
        '
        Me.Guna2GroupBox5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox5.Controls.Add(Me.Guna2HtmlLabel10)
        Me.Guna2GroupBox5.Controls.Add(Me.TxtboxAdjustmentSub)
        Me.Guna2GroupBox5.Controls.Add(Me.Guna2HtmlLabel9)
        Me.Guna2GroupBox5.Controls.Add(Me.TxtboxAdjustmentAdd)
        Me.Guna2GroupBox5.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox5.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox5.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox5.Location = New System.Drawing.Point(742, 30)
        Me.Guna2GroupBox5.Name = "Guna2GroupBox5"
        Me.Guna2GroupBox5.ShadowDecoration.Parent = Me.Guna2GroupBox5
        Me.Guna2GroupBox5.Size = New System.Drawing.Size(102, 154)
        Me.Guna2GroupBox5.TabIndex = 11
        Me.Guna2GroupBox5.Text = "ADJUSTMENT"
        Me.Guna2GroupBox5.TextOffset = New System.Drawing.Point(0, -10)
        '
        'Guna2HtmlLabel10
        '
        Me.Guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel10.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel10.Location = New System.Drawing.Point(9, 56)
        Me.Guna2HtmlLabel10.Name = "Guna2HtmlLabel10"
        Me.Guna2HtmlLabel10.Size = New System.Drawing.Size(18, 15)
        Me.Guna2HtmlLabel10.TabIndex = 9
        Me.Guna2HtmlLabel10.TabStop = False
        Me.Guna2HtmlLabel10.Text = "( - )"
        '
        'TxtboxAdjustmentSub
        '
        Me.TxtboxAdjustmentSub.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAdjustmentSub.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAdjustmentSub.DefaultText = ""
        Me.TxtboxAdjustmentSub.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAdjustmentSub.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAdjustmentSub.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAdjustmentSub.DisabledState.Parent = Me.TxtboxAdjustmentSub
        Me.TxtboxAdjustmentSub.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAdjustmentSub.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAdjustmentSub.FocusedState.Parent = Me.TxtboxAdjustmentSub
        Me.TxtboxAdjustmentSub.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAdjustmentSub.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAdjustmentSub.HoverState.Parent = Me.TxtboxAdjustmentSub
        Me.TxtboxAdjustmentSub.Location = New System.Drawing.Point(40, 55)
        Me.TxtboxAdjustmentSub.Margin = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.TxtboxAdjustmentSub.Name = "TxtboxAdjustmentSub"
        Me.TxtboxAdjustmentSub.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAdjustmentSub.PlaceholderText = ""
        Me.TxtboxAdjustmentSub.SelectedText = ""
        Me.TxtboxAdjustmentSub.ShadowDecoration.Parent = Me.TxtboxAdjustmentSub
        Me.TxtboxAdjustmentSub.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxAdjustmentSub.TabIndex = 13
        '
        'Guna2HtmlLabel9
        '
        Me.Guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel9.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel9.Location = New System.Drawing.Point(9, 31)
        Me.Guna2HtmlLabel9.Name = "Guna2HtmlLabel9"
        Me.Guna2HtmlLabel9.Size = New System.Drawing.Size(21, 15)
        Me.Guna2HtmlLabel9.TabIndex = 7
        Me.Guna2HtmlLabel9.TabStop = False
        Me.Guna2HtmlLabel9.Text = "( + )"
        '
        'TxtboxAdjustmentAdd
        '
        Me.TxtboxAdjustmentAdd.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAdjustmentAdd.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAdjustmentAdd.DefaultText = ""
        Me.TxtboxAdjustmentAdd.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAdjustmentAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAdjustmentAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAdjustmentAdd.DisabledState.Parent = Me.TxtboxAdjustmentAdd
        Me.TxtboxAdjustmentAdd.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAdjustmentAdd.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAdjustmentAdd.FocusedState.Parent = Me.TxtboxAdjustmentAdd
        Me.TxtboxAdjustmentAdd.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAdjustmentAdd.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAdjustmentAdd.HoverState.Parent = Me.TxtboxAdjustmentAdd
        Me.TxtboxAdjustmentAdd.Location = New System.Drawing.Point(40, 29)
        Me.TxtboxAdjustmentAdd.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxAdjustmentAdd.Name = "TxtboxAdjustmentAdd"
        Me.TxtboxAdjustmentAdd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAdjustmentAdd.PlaceholderText = ""
        Me.TxtboxAdjustmentAdd.SelectedText = ""
        Me.TxtboxAdjustmentAdd.ShadowDecoration.Parent = Me.TxtboxAdjustmentAdd
        Me.TxtboxAdjustmentAdd.Size = New System.Drawing.Size(50, 20)
        Me.TxtboxAdjustmentAdd.TabIndex = 12
        '
        'TxtboxPayrollNo
        '
        Me.TxtboxPayrollNo.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxPayrollNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPayrollNo.DefaultText = "AUTO GENERATED"
        Me.TxtboxPayrollNo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPayrollNo.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPayrollNo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPayrollNo.DisabledState.Parent = Me.TxtboxPayrollNo
        Me.TxtboxPayrollNo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPayrollNo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPayrollNo.FocusedState.Parent = Me.TxtboxPayrollNo
        Me.TxtboxPayrollNo.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtboxPayrollNo.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPayrollNo.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPayrollNo.HoverState.Parent = Me.TxtboxPayrollNo
        Me.TxtboxPayrollNo.Location = New System.Drawing.Point(102, 138)
        Me.TxtboxPayrollNo.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxPayrollNo.Name = "TxtboxPayrollNo"
        Me.TxtboxPayrollNo.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPayrollNo.PlaceholderText = ""
        Me.TxtboxPayrollNo.SelectedText = ""
        Me.TxtboxPayrollNo.SelectionStart = 14
        Me.TxtboxPayrollNo.ShadowDecoration.Parent = Me.TxtboxPayrollNo
        Me.TxtboxPayrollNo.Size = New System.Drawing.Size(180, 20)
        Me.TxtboxPayrollNo.TabIndex = 6
        Me.TxtboxPayrollNo.TabStop = False
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxCreatedBy)
        Me.Guna2GroupBox1.Controls.Add(Me.BtnClearField)
        Me.Guna2GroupBox1.Controls.Add(Me.BtnSelectEmployees)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2GroupBox6)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2GroupBox5)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2GroupBox4)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2GroupBox3)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2GroupBox2)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxPayrollNo)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxPeriod)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxPayrollTitle)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxPayrollType)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(1350, 200)
        Me.Guna2GroupBox1.TabIndex = 25
        Me.Guna2GroupBox1.Text = "EDIT PAYROLL"
        Me.Guna2GroupBox1.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxCreatedBy
        '
        Me.TxtboxCreatedBy.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxCreatedBy.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxCreatedBy.DefaultText = ""
        Me.TxtboxCreatedBy.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxCreatedBy.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxCreatedBy.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCreatedBy.DisabledState.Parent = Me.TxtboxCreatedBy
        Me.TxtboxCreatedBy.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxCreatedBy.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCreatedBy.FocusedState.Parent = Me.TxtboxCreatedBy
        Me.TxtboxCreatedBy.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtboxCreatedBy.ForeColor = System.Drawing.Color.Black
        Me.TxtboxCreatedBy.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxCreatedBy.HoverState.Parent = Me.TxtboxCreatedBy
        Me.TxtboxCreatedBy.Location = New System.Drawing.Point(101, 164)
        Me.TxtboxCreatedBy.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxCreatedBy.Name = "TxtboxCreatedBy"
        Me.TxtboxCreatedBy.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxCreatedBy.PlaceholderText = ""
        Me.TxtboxCreatedBy.SelectedText = ""
        Me.TxtboxCreatedBy.ShadowDecoration.Parent = Me.TxtboxCreatedBy
        Me.TxtboxCreatedBy.Size = New System.Drawing.Size(181, 20)
        Me.TxtboxCreatedBy.TabIndex = 27
        Me.TxtboxCreatedBy.TabStop = False
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(54, 85)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(44, 15)
        Me.Guna2HtmlLabel3.TabIndex = 5
        Me.Guna2HtmlLabel3.TabStop = False
        Me.Guna2HtmlLabel3.Text = "PERIOD"
        '
        'TxtboxPeriod
        '
        Me.TxtboxPeriod.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxPeriod.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPeriod.DefaultText = ""
        Me.TxtboxPeriod.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPeriod.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPeriod.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPeriod.DisabledState.Parent = Me.TxtboxPeriod
        Me.TxtboxPeriod.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPeriod.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPeriod.FocusedState.Parent = Me.TxtboxPeriod
        Me.TxtboxPeriod.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPeriod.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPeriod.HoverState.Parent = Me.TxtboxPeriod
        Me.TxtboxPeriod.Location = New System.Drawing.Point(102, 82)
        Me.TxtboxPeriod.Margin = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.TxtboxPeriod.Name = "TxtboxPeriod"
        Me.TxtboxPeriod.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPeriod.PlaceholderText = ""
        Me.TxtboxPeriod.SelectedText = ""
        Me.TxtboxPeriod.ShadowDecoration.Parent = Me.TxtboxPeriod
        Me.TxtboxPeriod.Size = New System.Drawing.Size(180, 20)
        Me.TxtboxPeriod.TabIndex = 2
        '
        'TxtboxPayrollTitle
        '
        Me.TxtboxPayrollTitle.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxPayrollTitle.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPayrollTitle.DefaultText = ""
        Me.TxtboxPayrollTitle.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPayrollTitle.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPayrollTitle.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPayrollTitle.DisabledState.Parent = Me.TxtboxPayrollTitle
        Me.TxtboxPayrollTitle.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPayrollTitle.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPayrollTitle.FocusedState.Parent = Me.TxtboxPayrollTitle
        Me.TxtboxPayrollTitle.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPayrollTitle.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPayrollTitle.HoverState.Parent = Me.TxtboxPayrollTitle
        Me.TxtboxPayrollTitle.Location = New System.Drawing.Point(102, 56)
        Me.TxtboxPayrollTitle.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxPayrollTitle.Name = "TxtboxPayrollTitle"
        Me.TxtboxPayrollTitle.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPayrollTitle.PlaceholderText = ""
        Me.TxtboxPayrollTitle.SelectedText = ""
        Me.TxtboxPayrollTitle.ShadowDecoration.Parent = Me.TxtboxPayrollTitle
        Me.TxtboxPayrollTitle.Size = New System.Drawing.Size(180, 20)
        Me.TxtboxPayrollTitle.TabIndex = 1
        '
        'TxtboxPayrollType
        '
        Me.TxtboxPayrollType.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxPayrollType.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPayrollType.DefaultText = ""
        Me.TxtboxPayrollType.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPayrollType.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPayrollType.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPayrollType.DisabledState.Parent = Me.TxtboxPayrollType
        Me.TxtboxPayrollType.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPayrollType.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPayrollType.FocusedState.Parent = Me.TxtboxPayrollType
        Me.TxtboxPayrollType.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPayrollType.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPayrollType.HoverState.Parent = Me.TxtboxPayrollType
        Me.TxtboxPayrollType.Location = New System.Drawing.Point(102, 30)
        Me.TxtboxPayrollType.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxPayrollType.Name = "TxtboxPayrollType"
        Me.TxtboxPayrollType.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPayrollType.PlaceholderText = ""
        Me.TxtboxPayrollType.ReadOnly = True
        Me.TxtboxPayrollType.SelectedText = ""
        Me.TxtboxPayrollType.ShadowDecoration.Parent = Me.TxtboxPayrollType
        Me.TxtboxPayrollType.Size = New System.Drawing.Size(180, 20)
        Me.TxtboxPayrollType.TabIndex = 2
        Me.TxtboxPayrollType.TabStop = False
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(12, 61)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(85, 15)
        Me.Guna2HtmlLabel2.TabIndex = 1
        Me.Guna2HtmlLabel2.TabStop = False
        Me.Guna2HtmlLabel2.Text = "PAYROLL TITLE"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(15, 33)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(83, 15)
        Me.Guna2HtmlLabel1.TabIndex = 0
        Me.Guna2HtmlLabel1.TabStop = False
        Me.Guna2HtmlLabel1.Text = "PAYROLL TYPE"
        '
        'Dtglist
        '
        Me.Dtglist.AllowUserToAddRows = False
        Me.Dtglist.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.Dtglist.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dtglist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Dtglist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Dtglist.BackgroundColor = System.Drawing.Color.White
        Me.Dtglist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dtglist.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Dtglist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dtglist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dtglist.ColumnHeadersHeight = 25
        Me.Dtglist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dtglist.ContextMenuStrip = Me.ContextMenuStrip1
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Dtglist.DefaultCellStyle = DataGridViewCellStyle3
        Me.Dtglist.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dtglist.EnableHeadersVisualStyles = False
        Me.Dtglist.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Dtglist.Location = New System.Drawing.Point(0, 200)
        Me.Dtglist.Name = "Dtglist"
        Me.Dtglist.ReadOnly = True
        Me.Dtglist.RowHeadersVisible = False
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White
        Me.Dtglist.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dtglist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dtglist.Size = New System.Drawing.Size(1350, 403)
        Me.Dtglist.TabIndex = 29
        Me.Dtglist.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.Dtglist.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Dtglist.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.Dtglist.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.Dtglist.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Dtglist.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.Dtglist.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dtglist.ThemeStyle.HeaderStyle.Height = 25
        Me.Dtglist.ThemeStyle.ReadOnly = True
        Me.Dtglist.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Dtglist.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Dtglist.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Dtglist.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.Dtglist.ThemeStyle.RowsStyle.Height = 22
        Me.Dtglist.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        Me.Dtglist.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'EditPayroll
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1350, 729)
        Me.Controls.Add(Me.Dtglist)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Controls.Add(Me.Guna2VSeparator1)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.MinimumSize = New System.Drawing.Size(1364, 726)
        Me.Name = "EditPayroll"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EditPayroll"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.Guna2GroupBox4.ResumeLayout(False)
        Me.Guna2GroupBox4.PerformLayout()
        Me.Guna2GroupBox3.ResumeLayout(False)
        Me.Guna2GroupBox2.ResumeLayout(False)
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.Guna2GroupBox6.ResumeLayout(False)
        Me.Guna2GroupBox6.PerformLayout()
        Me.Guna2GroupBox5.ResumeLayout(False)
        Me.Guna2GroupBox5.PerformLayout()
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox1.PerformLayout()
        CType(Me.Dtglist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents TxtboxTotalTax As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Tax As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalNetPay As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel22 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalHdmf As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel21 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalPhic As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel20 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalSssEs As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel19 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalSssPs As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel18 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalGrossPay As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel17 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalLeaveWithoutPay As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel16 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalBasic As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel15 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalSalary As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel14 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxTotalRecords As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel13 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents BtnSave As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2GroupBox4 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxTotalNoOfDaysServed As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel8 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxCalendarDays As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents CmboxMonth As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GroupBox3 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxCoverage As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox2 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxRemarks As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2VSeparator1 As Guna.UI2.WinForms.Guna2VSeparator
    Friend WithEvents RemoveRowsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents BtnClearField As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnSelectEmployees As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2GroupBox6 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxTax As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxHdmf As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents ChckboxPhic As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents ChckboxSss As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents ChckboxTax As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents ChckboxHdmf As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents TxtboxTardiness As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxAbsences As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel12 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel11 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GroupBox5 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2HtmlLabel10 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxAdjustmentSub As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel9 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxAdjustmentAdd As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxPayrollNo As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxPeriod As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxPayrollTitle As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxPayrollType As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxCreatedBy As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Dtglist As Guna.UI2.WinForms.Guna2DataGridView
End Class
