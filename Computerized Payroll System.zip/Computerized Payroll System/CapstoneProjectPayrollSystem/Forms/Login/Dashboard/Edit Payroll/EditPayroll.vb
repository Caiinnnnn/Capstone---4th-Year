﻿Imports System.ComponentModel

Public Class EditPayroll

    Public tblEditPayroll As New DataTable("tblEditPayroll")

    Public Sub RefreshEditPayrollDtglist()
        Dim totalSalary As Double = 0
        Dim totalBasic As Double = 0
        Dim totalLeaveWithoutPay As Double = 0
        Dim totalGrosspay As Double = 0
        Dim totalSssPs As Double = 0
        Dim totalSssEs As Double = 0
        Dim totalPhic As Double = 0
        Dim totalHdmf As Double = 0
        Dim totalTax As Double = 0
        Dim totalNetpay As Double = 0

        For Each row As DataGridViewRow In Dtglist.Rows
            totalSalary = Math.Round(totalSalary + CDbl(row.Cells("SALARY").Value), 2)
            totalBasic = Math.Round(totalBasic + CDbl(row.Cells("BASIC").Value), 2)
            totalLeaveWithoutPay = Math.Round(totalLeaveWithoutPay + (CDbl(row.Cells("ABSENCES AMOUNT").Value + CDbl(row.Cells("TARDINESS AMOUNT").Value))), 2)
            totalGrosspay = Math.Round(totalGrosspay + CDbl(row.Cells("GROSS PAY").Value), 2)
            totalSssPs = Math.Round(totalSssPs + CDbl(row.Cells("SSS PS").Value), 2)
            totalSssEs = Math.Round(totalSssEs + CDbl(row.Cells("SSS ES").Value), 2)
            totalPhic = Math.Round(totalPhic + CDbl(row.Cells("PHIC").Value), 2)
            totalHdmf = Math.Round(totalHdmf + CDbl(row.Cells("HDMF").Value), 2)
            totalTax = Math.Round(totalTax + CDbl(row.Cells("TAX").Value), 2)
            totalNetpay = Math.Round(totalNetpay + CDbl(row.Cells("NET PAY").Value), 2)
        Next


        TxtboxTotalRecords.Text = Dtglist.RowCount
        TxtboxTotalSalary.Text = totalSalary
        TxtboxTotalBasic.Text = totalBasic
        TxtboxTotalLeaveWithoutPay.Text = totalLeaveWithoutPay
        TxtboxTotalGrossPay.Text = totalGrosspay
        TxtboxTotalSssPs.Text = totalSssPs
        TxtboxTotalSssEs.Text = totalSssEs
        TxtboxTotalPhic.Text = totalPhic
        TxtboxTotalHdmf.Text = totalHdmf
        TxtboxTotalTax.Text = totalTax
        TxtboxTotalNetPay.Text = totalNetpay

        Dtglist.ClearSelection()
    End Sub

    Private Sub EditPayroll_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TxtboxPayrollType.Text = GlobalVariables.loginType

        TxtboxHdmf.Enabled = False
        TxtboxTax.Enabled = False

        tblEditPayroll.Columns.Add("EMP NO", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("ACC NO", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("FULL NAME", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("POSITION", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("COVERAGE", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("REMARKS", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("SSS NUM", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("HDMF NUM", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("PHIC NUM", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("SALARY", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("MONTH", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("CALENDAR DAYS", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("TOTAL NO OF DAYS SERVED", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("DAILY RATE", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("BASIC", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("ABSENCES", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("ABSENCES AMOUNT", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("TARDINESS", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("TARDINESS AMOUNT", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("ADD", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("SUB", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("GROSS PAY", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("SSS PS", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("SSS ES", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("PHIC", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("HDMF", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("TAX", Type.GetType("System.String"))
        tblEditPayroll.Columns.Add("NET PAY", Type.GetType("System.String"))

        For Each row As DataRow In RetrieveData("SELECT employeesnums.EmployeeNo,
                                                        payrollreports.AcctNo,
                                                        FullName,
                                                        Position,
                                                        Coverage,
                                                        Remarks,
                                                        SssNum,
                                                        HdmfNum,
                                                        PhicNum,
                                                        Salary,
                                                        Month,
                                                        CalendarDays,
                                                        TotalNoOfDaysServed,
                                                        DailyRate,
                                                        Basic,
                                                        Absences,
                                                        AbsencesAmount,
                                                        Tardiness,
                                                        TardinessAmount,
                                                        AdjustmentAdd,
                                                        AdjustmentSub,
                                                        GrossPay,
                                                        SssPs,
                                                        SssEs,
                                                        Phic,
                                                        Hdmf,
                                                        Tax,
                                                        NetPay
                                                FROM
                                                        employeesnums INNER JOIN payrollreports
                                                ON
                                                        employeesnums.AcctNo = payrollreports.AcctNo
                                                WHERE
                                                        HeaderPayrollNo = '" & TxtboxPayrollNo.Text & "'", strCon).Rows
            tblEditPayroll.Rows.Add(row.Item("EmployeeNo"),
                                    row.Item("AcctNo"),
                                    row.Item("FullName"),
                                    row.Item("Position"),
                                    row.Item("Coverage"),
                                    row.Item("Remarks"),
                                    row.Item("SssNum"),
                                    row.Item("HdmfNum"),
                                    row.Item("PhicNum"),
                                    row.Item("Salary"),
                                    row.Item("Month"),
                                    row.Item("CalendarDays"),
                                    row.Item("TotalNoOfDaysServed"),
                                    row.Item("DailyRate"),
                                    row.Item("Basic"),
                                    row.Item("Absences"),
                                    row.Item("AbsencesAmount"),
                                    row.Item("Tardiness"),
                                    row.Item("TardinessAmount"),
                                    row.Item("AdjustmentAdd"),
                                    row.Item("AdjustmentSub"),
                                    row.Item("GrossPay"),
                                    row.Item("SssPs"),
                                    row.Item("SssEs"),
                                    row.Item("Phic"),
                                    row.Item("Hdmf"),
                                    row.Item("Tax"),
                                    row.Item("NetPay")
                                    )
        Next

        Dtglist.DataSource = tblEditPayroll

        'sorting list by FULL NAME
        Dtglist.Sort(Dtglist.Columns("FULL NAME"), ListSortDirection.Ascending)

        'prevents the column from being sorted
        For Each column As DataGridViewColumn In Dtglist.Columns
            Dtglist.Columns(column.Name).SortMode = DataGridViewColumnSortMode.NotSortable
        Next

        RefreshEditPayrollDtglist()
    End Sub

    Private Sub BtnClearField_Click(sender As Object, e As EventArgs) Handles BtnClearField.Click
        TxtboxRemarks.Clear()
        TxtboxCoverage.Clear()
        CmboxMonth.SelectedIndex = -1
        TxtboxCalendarDays.Clear()
        TxtboxTotalNoOfDaysServed.Clear()
        TxtboxAdjustmentAdd.Clear()
        TxtboxAdjustmentSub.Clear()
        TxtboxAbsences.Clear()
        TxtboxTardiness.Clear()
        TxtboxHdmf.Clear()
        TxtboxTax.Clear()
        ChckboxHdmf.Checked = False
        ChckboxTax.Checked = False
        ChckboxSss.Checked = False
        ChckboxPhic.Checked = False
    End Sub

    Private Sub CmboxMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmboxMonth.SelectedIndexChanged
        If CmboxMonth.SelectedIndex <> -1 Then
            TxtboxCalendarDays.Enabled = False
            TxtboxTotalNoOfDaysServed.Enabled = False
            TxtboxCalendarDays.Clear()
            TxtboxTotalNoOfDaysServed.Clear()
        Else
            TxtboxCalendarDays.Enabled = True
            TxtboxTotalNoOfDaysServed.Enabled = True
        End If
    End Sub

    Private Sub ChckboxHdmf_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxHdmf.CheckedChanged
        If ChckboxHdmf.Checked = True Then
            TxtboxHdmf.Enabled = True
        Else
            TxtboxHdmf.Enabled = False
            TxtboxHdmf.Clear()
        End If
    End Sub

    Private Sub RemoveRowsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveRowsToolStripMenuItem.Click
        'removing selected rows
        For Each row As DataGridViewRow In Dtglist.SelectedRows
            Dtglist.Rows.Remove(row)
        Next
        RefreshEditPayrollDtglist()
    End Sub

    Private Sub ChckboxTax_CheckedChanged(sender As Object, e As EventArgs) Handles ChckboxTax.CheckedChanged
        If ChckboxTax.Checked = True Then
            TxtboxTax.Enabled = True
        Else
            TxtboxTax.Enabled = False
            TxtboxTax.Clear()
        End If
    End Sub

    Private Sub TxtboxPayrollTitle_Leave(sender As Object, e As EventArgs) Handles TxtboxPayrollTitle.Leave
        TxtboxPayrollTitle.Text = TxtboxPayrollTitle.Text.ToUpper
    End Sub

    Private Sub TxtboxPeriod_Leave(sender As Object, e As EventArgs) Handles TxtboxPeriod.Leave
        TxtboxPeriod.Text = TxtboxPeriod.Text.ToUpper
    End Sub

    Private Sub TxtboxCalendarDays_TextChanged(sender As Object, e As EventArgs) Handles TxtboxCalendarDays.TextChanged
        TxtboxCalendarDays.Text = CheckForNumericCharacters(TxtboxCalendarDays.Text)
    End Sub

    Private Sub TxtboxTotalNoOfDaysServed_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTotalNoOfDaysServed.TextChanged
        TxtboxTotalNoOfDaysServed.Text = CheckForNumericCharacters(TxtboxTotalNoOfDaysServed.Text)
    End Sub

    Private Sub TxtboxAdjustmentAdd_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAdjustmentAdd.TextChanged
        TxtboxAdjustmentAdd.Text = validateDoublesAndCurrency(TxtboxAdjustmentAdd.Text)
    End Sub

    Private Sub TxtboxAdjustmentSub_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAdjustmentSub.TextChanged
        TxtboxAdjustmentSub.Text = validateDoublesAndCurrency(TxtboxAdjustmentSub.Text)
    End Sub

    Private Sub TxtboxAbsences_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAbsences.TextChanged
        TxtboxAbsences.Text = CheckForNumericCharacters(TxtboxAbsences.Text)
    End Sub

    Private Sub TxtboxTardiness_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTardiness.TextChanged
        TxtboxTardiness.Text = CheckForNumericCharacters(TxtboxTardiness.Text)
    End Sub

    Private Sub TxtboxHdmf_TextChanged(sender As Object, e As EventArgs) Handles TxtboxHdmf.TextChanged
        TxtboxHdmf.Text = validateDoublesAndCurrency(TxtboxHdmf.Text)
    End Sub

    Private Sub TxtboxTax_TextChanged(sender As Object, e As EventArgs) Handles TxtboxTax.TextChanged
        TxtboxTax.Text = validateDoublesAndCurrency(TxtboxTax.Text)
    End Sub

    Private Sub TxtboxRemarks_Leave(sender As Object, e As EventArgs) Handles TxtboxRemarks.Leave
        TxtboxRemarks.Text = TxtboxRemarks.Text.ToUpper
    End Sub

    Private Sub TxtboxCoverage_Leave(sender As Object, e As EventArgs) Handles TxtboxCoverage.Leave
        TxtboxCoverage.Text = TxtboxCoverage.Text.ToUpper
    End Sub

    Private Sub BtnSelectEmployees_Click(sender As Object, e As EventArgs) Handles BtnSelectEmployees.Click
        EditPayrollSelectEmployees.Show()
    End Sub

    Private Sub Dtglist_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dtglist.CellDoubleClick
        If Dtglist.RowCount <= 0 Then
            Exit Sub
        End If

        'checks if the viewer is not the owner
        If BtnSave.Enabled = False Then
            Exit Sub
        End If

        ' To check if the specific form is opened
        If Application.OpenForms().OfType(Of EditPayrollEditComputation).Any Then
            MessageBox.Show("Form currently opened")
            Exit Sub
        End If

        EditPayrollEditComputation.TxtboxFullName.Text = Dtglist.CurrentRow.Cells("FULL NAME").Value
        EditPayrollEditComputation.TxtboxAcctNo.Text = Dtglist.CurrentRow.Cells("ACC NO").Value
        EditPayrollEditComputation.TxtboxPosition.Text = Dtglist.CurrentRow.Cells("POSITION").Value
        EditPayrollEditComputation.TxtboxSalary.Text = Dtglist.CurrentRow.Cells("SALARY").Value

        EditPayrollEditComputation.TxtboxRemarks.Text = Dtglist.CurrentRow.Cells("REMARKS").Value
        EditPayrollEditComputation.TxtboxCoverage.Text = Dtglist.CurrentRow.Cells("COVERAGE").Value

        EditPayrollEditComputation.CmboxMonth.Text = Dtglist.CurrentRow.Cells("MONTH").Value

        If Dtglist.CurrentRow.Cells("MONTH").Value = "0.5" Or Dtglist.CurrentRow.Cells("MONTH").Value = "1.0" Then
            EditPayrollEditComputation.TxtboxCalendarDays.Enabled = False
            EditPayrollEditComputation.TxtboxTotalNoOfDaysServed.Enabled = False
        Else
            EditPayrollEditComputation.TxtboxCalendarDays.Enabled = True
            EditPayrollEditComputation.TxtboxTotalNoOfDaysServed.Enabled = True
        End If

        EditPayrollEditComputation.TxtboxCalendarDays.Text = Dtglist.CurrentRow.Cells("CALENDAR DAYS").Value
        EditPayrollEditComputation.TxtboxTotalNoOfDaysServed.Text = Dtglist.CurrentRow.Cells("TOTAL NO OF DAYS SERVED").Value

        EditPayrollEditComputation.TxtboxAdjustmentAdd.Text = Dtglist.CurrentRow.Cells("ADD").Value
        EditPayrollEditComputation.TxtboxAdjustmentSub.Text = Dtglist.CurrentRow.Cells("SUB").Value

        EditPayrollEditComputation.TxtboxAbsences.Text = Dtglist.CurrentRow.Cells("ABSENCES").Value
        EditPayrollEditComputation.TxtboxTardiness.Text = Dtglist.CurrentRow.Cells("TARDINESS").Value

        If Dtglist.CurrentRow.Cells("PHIC").Value = "0" Then
            EditPayrollEditComputation.ChckboxPhic.Checked = False
        Else
            EditPayrollEditComputation.ChckboxPhic.Checked = True
        End If

        If Dtglist.CurrentRow.Cells("SSS PS").Value = "0" Then
            EditPayrollEditComputation.ChckboxSss.Checked = False
        Else
            EditPayrollEditComputation.ChckboxSss.Checked = True
        End If

        If Dtglist.CurrentRow.Cells("HDMF").Value = "0" Then
            EditPayrollEditComputation.TxtboxHdmf.Text = Dtglist.CurrentRow.Cells("HDMF").Value
            EditPayrollEditComputation.TxtboxHdmf.Enabled = False
            EditPayrollEditComputation.ChckboxHdmf.Checked = False

        Else
            EditPayrollEditComputation.TxtboxHdmf.Text = Dtglist.CurrentRow.Cells("HDMF").Value
            EditPayrollEditComputation.TxtboxHdmf.Enabled = True
            EditPayrollEditComputation.ChckboxHdmf.Checked = True
        End If

        If Dtglist.CurrentRow.Cells("TAX").Value = "0" Then
            EditPayrollEditComputation.TxtboxTax.Text = Dtglist.CurrentRow.Cells("TAX").Value
            EditPayrollEditComputation.TxtboxTax.Enabled = False
            EditPayrollEditComputation.ChckboxTax.Checked = False
        Else
            EditPayrollEditComputation.TxtboxTax.Text = Dtglist.CurrentRow.Cells("TAX").Value
            EditPayrollEditComputation.TxtboxTax.Enabled = True
            EditPayrollEditComputation.ChckboxTax.Checked = True
        End If

        EditPayrollEditComputation.EditPayrollEditComputation_Compute()
        EditPayrollEditComputation.Show()

    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If TxtboxPeriod.Text = "" Or
            TxtboxPayrollTitle.Text = "" Then
            MessageBox.Show("Important fields cannot be empty")
            Exit Sub
        End If

        RefreshEditPayrollDtglist()

        Dim result As DialogResult = MessageBox.Show("Update Payroll?", "Edit Payroll", MessageBoxButtons.YesNo)

        If result = DialogResult.No Then
            Exit Sub
        End If

        Dim headerNameTo As String = Dtglist.Rows(0).Cells("FULL NAME").Value
        Dim headerType As String = TxtboxPayrollType.Text
        Dim headerPayrollNo As String = TxtboxPayrollNo.Text
        Dim headerPayrollTitle As String = TxtboxPayrollTitle.Text.ToUpper
        Dim headerPeriod As String = TxtboxPeriod.Text.ToUpper
        Dim headerCreatedBy As String = TxtboxCreatedBy.Text

        UpdateQuery("UPDATE payrollheaders SET NameTo='" & headerNameTo & "',
                                               PayrollTitle='" & headerPayrollTitle & "',
                                               Period = '" & headerPeriod & "',
                                               Amount = '" & TxtboxTotalSalary.Text & "',
                                               Type = '" & TxtboxPayrollType.Text & "',
                                               CreatedBy = '" & TxtboxCreatedBy.Text & "'
                                           WHERE
                                               PayrollNo = '" & headerPayrollNo & "'", strCon, False)

        DeleteRows("DELETE FROM payrollreports WHERE HeaderPayrollNo = '" & headerPayrollNo & "'", strCon)

        For Each row As DataGridViewRow In Dtglist.Rows
            Dim acctNo As String = row.Cells("ACC NO").Value
            Dim fullName As String = row.Cells("FULL NAME").Value
            Dim position As String = row.Cells("POSITION").Value
            Dim coverage As String = row.Cells("COVERAGE").Value
            Dim remarks As String = row.Cells("REMARKS").Value
            Dim sssNum As String = row.Cells("SSS NUM").Value
            Dim hdmfNum As String = row.Cells("HDMF NUM").Value
            Dim phicNum As String = row.Cells("PHIC NUM").Value
            Dim salary As String = row.Cells("SALARY").Value
            Dim month As String = row.Cells("MONTH").Value
            Dim calendarDays As String = row.Cells("CALENDAR DAYS").Value
            Dim totalNoOfDaysServed As String = row.Cells("TOTAL NO OF DAYS SERVED").Value
            Dim dailyRate As String = row.Cells("DAILY RATE").Value
            Dim basic As String = row.Cells("BASIC").Value
            Dim absences As String = row.Cells("ABSENCES").Value
            Dim absencesAmount As String = row.Cells("ABSENCES AMOUNT").Value
            Dim tardiness As String = row.Cells("TARDINESS").Value
            Dim tardinessAmount As String = row.Cells("TARDINESS AMOUNT").Value
            Dim adjustmentAdd As String = row.Cells("ADD").Value
            Dim adjustmentSub As String = row.Cells("SUB").Value
            Dim grossPay As String = row.Cells("GROSS PAY").Value
            Dim sssPs As String = row.Cells("SSS PS").Value
            Dim sssEs As String = row.Cells("SSS ES").Value
            Dim phic As String = row.Cells("PHIC").Value
            Dim hdmf As String = row.Cells("HDMF").Value
            Dim tax As String = row.Cells("TAX").Value
            Dim netPay As String = row.Cells("NET PAY").Value

            CreateQuery("INSERT INTO payrollreports (AcctNo,
                                                     FullName,
                                                     Position,
                                                     Coverage,
                                                     Remarks,
                                                     SssNum,
                                                     HdmfNum,
                                                     PhicNum,
                                                     Salary,
                                                     Month,
                                                     CalendarDays,
                                                     TotalNoOfDaysServed,
                                                     DailyRate,
                                                     Basic,
                                                     Absences,
                                                     AbsencesAmount,
                                                     Tardiness,
                                                     TardinessAmount,
                                                     AdjustmentAdd,
                                                     AdjustmentSub,
                                                     GrossPay,
                                                     SssPs,
                                                     SssEs,
                                                     Phic,
                                                     Hdmf,
                                                     Tax,
                                                     NetPay,
                                                     HeaderPayrollNo,
                                                     HeaderType,
                                                     HeaderPayrollTitle,
                                                     HeaderPeriod,
                                                     HeaderCreatedBy)
                                                     VALUES
                                                     ('" & acctNo & "',
                                                     '" & fullName & "',
                                                     '" & position & "',
                                                     '" & coverage & "',
                                                     '" & remarks & "',
                                                     '" & sssNum & "',
                                                     '" & hdmfNum & "',
                                                     '" & phicNum & "',
                                                     '" & salary & "',
                                                     '" & month & "',
                                                     '" & calendarDays & "',
                                                     '" & totalNoOfDaysServed & "',
                                                     '" & dailyRate & "',
                                                     '" & basic & "',
                                                     '" & absences & "',
                                                     '" & absencesAmount & "',
                                                     '" & tardiness & "',
                                                     '" & tardinessAmount & "',
                                                     '" & adjustmentAdd & "',
                                                     '" & adjustmentSub & "',
                                                     '" & grossPay & "',
                                                     '" & sssPs & "',
                                                     '" & sssEs & "',
                                                     '" & phic & "',
                                                     '" & hdmf & "',
                                                     '" & tax & "',
                                                     '" & netPay & "',
                                                     '" & headerPayrollNo & "',
                                                     '" & headerType & "',
                                                     '" & headerPayrollTitle & "',
                                                     '" & headerPeriod & "',
                                                     '" & headerCreatedBy & "')", strCon, False)
        Next

        MessageBox.Show("Payroll saved")
        Dashboard.RefreshDashboard()
        Me.Close()
    End Sub
End Class