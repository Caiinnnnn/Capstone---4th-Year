﻿Imports System.Reflection
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class SearchPayroll

    Private Sub SearchFunction()

        Dim search As String = TxtboxSearch.Text

        tblSearchPayroll.Clear()

        For Each row As DataRow In RetrieveData("SELECT employeesnums.EmployeeNo,
                                                        payrollreports.AcctNo,
                                                        FullName,
                                                        Position,
                                                        Coverage,
                                                        Remarks,
                                                        SssNum,
                                                        HdmfNum,
                                                        PhicNum,
                                                        Salary,
                                                        Month,
                                                        CalendarDays,
                                                        TotalNoOfDaysServed,
                                                        DailyRate,
                                                        Basic,
                                                        Absences,
                                                        AbsencesAmount,
                                                        Tardiness,
                                                        TardinessAmount,
                                                        AdjustmentAdd,
                                                        AdjustmentSub,
                                                        GrossPay,
                                                        SssPs,
                                                        SssEs,
                                                        Phic,
                                                        Hdmf,
                                                        Tax,
                                                        NetPay,
                                                        HeaderPayrollNo,
                                                        HeaderType,
                                                        HeaderPayrollTitle,
                                                        HeaderPeriod,
                                                        HeaderCreatedBy
                                                 FROM
                                                        employeesnums INNER JOIN payrollreports
                                                 ON
                                                        employeesnums.AcctNo = payrollreports.AcctNo
                                                 WHERE
                                                        (employeesnums.EmployeeNo LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (payrollreports.AcctNo LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (FullName LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Position LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Coverage LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Remarks LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (SssNum LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (HdmfNum LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (PhicNum LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Salary LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Month LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (CalendarDays LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (TotalNoOfDaysServed LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (DailyRate LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Basic LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Absences LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (AbsencesAmount LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Tardiness LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (TardinessAmount LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (AdjustmentAdd LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (AdjustmentSub LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (GrossPay LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (SssPs LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (SssEs LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Phic LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Hdmf LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (Tax LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (NetPay LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (HeaderPayrollNo LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (HeaderPayrollTitle LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%') OR
                                                        (HeaderPeriod LIKE '%" & search & "%' AND HeaderType LIKE '%" & CmboxType.Text & "%')", strCon).Rows

            tblSearchPayroll.Rows.Add(row.Item("EmployeeNo"),
                                      row.Item("AcctNo"),
                                      row.Item("FullName"),
                                      row.Item("Position"),
                                      row.Item("Coverage"),
                                      row.Item("Remarks"),
                                      row.Item("SssNum"),
                                      row.Item("HdmfNum"),
                                      row.Item("PhicNum"),
                                      row.Item("Salary"),
                                      row.Item("Month"),
                                      row.Item("CalendarDays"),
                                      row.Item("TotalNoOfDaysServed"),
                                      row.Item("DailyRate"),
                                      row.Item("Basic"),
                                      row.Item("Absences"),
                                      row.Item("AbsencesAmount"),
                                      row.Item("Tardiness"),
                                      row.Item("TardinessAmount"),
                                      row.Item("AdjustmentAdd"),
                                      row.Item("AdjustmentSub"),
                                      row.Item("GrossPay"),
                                      row.Item("SssPs"),
                                      row.Item("SssEs"),
                                      row.Item("Phic"),
                                      row.Item("Hdmf"),
                                      row.Item("Tax"),
                                      row.Item("NetPay"),
                                      row.Item("HeaderPayrollNo"),
                                      row.Item("HeaderType"),
                                      row.Item("HeaderPayrollTitle"),
                                      row.Item("HeaderCreatedBy")
                                      )

        Next

        Dtglist.DataSource = tblSearchPayroll
    End Sub

    Private Sub RefreshDtglist()

        tblSearchPayroll.Clear()

        For Each row As DataRow In RetrieveData("SELECT employeesnums.EmployeeNo,
                                                        payrollreports.AcctNo,
                                                        FullName,
                                                        Position,
                                                        Coverage,
                                                        Remarks,
                                                        SssNum,
                                                        HdmfNum,
                                                        PhicNum,
                                                        Salary,
                                                        Month,
                                                        CalendarDays,
                                                        TotalNoOfDaysServed,
                                                        DailyRate,
                                                        Basic,
                                                        Absences,
                                                        AbsencesAmount,
                                                        Tardiness,
                                                        TardinessAmount,
                                                        AdjustmentAdd,
                                                        AdjustmentSub,
                                                        GrossPay,
                                                        SssPs,
                                                        SssEs,
                                                        Phic,
                                                        Hdmf,
                                                        Tax,
                                                        NetPay,
                                                        HeaderPayrollNo,
                                                        HeaderType,
                                                        HeaderPayrollTitle,
                                                        HeaderPeriod,
                                                        HeaderCreatedBy
                                                 FROM
                                                        employeesnums INNER JOIN payrollreports
                                                 On
                                                        employeesnums.AcctNo = payrollreports.AcctNo", strCon).Rows

            tblSearchPayroll.Rows.Add(row.Item("EmployeeNo"),
                                      row.Item("AcctNo"),
                                      row.Item("FullName"),
                                      row.Item("Position"),
                                      row.Item("Coverage"),
                                      row.Item("Remarks"),
                                      row.Item("SssNum"),
                                      row.Item("HdmfNum"),
                                      row.Item("PhicNum"),
                                      row.Item("Salary"),
                                      row.Item("Month"),
                                      row.Item("CalendarDays"),
                                      row.Item("TotalNoOfDaysServed"),
                                      row.Item("DailyRate"),
                                      row.Item("Basic"),
                                      row.Item("Absences"),
                                      row.Item("AbsencesAmount"),
                                      row.Item("Tardiness"),
                                      row.Item("TardinessAmount"),
                                      row.Item("AdjustmentAdd"),
                                      row.Item("AdjustmentSub"),
                                      row.Item("GrossPay"),
                                      row.Item("SssPs"),
                                      row.Item("SssEs"),
                                      row.Item("Phic"),
                                      row.Item("Hdmf"),
                                      row.Item("Tax"),
                                      row.Item("NetPay"),
                                      row.Item("HeaderPayrollNo"),
                                      row.Item("HeaderType"),
                                      row.Item("HeaderPayrollTitle"),
                                      row.Item("HeaderCreatedBy")
                                      )

        Next

        Dtglist.DataSource = tblSearchPayroll
    End Sub

    Public tblSearchPayroll As New DataTable("tblSearchPayroll")
    Private Sub SearchPayroll_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tblSearchPayroll.Columns.Add("EMP NO")
        tblSearchPayroll.Columns.Add("ACC NO")
        tblSearchPayroll.Columns.Add("FULL NAME")
        tblSearchPayroll.Columns.Add("POSITION")
        tblSearchPayroll.Columns.Add("COVERAGE")
        tblSearchPayroll.Columns.Add("REMARKS")
        tblSearchPayroll.Columns.Add("SSS NUM")
        tblSearchPayroll.Columns.Add("HDMF NUM")
        tblSearchPayroll.Columns.Add("PHIC NUM")
        tblSearchPayroll.Columns.Add("SALARY")
        tblSearchPayroll.Columns.Add("MONTH")
        tblSearchPayroll.Columns.Add("CALENDAR DAYS")
        tblSearchPayroll.Columns.Add("TOTAL NO OF DAYS SERVED")
        tblSearchPayroll.Columns.Add("DAILY RATE")
        tblSearchPayroll.Columns.Add("BASIC")
        tblSearchPayroll.Columns.Add("ABSENCES")
        tblSearchPayroll.Columns.Add("ABSENCES AMOUNT")
        tblSearchPayroll.Columns.Add("TARDINESS")
        tblSearchPayroll.Columns.Add("TARDINESS AMOUNT")
        tblSearchPayroll.Columns.Add("ADD")
        tblSearchPayroll.Columns.Add("SUB")
        tblSearchPayroll.Columns.Add("GROSS PAY")
        tblSearchPayroll.Columns.Add("SSS PS")
        tblSearchPayroll.Columns.Add("SSS ES")
        tblSearchPayroll.Columns.Add("PHIC")
        tblSearchPayroll.Columns.Add("HDMF")
        tblSearchPayroll.Columns.Add("TAX")
        tblSearchPayroll.Columns.Add("NET PAY")
        tblSearchPayroll.Columns.Add("PAYROLL NO")
        tblSearchPayroll.Columns.Add("TYPE")
        tblSearchPayroll.Columns.Add("PAYROLL TITLE")
        tblSearchPayroll.Columns.Add("PERIOD")
        tblSearchPayroll.Columns.Add("CREATED BY")

        RefreshDtglist()

    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        CmboxType.SelectedIndex = -1
        TxtboxSearch.Clear()
        RefreshDtglist()
        TxtboxSearch.Focus()
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        SearchFunction()
    End Sub
End Class