﻿Imports System.ComponentModel
Imports System.Web.UI.WebControls

Public Class Dashboard

    Public tblUserPayroll As New DataTable("tblDashboard")
    Public tblAllPayroll As New DataTable("tblAllPayroll")

    Public Sub RefreshDashboard()

        ' for users payroll
        tblUserPayroll.Clear()
        For Each row As DataRow In RetrieveData("SELECT * FROM payrollheaders WHERE
                                                                              Type = '" & GlobalVariables.loginType & "' AND
                                                                              CreatedBy = '" & GlobalVariables.loginUsername & "'", strCon).Rows
            tblUserPayroll.Rows.Add(row.Item("PayrollNo"),
                                  row.Item("Type"),
                                  row.Item("NameTo"),
                                  row.Item("PayrollTitle"),
                                  row.Item("Amount"),
                                  row.Item("Period"),
                                  row.Item("CreatedBy")
                                  )
        Next row
        UserPayrollDtglist.DataSource = tblUserPayroll

        UserPayrollDtglist.Sort(UserPayrollDtglist.Columns("PAYROLL NO"), ListSortDirection.Descending)

        For Each column As DataGridViewColumn In UserPayrollDtglist.Columns
            UserPayrollDtglist.Columns(column.Name).SortMode = DataGridViewColumnSortMode.NotSortable
        Next

        ' for all payroll
        tblAllPayroll.Clear()
        For Each row As DataRow In RetrieveData("SELECT * FROM payrollheaders WHERE
                                                                              Type = '" & GlobalVariables.loginType & "'", strCon).Rows
            tblAllPayroll.Rows.Add(row.Item("PayrollNo"),
                                  row.Item("Type"),
                                  row.Item("NameTo"),
                                  row.Item("PayrollTitle"),
                                  row.Item("Amount"),
                                  row.Item("Period"),
                                  row.Item("CreatedBy")
                                  )
        Next row
        AllPayrollDtglist.DataSource = tblAllPayroll

        AllPayrollDtglist.Sort(AllPayrollDtglist.Columns("PAYROLL NO"), ListSortDirection.Descending)

        For Each column As DataGridViewColumn In AllPayrollDtglist.Columns
            AllPayrollDtglist.Columns(column.Name).SortMode = DataGridViewColumnSortMode.NotSortable
        Next


        'pre-loading avatars
        Dim avatar As Dictionary(Of String, Bitmap) = New Dictionary(Of String, Bitmap)
        avatar.Add("man_1", My.Resources.man_1)
        avatar.Add("man_2", My.Resources.man_2)
        avatar.Add("man_3", My.Resources.man_3)
        avatar.Add("man_4", My.Resources.man_4)
        avatar.Add("man_5", My.Resources.man_5)
        avatar.Add("man_6", My.Resources.man_6)
        avatar.Add("man_7", My.Resources.man_7)
        avatar.Add("woman_1", My.Resources.woman_1)
        avatar.Add("woman_2", My.Resources.woman_2)
        avatar.Add("woman_3", My.Resources.woman_3)
        avatar.Add("woman_4", My.Resources.woman_4)
        avatar.Add("woman_5", My.Resources.woman_5)
        avatar.Add("woman_6", My.Resources.woman_6)
        avatar.Add("woman_7", My.Resources.woman_7)
        avatar.Add("animal_1", My.Resources.animal_1)
        avatar.Add("animal_2", My.Resources.animal_2)
        avatar.Add("animal_3", My.Resources.animal_3)
        avatar.Add("animal_4", My.Resources.animal_4)
        avatar.Add("animal_5", My.Resources.animal_5)
        avatar.Add("animal_6", My.Resources.animal_6)
        avatar.Add("animal_7", My.Resources.animal_7)

        Dim profileAvatar As String
        RetrieveRow("SELECT * FROM user_accts WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon)
        profileAvatar = myreader("Avatar")
        PboxAvatar.Image = avatar.Item(profileAvatar)

    End Sub

    Private Sub Dashboard_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        App.Close()
    End Sub

    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GlobalVariables.loginType = "ELEM"
        TypeToolStripMenuItem.Text = GlobalVariables.loginType

        RetrieveRow("SELECT * FROM user_accts WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon)

        GlobalVariables.loginFullName = myreader("FullName").ToString
        GlobalVariables.loginPosition = myreader("Position").ToString

        LblLogin.Text = GlobalVariables.loginFullName
        LblPosition.Text = GlobalVariables.loginPosition


        TabPage1.Text = GlobalVariables.loginUsername.ToUpper + " Payroll"

        tblUserPayroll.Columns.Add("PAYROLL NO", Type.GetType("System.String"))
        tblUserPayroll.Columns.Add("TYPE", Type.GetType("System.String"))
        tblUserPayroll.Columns.Add("NAME TO", Type.GetType("System.String"))
        tblUserPayroll.Columns.Add("PAYROLL TITLE", Type.GetType("System.String"))
        tblUserPayroll.Columns.Add("AMOUNT", Type.GetType("System.String"))
        tblUserPayroll.Columns.Add("PERIOD", Type.GetType("System.String"))
        tblUserPayroll.Columns.Add("CREATED BY", Type.GetType("System.String"))

        tblAllPayroll.Columns.Add("PAYROLL NO", Type.GetType("System.String"))
        tblAllPayroll.Columns.Add("TYPE", Type.GetType("System.String"))
        tblAllPayroll.Columns.Add("NAME TO", Type.GetType("System.String"))
        tblAllPayroll.Columns.Add("PAYROLL TITLE", Type.GetType("System.String"))
        tblAllPayroll.Columns.Add("AMOUNT", Type.GetType("System.String"))
        tblAllPayroll.Columns.Add("PERIOD", Type.GetType("System.String"))
        tblAllPayroll.Columns.Add("CREATED BY", Type.GetType("System.String"))

        RefreshDashboard()
    End Sub

    Private Sub ELEMToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ELEMToolStripMenuItem.Click
        GlobalVariables.loginType = "ELEM"
        TypeToolStripMenuItem.Text = GlobalVariables.loginType
        RefreshDashboard()
    End Sub

    Private Sub HSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HSToolStripMenuItem.Click
        GlobalVariables.loginType = "HS"
        TypeToolStripMenuItem.Text = GlobalVariables.loginType
        RefreshDashboard()
    End Sub

    Private Sub NTPToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NTPToolStripMenuItem.Click
        GlobalVariables.loginType = "NTP"
        TypeToolStripMenuItem.Text = GlobalVariables.loginType
        RefreshDashboard()
    End Sub

    Private Sub BtnEmplist_Click(sender As Object, e As EventArgs) Handles BtnEmplist.Click
        EmpList.Show()
    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click
        Me.Dispose()
        Me.Close()
        App.TxtboxUsername.Clear()
        App.TxtboxPassword.Clear()
        App.Show()
        App.TxtboxUsername.Focus()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        NewPayroll.Show()
    End Sub

    Private Sub UserPayrollDtglist_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles UserPayrollDtglist.CellDoubleClick
        If UserPayrollDtglist.RowCount <= 0 Then
            Exit Sub
        End If

        EditPayroll.TxtboxPayrollNo.Text = UserPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value
        EditPayroll.TxtboxPayrollType.Text = UserPayrollDtglist.CurrentRow.Cells("TYPE").Value
        EditPayroll.TxtboxPayrollTitle.Text = UserPayrollDtglist.CurrentRow.Cells("PAYROLL TITLE").Value
        EditPayroll.TxtboxPeriod.Text = UserPayrollDtglist.CurrentRow.Cells("PERIOD").Value
        EditPayroll.TxtboxCreatedBy.Text = UserPayrollDtglist.CurrentRow.Cells("CREATED BY").Value
        EditPayroll.Show()
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        SearchPayroll.Show()
    End Sub

    Private Sub BtnPrint_Click(sender As Object, e As EventArgs) Handles BtnPrint.Click
        PrintForm.Show()
    End Sub

    Private Sub BtnForFindes_Click(sender As Object, e As EventArgs) Handles BtnForFindes.Click
        If UserPayrollDtglist.RowCount <= 0 Then
            Exit Sub
        End If

        Dim payrollNo As String = UserPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value

        Dim tblForFindes As New DataTable

        tblForFindes.Columns.Add("AcctNo")
        tblForFindes.Columns.Add("FullName")
        tblForFindes.Columns.Add("NetPay")

        For Each row As DataRow In RetrieveData("SELECT * FROM payrollreports WHERE HeaderPayrollNo = '" & payrollNo & "'", strCon).Rows
            tblForFindes.Rows.Add(row.Item("AcctNo"),
                                  row.Item("FullName"),
                                  Replace(row.Item("NetPay"), ".", ""))
        Next

        Dim rptdoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        rptdoc = New PrintForFindesReports
        rptdoc.SetDataSource(tblForFindes)
        PrintForFindesForm.CrystalReportViewer1.ReportSource = rptdoc
        PrintForFindesForm.Show()
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        ChangePassword.Show()
    End Sub

    Private Sub ChangeAvatarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangeAvatarToolStripMenuItem.Click
        ChangeAvatar.Show()
    End Sub

    Private Sub AllPayrollDtglist_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles AllPayrollDtglist.CellDoubleClick
        If AllPayrollDtglist.RowCount <= 0 Then
            Exit Sub
        End If

        If AllPayrollDtglist.CurrentRow.Cells("CREATED BY").Value <> GlobalVariables.loginUsername Then
            EditPayroll.TxtboxPayrollTitle.ReadOnly = True
            EditPayroll.TxtboxPeriod.ReadOnly = True
            EditPayroll.TxtboxRemarks.ReadOnly = True
            EditPayroll.TxtboxCoverage.ReadOnly = True
            EditPayroll.CmboxMonth.Enabled = False
            EditPayroll.TxtboxCalendarDays.ReadOnly = True
            EditPayroll.TxtboxTotalNoOfDaysServed.ReadOnly = True
            EditPayroll.TxtboxAdjustmentAdd.ReadOnly = True
            EditPayroll.TxtboxAdjustmentSub.ReadOnly = True
            EditPayroll.TxtboxAbsences.ReadOnly = True
            EditPayroll.TxtboxTardiness.ReadOnly = True
            EditPayroll.TxtboxHdmf.ReadOnly = True
            EditPayroll.TxtboxTax.ReadOnly = True
            EditPayroll.ChckboxHdmf.Enabled = False
            EditPayroll.ChckboxTax.Enabled = False
            EditPayroll.ChckboxSss.Enabled = False
            EditPayroll.ChckboxPhic.Enabled = False
            EditPayroll.BtnSelectEmployees.Enabled = False
            EditPayroll.BtnClearField.Enabled = False
            EditPayroll.BtnSave.Enabled = False
        End If

        EditPayroll.TxtboxPayrollNo.Text = AllPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value
        EditPayroll.TxtboxPayrollType.Text = AllPayrollDtglist.CurrentRow.Cells("TYPE").Value
        EditPayroll.TxtboxPayrollTitle.Text = AllPayrollDtglist.CurrentRow.Cells("PAYROLL TITLE").Value
        EditPayroll.TxtboxPeriod.Text = AllPayrollDtglist.CurrentRow.Cells("PERIOD").Value
        EditPayroll.TxtboxCreatedBy.Text = AllPayrollDtglist.CurrentRow.Cells("CREATED BY").Value
        EditPayroll.Show()
    End Sub
End Class