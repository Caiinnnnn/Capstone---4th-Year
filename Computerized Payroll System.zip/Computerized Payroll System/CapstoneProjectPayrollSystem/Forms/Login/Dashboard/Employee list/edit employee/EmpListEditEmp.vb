﻿Public Class EmpListEditEmp
    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If TxtboxLastName.Text = String.Empty Or
           TxtboxFirstName.Text = String.Empty Or
           TxtboxAccNumber.Text = String.Empty Or
           TxtboxEmployeeNo.Text = String.Empty Or
           CmboxType.SelectedIndex = -1 Or
           TxtboxPosition.Text = String.Empty Or
           TxtboxSssNum.Text = String.Empty Or
           TxtboxPhicNum.Text = String.Empty Or
           TxtboxHdmfNum.Text = String.Empty Or
           TxtboxSalary.Text = String.Empty Or
           CmboxStatus.SelectedIndex = -1 Then

            MessageBox.Show("cannot have empty fields")
            Exit Sub
        End If

        'string interpolation for fullname
        Dim fname As String = TxtboxFirstName.Text.ToUpper
        Dim lname As String = TxtboxLastName.Text.ToUpper
        Dim sname As String = TxtboxSuffix.Text.ToUpper
        Dim aname As String = TxtboxAppellation.Text.ToUpper
        Dim mname As String = ""

        If TxtboxMiddleName.Text = "" Then
            mname = TxtboxMiddleName.Text
        Else
            mname = TxtboxMiddleName.Text.ToUpper.Substring(0, 1)
        End If

        Dim fullname As String

        If sname <> "" And aname <> "" Then 'if suffix and appellation is not null
            fullname = $"{sname} {lname}, {aname} {fname} {mname}"
        ElseIf sname <> "" And aname = "" Then 'if suffix is not nut and appellation is null
            fullname = $"{lname} {sname}, {fname} {mname}"
        ElseIf sname = "" And aname <> "" Then 'if suffix is null and appellation is not null
            fullname = $"{lname}, {aname} {fname} {mname}"
        Else
            fullname = $"{lname}, {fname} {mname}"
        End If

        'removing timestamp from datetimepicker
        Dim bdate As String = DtpBirthDate.Value.ToShortDateString

        'checking if unique id(s) exists in employees table
        CheckID("SELECT * FROM employees WHERE AcctNo = '" & TxtboxAccNumber.Text & "'
                                            OR SssNum='" & TxtboxSssNum.Text & "' 
                                            OR HdmfNum ='" & TxtboxHdmfNum.Text & "' 
                                            OR PhicNum='" & TxtboxPhicNum.Text & "'", strCon)

        ' the `dt.Rows.Count > 1` is like that instead of `dt.Rows.Count > 0`
        ' is to kind of like searching for similar values "except" to the current
        ' values that is being checked by the checkID function
        If dt.Rows.Count > 1 Then
            MessageBox.Show("Unique ID/s already exists")
            'clearField()
            Exit Sub
        End If

        'checking if unique id(s) exists in employeesnums table
        CheckID("SELECT * FROM employeesnums WHERE AcctNo = '" & TxtboxAccNumber.Text & "'
                                            AND EmployeeNo = '" & TxtboxEmployeeNo.Text & "'", strCon)

        If dt.Rows.Count > 1 Then
            MessageBox.Show("Unique ID/s already exists")
            'clearField()
            Exit Sub
        End If

        UpdateQuery("UPDATE employeesnums SET EmployeeNo = '" & TxtboxEmployeeNo.Text.ToUpper & "'
                                          WHERE AcctNo = '" & TxtboxAccNumber.Text & "'", strCon, False)

        UpdateQuery("UPDATE employees SET FullName = '" & fullname & "',
                                          LastName = '" & TxtboxLastName.Text.ToUpper & "',
                                          Suffix = '" & TxtboxSuffix.Text.ToUpper & "',
                                          Appellation = '" & TxtboxAppellation.Text.ToUpper & "',
                                          FirstName = '" & TxtboxFirstName.Text.ToUpper & "',
                                          MiddleName = '" & TxtboxMiddleName.Text.ToUpper & "',
                                          BirthDate = '" & bdate & "',
                                          Salary = '" & TxtboxSalary.Text & "',
                                          Type = '" & CmboxType.Text & "',
                                          Position = '" & TxtboxPosition.Text.ToUpper & "',
                                          Remarks = '" & TxtboxRemarks.Text.ToUpper & "',
                                          SssNum = '" & TxtboxSssNum.Text & "',
                                          HdmfNum = '" & TxtboxHdmfNum.Text & "',
                                          PhicNum = '" & TxtboxPhicNum.Text & "',
                                          Status = '" & CmboxStatus.Text & "'
                                      WHERE
                                          AcctNo = '" & TxtboxAccNumber.Text & "'", strCon, True)

        EmpList.RefreshEmpListDtglist()
        Me.Close()
    End Sub

    Private Sub TxtboxLastName_TextChanged(sender As Object, e As EventArgs) Handles TxtboxLastName.TextChanged
        TxtboxLastName.Text = CheckForAlphaCharacters(TxtboxLastName.Text)
    End Sub

    Private Sub TxtboxSuffix_TextChanged(sender As Object, e As EventArgs) Handles TxtboxSuffix.TextChanged
        TxtboxSuffix.Text = CheckForAlphaCharacters(TxtboxSuffix.Text)
    End Sub

    Private Sub TxtboxAppellation_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAppellation.TextChanged
        TxtboxAppellation.Text = CheckForAlphaCharacters(TxtboxAppellation.Text)
    End Sub

    Private Sub TxtboxFirstName_TextChanged(sender As Object, e As EventArgs) Handles TxtboxFirstName.TextChanged
        TxtboxFirstName.Text = CheckForAlphaCharacters(TxtboxFirstName.Text)
    End Sub

    Private Sub TxtboxMiddleName_TextChanged(sender As Object, e As EventArgs) Handles TxtboxMiddleName.TextChanged
        TxtboxMiddleName.Text = CheckForAlphaCharacters(TxtboxMiddleName.Text)
    End Sub

    Private Sub TxtboxAccNumber_TextChanged(sender As Object, e As EventArgs) Handles TxtboxAccNumber.TextChanged
        TxtboxAccNumber.Text = CheckForNumericCharacters(TxtboxAccNumber.Text)
    End Sub

    Private Sub TxtboxSssNum_TextChanged(sender As Object, e As EventArgs) Handles TxtboxSssNum.TextChanged
        TxtboxSssNum.Text = CheckForNumericCharacters(TxtboxSssNum.Text)
    End Sub

    Private Sub TxtboxPhicNum_TextChanged(sender As Object, e As EventArgs) Handles TxtboxPhicNum.TextChanged
        TxtboxPhicNum.Text = CheckForNumericCharacters(TxtboxPhicNum.Text)
    End Sub

    Private Sub TxtboxHdmfNum_TextChanged(sender As Object, e As EventArgs) Handles TxtboxHdmfNum.TextChanged
        TxtboxHdmfNum.Text = CheckForNumericCharacters(TxtboxHdmfNum.Text)
    End Sub

    Private Sub TxtboxSalary_TextChanged(sender As Object, e As EventArgs) Handles TxtboxSalary.TextChanged
        TxtboxSalary.Text = validateDoublesAndCurrency(TxtboxSalary.Text)
    End Sub
End Class