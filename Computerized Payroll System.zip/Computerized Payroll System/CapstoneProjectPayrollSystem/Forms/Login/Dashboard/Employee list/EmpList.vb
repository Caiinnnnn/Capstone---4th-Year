﻿Imports System.ComponentModel

Public Class EmpList

    Private Sub SortDtglist()
        'sorting the datagridview by LastName
        Dtglist.Sort(Dtglist.Columns("FullName"), ListSortDirection.Ascending)

        Dtglist.ClearSelection() 'un-highlights the datagridiew

        For Each row As DataGridViewRow In Dtglist.Rows
            ' iterating dtglist rows
            If row.Cells("STATUS").Value = "ACTIVE" Then
                ' if the user is currently ACTIVE
                row.DefaultCellStyle.BackColor = Color.FromArgb(48, 150, 23)
                row.DefaultCellStyle.ForeColor = Color.White
            End If

            If row.Cells("STATUS").Value = "INACTIVE" Then
                ' if the user is currently INACTIVE
                row.DefaultCellStyle.BackColor = Color.FromArgb(224, 58, 58)
                row.DefaultCellStyle.ForeColor = Color.White
            End If
        Next

        LblCount.Text = Dtglist.RowCount().ToString
        LblCountActive.Text = CountRowsDtglist("Status", "ACTIVE", Dtglist)
        LblCountInactive.Text = CountRowsDtglist("Status", "INACTIVE", Dtglist)

        'LblCount.Text = Dtglist.DisplayedRowCount(True).ToString
    End Sub

    Public Sub RefreshEmpListDtglist()
        Reload("SELECT employeesnums.EmployeeNo,
                        employees.AcctNo,
                        FullName,
                        LastName,
                        Suffix,
                        Appellation,
                        FirstName,
                        MiddleName,
                        BirthDate,
                        Salary,
                        Type,
                        Position,
                        Remarks,
                        SssNum,
                        HdmfNum,
                        PhicNum,
                        Status,
                        AddedBy
                FROM employeesnums
                INNER JOIN employees
                ON employeesnums.AcctNo = employees.AcctNo", Dtglist, strCon)

        SortDtglist()
    End Sub

    Private Sub EmpList_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        RefreshEmpListDtglist()

        FillComboboxes("SELECT Username FROM user_accts", "Username", CmboxCreatedBy, strCon)
        CmboxCreatedBy.SelectedIndex = -1
    End Sub

    Private Sub BtnCreate_Click(sender As Object, e As EventArgs) Handles BtnCreate.Click
        EmpListCreateEmp.Show()
    End Sub

    Private Sub Dtglist_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dtglist.CellDoubleClick
        If Dtglist.RowCount <= 0 Then
            Exit Sub
        End If

        If Not GlobalVariables.loginUsername = Dtglist.CurrentRow.Cells("AddedBy").Value.ToString Then

            EmpListEditEmp.TxtboxLastName.ReadOnly = True
            EmpListEditEmp.TxtboxSuffix.ReadOnly = True
            EmpListEditEmp.TxtboxAppellation.ReadOnly = True
            EmpListEditEmp.TxtboxFirstName.ReadOnly = True
            EmpListEditEmp.TxtboxMiddleName.ReadOnly = True
            EmpListEditEmp.DtpBirthDate.Enabled = False
            EmpListEditEmp.TxtboxAccNumber.ReadOnly = True
            EmpListEditEmp.TxtboxEmployeeNo.ReadOnly = True
            EmpListEditEmp.CmboxType.Enabled = False
            EmpListEditEmp.TxtboxPosition.ReadOnly = True
            EmpListEditEmp.TxtboxSssNum.ReadOnly = True
            EmpListEditEmp.TxtboxPhicNum.ReadOnly = True
            EmpListEditEmp.TxtboxHdmfNum.ReadOnly = True
            EmpListEditEmp.TxtboxSalary.ReadOnly = True
            EmpListEditEmp.TxtboxRemarks.ReadOnly = True
            EmpListEditEmp.CmboxStatus.Enabled = False

            EmpListEditEmp.BtnSave.Enabled = False

        End If

        EmpListEditEmp.TxtboxLastName.Text = Dtglist.CurrentRow.Cells("LastName").Value
        EmpListEditEmp.TxtboxSuffix.Text = Dtglist.CurrentRow.Cells("Suffix").Value
        EmpListEditEmp.TxtboxAppellation.Text = Dtglist.CurrentRow.Cells("Appellation").Value
        EmpListEditEmp.TxtboxFirstName.Text = Dtglist.CurrentRow.Cells("FirstName").Value
        EmpListEditEmp.TxtboxMiddleName.Text = Dtglist.CurrentRow.Cells("MiddleName").Value
        EmpListEditEmp.DtpBirthDate.Value = Dtglist.CurrentRow.Cells("BirthDate").Value
        EmpListEditEmp.TxtboxAccNumber.Text = Dtglist.CurrentRow.Cells("AcctNo").Value
        EmpListEditEmp.TxtboxEmployeeNo.Text = Dtglist.CurrentRow.Cells("EmployeeNo").Value
        EmpListEditEmp.CmboxType.Text = Dtglist.CurrentRow.Cells("Type").Value
        EmpListEditEmp.TxtboxPosition.Text = Dtglist.CurrentRow.Cells("Position").Value
        EmpListEditEmp.TxtboxSssNum.Text = Dtglist.CurrentRow.Cells("SssNum").Value
        EmpListEditEmp.TxtboxPhicNum.Text = Dtglist.CurrentRow.Cells("PhicNum").Value
        EmpListEditEmp.TxtboxHdmfNum.Text = Dtglist.CurrentRow.Cells("HdmfNum").Value
        EmpListEditEmp.TxtboxSalary.Text = Dtglist.CurrentRow.Cells("Salary").Value
        EmpListEditEmp.TxtboxRemarks.Text = Dtglist.CurrentRow.Cells("Remarks").Value
        EmpListEditEmp.CmboxStatus.Text = Dtglist.CurrentRow.Cells("Status").Value

        EmpListEditEmp.Show()

    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        RefreshEmpListDtglist()
        TxtboxSearch.Clear()
        CmboxType.SelectedIndex = -1
        CmboxStatus.SelectedIndex = -1
        CmboxCreatedBy.SelectedIndex = -1
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        Dim txtSearch As String = TxtboxSearch.Text

        Search("SELECT employeesnums.EmployeeNo,
                        employees.AcctNo,
                        FullName,
                        LastName,
                        Suffix,
                        Appellation,
                        FirstName,
                        MiddleName,
                        BirthDate,
                        Salary,
                        Type,
                        Position,
                        Remarks,
                        SssNum,
                        HdmfNum,
                        PhicNum,
                        Status,
                        AddedBy
                FROM employeesnums
                INNER JOIN employees
                ON employeesnums.AcctNo = employees.AcctNo
                WHERE
                (employeesnums.EmployeeNo LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (employees.AcctNo LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (FullName LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (LastName LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (Suffix LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (Appellation LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (FirstName LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (MiddleName LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (BirthDate LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (Salary LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (Position LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (Remarks LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (SssNum LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (HdmfNum LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%') OR
                (PhicNum LIKE '%" & txtSearch & "%' AND Type LIKE '%" & CmboxType.Text & "%' AND AddedBy LIKE '%" & CmboxCreatedBy.Text & "%' AND Status LIKE '%" & CmboxStatus.Text & "%')
                ", Dtglist, strCon)

        SortDtglist()
    End Sub

    Private Sub Dtglist_Sorted(sender As Object, e As EventArgs) Handles Dtglist.Sorted
        Dtglist.ClearSelection() 'un-highlights the datagridiew

        For Each row As DataGridViewRow In Dtglist.Rows
            ' iterating dtglist rows
            If row.Cells("STATUS").Value = "ACTIVE" Then
                ' if the user is currently ACTIVE
                row.DefaultCellStyle.BackColor = Color.FromArgb(48, 150, 23)
                row.DefaultCellStyle.ForeColor = Color.White
            End If

            If row.Cells("STATUS").Value = "INACTIVE" Then
                ' if the user is currently INACTIVE
                row.DefaultCellStyle.BackColor = Color.FromArgb(224, 58, 58)
                row.DefaultCellStyle.ForeColor = Color.White
            End If
        Next
    End Sub
End Class