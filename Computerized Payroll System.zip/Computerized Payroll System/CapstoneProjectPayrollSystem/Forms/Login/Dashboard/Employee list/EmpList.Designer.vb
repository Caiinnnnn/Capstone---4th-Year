﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EmpList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.BtnCreate = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.LblCount = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.CmboxStatus = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.BtnClear = New Guna.UI2.WinForms.Guna2Button()
        Me.CmboxCreatedBy = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.CmboxType = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.BtnSearch = New Guna.UI2.WinForms.Guna2Button()
        Me.TxtboxSearch = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Dtglist = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.EmployeeNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AcctNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FullName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Suffix = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Appellation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MiddleName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BirthDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Salary = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Type = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Position = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Remarks = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SssNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HdmfNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhicNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddedBy = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.LblCountActive = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.LblCountInactive = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel2.SuspendLayout()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.Guna2Panel1.SuspendLayout()
        CType(Me.Dtglist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.White
        Me.Guna2Panel2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel2.BorderThickness = 1
        Me.Guna2Panel2.Controls.Add(Me.BtnCreate)
        Me.Guna2Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Guna2Panel2.Location = New System.Drawing.Point(0, 596)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(1350, 133)
        Me.Guna2Panel2.TabIndex = 1
        '
        'BtnCreate
        '
        Me.BtnCreate.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnCreate.BorderThickness = 1
        Me.BtnCreate.CheckedState.Parent = Me.BtnCreate
        Me.BtnCreate.CustomImages.Parent = Me.BtnCreate
        Me.BtnCreate.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnCreate.ForeColor = System.Drawing.Color.White
        Me.BtnCreate.HoverState.Parent = Me.BtnCreate
        Me.BtnCreate.Location = New System.Drawing.Point(33, 49)
        Me.BtnCreate.Name = "BtnCreate"
        Me.BtnCreate.ShadowDecoration.Parent = Me.BtnCreate
        Me.BtnCreate.Size = New System.Drawing.Size(180, 45)
        Me.BtnCreate.TabIndex = 0
        Me.BtnCreate.Text = "CREATE"
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.Controls.Add(Me.LblCountInactive)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Guna2GroupBox1.Controls.Add(Me.LblCountActive)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Guna2GroupBox1.Controls.Add(Me.LblCount)
        Me.Guna2GroupBox1.Controls.Add(Me.CmboxStatus)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Guna2GroupBox1.Controls.Add(Me.BtnClear)
        Me.Guna2GroupBox1.Controls.Add(Me.CmboxCreatedBy)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2GroupBox1.Controls.Add(Me.CmboxType)
        Me.Guna2GroupBox1.Controls.Add(Me.BtnSearch)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxSearch)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(1350, 150)
        Me.Guna2GroupBox1.TabIndex = 2
        Me.Guna2GroupBox1.Text = "EMPLOYEE MASTER LIST"
        Me.Guna2GroupBox1.TextOffset = New System.Drawing.Point(0, -10)
        '
        'LblCount
        '
        Me.LblCount.BackColor = System.Drawing.Color.Transparent
        Me.LblCount.ForeColor = System.Drawing.Color.Black
        Me.LblCount.Location = New System.Drawing.Point(101, 33)
        Me.LblCount.Name = "LblCount"
        Me.LblCount.Size = New System.Drawing.Size(52, 17)
        Me.LblCount.TabIndex = 9
        Me.LblCount.Text = "LblCount"
        '
        'CmboxStatus
        '
        Me.CmboxStatus.BackColor = System.Drawing.Color.Transparent
        Me.CmboxStatus.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.CmboxStatus.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxStatus.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxStatus.FocusedState.Parent = Me.CmboxStatus
        Me.CmboxStatus.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxStatus.ForeColor = System.Drawing.Color.Black
        Me.CmboxStatus.FormattingEnabled = True
        Me.CmboxStatus.HoverState.Parent = Me.CmboxStatus
        Me.CmboxStatus.ItemHeight = 15
        Me.CmboxStatus.Items.AddRange(New Object() {"ACTIVE", "INACTIVE"})
        Me.CmboxStatus.ItemsAppearance.Parent = Me.CmboxStatus
        Me.CmboxStatus.Location = New System.Drawing.Point(819, 123)
        Me.CmboxStatus.Name = "CmboxStatus"
        Me.CmboxStatus.ShadowDecoration.Parent = Me.CmboxStatus
        Me.CmboxStatus.Size = New System.Drawing.Size(113, 21)
        Me.CmboxStatus.TabIndex = 8
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(777, 127)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(36, 15)
        Me.Guna2HtmlLabel3.TabIndex = 7
        Me.Guna2HtmlLabel3.Text = "Status:"
        '
        'BtnClear
        '
        Me.BtnClear.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnClear.BorderThickness = 1
        Me.BtnClear.CheckedState.Parent = Me.BtnClear
        Me.BtnClear.CustomImages.Parent = Me.BtnClear
        Me.BtnClear.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnClear.ForeColor = System.Drawing.Color.White
        Me.BtnClear.HoverState.Parent = Me.BtnClear
        Me.BtnClear.Location = New System.Drawing.Point(951, 123)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.ShadowDecoration.Parent = Me.BtnClear
        Me.BtnClear.Size = New System.Drawing.Size(80, 20)
        Me.BtnClear.TabIndex = 6
        Me.BtnClear.Text = "Clear"
        '
        'CmboxCreatedBy
        '
        Me.CmboxCreatedBy.BackColor = System.Drawing.Color.Transparent
        Me.CmboxCreatedBy.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.CmboxCreatedBy.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxCreatedBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxCreatedBy.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxCreatedBy.FocusedState.Parent = Me.CmboxCreatedBy
        Me.CmboxCreatedBy.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxCreatedBy.ForeColor = System.Drawing.Color.Black
        Me.CmboxCreatedBy.FormattingEnabled = True
        Me.CmboxCreatedBy.HoverState.Parent = Me.CmboxCreatedBy
        Me.CmboxCreatedBy.ItemHeight = 15
        Me.CmboxCreatedBy.ItemsAppearance.Parent = Me.CmboxCreatedBy
        Me.CmboxCreatedBy.Location = New System.Drawing.Point(609, 123)
        Me.CmboxCreatedBy.Name = "CmboxCreatedBy"
        Me.CmboxCreatedBy.ShadowDecoration.Parent = Me.CmboxCreatedBy
        Me.CmboxCreatedBy.Size = New System.Drawing.Size(140, 21)
        Me.CmboxCreatedBy.TabIndex = 5
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(545, 127)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(58, 15)
        Me.Guna2HtmlLabel2.TabIndex = 4
        Me.Guna2HtmlLabel2.Text = "Created By:"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(377, 127)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(30, 15)
        Me.Guna2HtmlLabel1.TabIndex = 3
        Me.Guna2HtmlLabel1.Text = "Type:"
        '
        'CmboxType
        '
        Me.CmboxType.BackColor = System.Drawing.Color.Transparent
        Me.CmboxType.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.CmboxType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxType.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxType.FocusedState.Parent = Me.CmboxType
        Me.CmboxType.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxType.ForeColor = System.Drawing.Color.Black
        Me.CmboxType.FormattingEnabled = True
        Me.CmboxType.HoverState.Parent = Me.CmboxType
        Me.CmboxType.ItemHeight = 15
        Me.CmboxType.Items.AddRange(New Object() {"ELEM", "HS", "NTP"})
        Me.CmboxType.ItemsAppearance.Parent = Me.CmboxType
        Me.CmboxType.Location = New System.Drawing.Point(414, 124)
        Me.CmboxType.Name = "CmboxType"
        Me.CmboxType.ShadowDecoration.Parent = Me.CmboxType
        Me.CmboxType.Size = New System.Drawing.Size(84, 21)
        Me.CmboxType.TabIndex = 2
        '
        'BtnSearch
        '
        Me.BtnSearch.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSearch.BorderThickness = 1
        Me.BtnSearch.CheckedState.Parent = Me.BtnSearch
        Me.BtnSearch.CustomImages.Parent = Me.BtnSearch
        Me.BtnSearch.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSearch.ForeColor = System.Drawing.Color.White
        Me.BtnSearch.HoverState.Parent = Me.BtnSearch
        Me.BtnSearch.Location = New System.Drawing.Point(220, 124)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.ShadowDecoration.Parent = Me.BtnSearch
        Me.BtnSearch.Size = New System.Drawing.Size(100, 20)
        Me.BtnSearch.TabIndex = 1
        Me.BtnSearch.Text = "Search"
        '
        'TxtboxSearch
        '
        Me.TxtboxSearch.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxSearch.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxSearch.DefaultText = ""
        Me.TxtboxSearch.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxSearch.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxSearch.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSearch.DisabledState.Parent = Me.TxtboxSearch
        Me.TxtboxSearch.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSearch.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSearch.FocusedState.Parent = Me.TxtboxSearch
        Me.TxtboxSearch.ForeColor = System.Drawing.Color.Black
        Me.TxtboxSearch.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSearch.HoverState.Parent = Me.TxtboxSearch
        Me.TxtboxSearch.Location = New System.Drawing.Point(13, 124)
        Me.TxtboxSearch.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxSearch.Name = "TxtboxSearch"
        Me.TxtboxSearch.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxSearch.PlaceholderText = ""
        Me.TxtboxSearch.SelectedText = ""
        Me.TxtboxSearch.ShadowDecoration.Parent = Me.TxtboxSearch
        Me.TxtboxSearch.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxSearch.TabIndex = 0
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel1.BorderThickness = 1
        Me.Guna2Panel1.Controls.Add(Me.Dtglist)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 150)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(1350, 446)
        Me.Guna2Panel1.TabIndex = 3
        '
        'Dtglist
        '
        Me.Dtglist.AllowUserToAddRows = False
        Me.Dtglist.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.Dtglist.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dtglist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Dtglist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Dtglist.BackgroundColor = System.Drawing.Color.White
        Me.Dtglist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dtglist.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Dtglist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dtglist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dtglist.ColumnHeadersHeight = 25
        Me.Dtglist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dtglist.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.EmployeeNo, Me.AcctNo, Me.FullName, Me.LastName, Me.Suffix, Me.Appellation, Me.FirstName, Me.MiddleName, Me.BirthDate, Me.Salary, Me.Type, Me.Position, Me.Remarks, Me.SssNum, Me.HdmfNum, Me.PhicNum, Me.Status, Me.AddedBy})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Dtglist.DefaultCellStyle = DataGridViewCellStyle3
        Me.Dtglist.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dtglist.EnableHeadersVisualStyles = False
        Me.Dtglist.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Dtglist.Location = New System.Drawing.Point(0, 0)
        Me.Dtglist.Name = "Dtglist"
        Me.Dtglist.ReadOnly = True
        Me.Dtglist.RowHeadersVisible = False
        Me.Dtglist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dtglist.Size = New System.Drawing.Size(1350, 446)
        Me.Dtglist.TabIndex = 0
        Me.Dtglist.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.Dtglist.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Dtglist.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.Dtglist.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.Dtglist.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Dtglist.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.Dtglist.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dtglist.ThemeStyle.HeaderStyle.Height = 25
        Me.Dtglist.ThemeStyle.ReadOnly = True
        Me.Dtglist.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Dtglist.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Dtglist.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Dtglist.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.Dtglist.ThemeStyle.RowsStyle.Height = 22
        Me.Dtglist.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        Me.Dtglist.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'EmployeeNo
        '
        Me.EmployeeNo.DataPropertyName = "EmployeeNo"
        Me.EmployeeNo.HeaderText = "EMP NO"
        Me.EmployeeNo.Name = "EmployeeNo"
        Me.EmployeeNo.ReadOnly = True
        Me.EmployeeNo.Width = 85
        '
        'AcctNo
        '
        Me.AcctNo.DataPropertyName = "AcctNo"
        Me.AcctNo.HeaderText = "ACC NO"
        Me.AcctNo.Name = "AcctNo"
        Me.AcctNo.ReadOnly = True
        Me.AcctNo.Width = 84
        '
        'FullName
        '
        Me.FullName.DataPropertyName = "FullName"
        Me.FullName.HeaderText = "FULL NAME"
        Me.FullName.Name = "FullName"
        Me.FullName.ReadOnly = True
        Me.FullName.Width = 106
        '
        'LastName
        '
        Me.LastName.DataPropertyName = "LastName"
        Me.LastName.HeaderText = "LAST NAME"
        Me.LastName.Name = "LastName"
        Me.LastName.ReadOnly = True
        Me.LastName.Width = 105
        '
        'Suffix
        '
        Me.Suffix.DataPropertyName = "Suffix"
        Me.Suffix.HeaderText = "SUFFIX"
        Me.Suffix.Name = "Suffix"
        Me.Suffix.ReadOnly = True
        Me.Suffix.Width = 75
        '
        'Appellation
        '
        Me.Appellation.DataPropertyName = "Appellation"
        Me.Appellation.HeaderText = "APPELLATION"
        Me.Appellation.Name = "Appellation"
        Me.Appellation.ReadOnly = True
        Me.Appellation.Width = 118
        '
        'FirstName
        '
        Me.FirstName.DataPropertyName = "FirstName"
        Me.FirstName.HeaderText = "FIRST NAME"
        Me.FirstName.Name = "FirstName"
        Me.FirstName.ReadOnly = True
        Me.FirstName.Width = 108
        '
        'MiddleName
        '
        Me.MiddleName.DataPropertyName = "MiddleName"
        Me.MiddleName.HeaderText = "MIDDLE NAME"
        Me.MiddleName.Name = "MiddleName"
        Me.MiddleName.ReadOnly = True
        Me.MiddleName.Width = 126
        '
        'BirthDate
        '
        Me.BirthDate.DataPropertyName = "BirthDate"
        Me.BirthDate.HeaderText = "BIRTH DATE"
        Me.BirthDate.Name = "BirthDate"
        Me.BirthDate.ReadOnly = True
        Me.BirthDate.Width = 104
        '
        'Salary
        '
        Me.Salary.DataPropertyName = "Salary"
        Me.Salary.HeaderText = "SALARY"
        Me.Salary.Name = "Salary"
        Me.Salary.ReadOnly = True
        Me.Salary.Width = 80
        '
        'Type
        '
        Me.Type.DataPropertyName = "Type"
        Me.Type.HeaderText = "TYPE"
        Me.Type.Name = "Type"
        Me.Type.ReadOnly = True
        Me.Type.Width = 62
        '
        'Position
        '
        Me.Position.DataPropertyName = "Position"
        Me.Position.HeaderText = "POSITION"
        Me.Position.Name = "Position"
        Me.Position.ReadOnly = True
        Me.Position.Width = 94
        '
        'Remarks
        '
        Me.Remarks.DataPropertyName = "Remarks"
        Me.Remarks.HeaderText = "REMARKS"
        Me.Remarks.Name = "Remarks"
        Me.Remarks.ReadOnly = True
        Me.Remarks.Width = 92
        '
        'SssNum
        '
        Me.SssNum.DataPropertyName = "SssNum"
        Me.SssNum.HeaderText = "SSS NUM"
        Me.SssNum.Name = "SssNum"
        Me.SssNum.ReadOnly = True
        Me.SssNum.Width = 90
        '
        'HdmfNum
        '
        Me.HdmfNum.DataPropertyName = "HdmfNum"
        Me.HdmfNum.HeaderText = "HDMF NUM"
        Me.HdmfNum.Name = "HdmfNum"
        Me.HdmfNum.ReadOnly = True
        Me.HdmfNum.Width = 109
        '
        'PhicNum
        '
        Me.PhicNum.DataPropertyName = "PhicNum"
        Me.PhicNum.HeaderText = "PHIC NUM"
        Me.PhicNum.Name = "PhicNum"
        Me.PhicNum.ReadOnly = True
        '
        'Status
        '
        Me.Status.DataPropertyName = "Status"
        Me.Status.HeaderText = "STATUS"
        Me.Status.Name = "Status"
        Me.Status.ReadOnly = True
        Me.Status.Width = 77
        '
        'AddedBy
        '
        Me.AddedBy.DataPropertyName = "AddedBy"
        Me.AddedBy.HeaderText = "ADDED BY"
        Me.AddedBy.Name = "AddedBy"
        Me.AddedBy.ReadOnly = True
        Me.AddedBy.Width = 98
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(13, 33)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(82, 17)
        Me.Guna2HtmlLabel4.TabIndex = 10
        Me.Guna2HtmlLabel4.Text = "Total record(s):"
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(56, 56)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(39, 17)
        Me.Guna2HtmlLabel5.TabIndex = 11
        Me.Guna2HtmlLabel5.Text = "Active:"
        '
        'LblCountActive
        '
        Me.LblCountActive.BackColor = System.Drawing.Color.Transparent
        Me.LblCountActive.ForeColor = System.Drawing.Color.Black
        Me.LblCountActive.Location = New System.Drawing.Point(101, 56)
        Me.LblCountActive.Name = "LblCountActive"
        Me.LblCountActive.Size = New System.Drawing.Size(85, 17)
        Me.LblCountActive.TabIndex = 12
        Me.LblCountActive.Text = "LblCountActive"
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(48, 79)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(47, 17)
        Me.Guna2HtmlLabel6.TabIndex = 13
        Me.Guna2HtmlLabel6.Text = "Inactive:"
        '
        'LblCountInactive
        '
        Me.LblCountInactive.BackColor = System.Drawing.Color.Transparent
        Me.LblCountInactive.ForeColor = System.Drawing.Color.Black
        Me.LblCountInactive.Location = New System.Drawing.Point(101, 81)
        Me.LblCountInactive.Name = "LblCountInactive"
        Me.LblCountInactive.Size = New System.Drawing.Size(93, 17)
        Me.LblCountInactive.TabIndex = 14
        Me.LblCountInactive.Text = "LblCountInactive"
        '
        'EmpList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1350, 729)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.MinimumSize = New System.Drawing.Size(1364, 726)
        Me.Name = "EmpList"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EMPLOYEE LIST"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox1.PerformLayout()
        Me.Guna2Panel1.ResumeLayout(False)
        CType(Me.Dtglist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Dtglist As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents TxtboxSearch As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents BtnSearch As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents CmboxType As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents CmboxCreatedBy As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents BtnClear As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnCreate As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents CmboxStatus As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents EmployeeNo As DataGridViewTextBoxColumn
    Friend WithEvents AcctNo As DataGridViewTextBoxColumn
    Friend WithEvents FullName As DataGridViewTextBoxColumn
    Friend WithEvents LastName As DataGridViewTextBoxColumn
    Friend WithEvents Suffix As DataGridViewTextBoxColumn
    Friend WithEvents Appellation As DataGridViewTextBoxColumn
    Friend WithEvents FirstName As DataGridViewTextBoxColumn
    Friend WithEvents MiddleName As DataGridViewTextBoxColumn
    Friend WithEvents BirthDate As DataGridViewTextBoxColumn
    Friend WithEvents Salary As DataGridViewTextBoxColumn
    Friend WithEvents Type As DataGridViewTextBoxColumn
    Friend WithEvents Position As DataGridViewTextBoxColumn
    Friend WithEvents Remarks As DataGridViewTextBoxColumn
    Friend WithEvents SssNum As DataGridViewTextBoxColumn
    Friend WithEvents HdmfNum As DataGridViewTextBoxColumn
    Friend WithEvents PhicNum As DataGridViewTextBoxColumn
    Friend WithEvents Status As DataGridViewTextBoxColumn
    Friend WithEvents AddedBy As DataGridViewTextBoxColumn
    Friend WithEvents LblCount As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents LblCountActive As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents LblCountInactive As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
End Class
