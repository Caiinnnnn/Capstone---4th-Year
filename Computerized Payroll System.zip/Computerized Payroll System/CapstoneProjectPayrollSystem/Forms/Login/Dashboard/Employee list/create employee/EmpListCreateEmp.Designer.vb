﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EmpListCreateEmp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.BtnSave = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel16 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.CmboxStatus = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2HtmlLabel15 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxRemarks = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2Separator7 = New Guna.UI2.WinForms.Guna2Separator()
        Me.TxtboxSalary = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel14 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Separator5 = New Guna.UI2.WinForms.Guna2Separator()
        Me.Guna2HtmlLabel13 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel12 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxHdmfNum = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxPhicNum = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxSssNum = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel11 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Separator4 = New Guna.UI2.WinForms.Guna2Separator()
        Me.Guna2HtmlLabel10 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxPosition = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel9 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.CmboxType = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2Separator3 = New Guna.UI2.WinForms.Guna2Separator()
        Me.Guna2HtmlLabel8 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxEmployeeNo = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxAccNumber = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2Separator2 = New Guna.UI2.WinForms.Guna2Separator()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.DtpBirthDate = New Guna.UI2.WinForms.Guna2DateTimePicker()
        Me.Guna2Separator1 = New Guna.UI2.WinForms.Guna2Separator()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxMiddleName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxFirstName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxAppellation = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxSuffix = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxLastName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.Controls.Add(Me.BtnSave)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel16)
        Me.Guna2GroupBox1.Controls.Add(Me.CmboxStatus)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel15)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxRemarks)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Separator7)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxSalary)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel14)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Separator5)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel13)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel12)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxHdmfNum)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxPhicNum)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxSssNum)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel11)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Separator4)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel10)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxPosition)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel9)
        Me.Guna2GroupBox1.Controls.Add(Me.CmboxType)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Separator3)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel8)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxEmployeeNo)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel7)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxAccNumber)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Separator2)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Guna2GroupBox1.Controls.Add(Me.DtpBirthDate)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Separator1)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxMiddleName)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxFirstName)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxAppellation)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxSuffix)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxLastName)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(784, 561)
        Me.Guna2GroupBox1.TabIndex = 0
        Me.Guna2GroupBox1.Text = "CREATE EMPLOYEE"
        '
        'BtnSave
        '
        Me.BtnSave.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSave.BorderThickness = 1
        Me.BtnSave.CheckedState.Parent = Me.BtnSave
        Me.BtnSave.CustomImages.Parent = Me.BtnSave
        Me.BtnSave.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSave.ForeColor = System.Drawing.Color.White
        Me.BtnSave.HoverState.Parent = Me.BtnSave
        Me.BtnSave.Location = New System.Drawing.Point(10, 504)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.ShadowDecoration.Parent = Me.BtnSave
        Me.BtnSave.Size = New System.Drawing.Size(180, 45)
        Me.BtnSave.TabIndex = 39
        Me.BtnSave.Text = "SAVE"
        '
        'Guna2HtmlLabel16
        '
        Me.Guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel16.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel16.Location = New System.Drawing.Point(172, 445)
        Me.Guna2HtmlLabel16.Name = "Guna2HtmlLabel16"
        Me.Guna2HtmlLabel16.Size = New System.Drawing.Size(33, 15)
        Me.Guna2HtmlLabel16.TabIndex = 38
        Me.Guna2HtmlLabel16.TabStop = False
        Me.Guna2HtmlLabel16.Text = "Status"
        '
        'CmboxStatus
        '
        Me.CmboxStatus.BackColor = System.Drawing.Color.Transparent
        Me.CmboxStatus.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.CmboxStatus.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxStatus.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxStatus.FocusedState.Parent = Me.CmboxStatus
        Me.CmboxStatus.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxStatus.ForeColor = System.Drawing.Color.Black
        Me.CmboxStatus.FormattingEnabled = True
        Me.CmboxStatus.HoverState.Parent = Me.CmboxStatus
        Me.CmboxStatus.ItemHeight = 15
        Me.CmboxStatus.Items.AddRange(New Object() {"ACTIVE", "INACTIVE"})
        Me.CmboxStatus.ItemsAppearance.Parent = Me.CmboxStatus
        Me.CmboxStatus.Location = New System.Drawing.Point(172, 466)
        Me.CmboxStatus.Name = "CmboxStatus"
        Me.CmboxStatus.ShadowDecoration.Parent = Me.CmboxStatus
        Me.CmboxStatus.Size = New System.Drawing.Size(140, 21)
        Me.CmboxStatus.TabIndex = 37
        '
        'Guna2HtmlLabel15
        '
        Me.Guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel15.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel15.Location = New System.Drawing.Point(13, 443)
        Me.Guna2HtmlLabel15.Name = "Guna2HtmlLabel15"
        Me.Guna2HtmlLabel15.Size = New System.Drawing.Size(45, 15)
        Me.Guna2HtmlLabel15.TabIndex = 36
        Me.Guna2HtmlLabel15.TabStop = False
        Me.Guna2HtmlLabel15.Text = "Remarks"
        '
        'TxtboxRemarks
        '
        Me.TxtboxRemarks.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxRemarks.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxRemarks.DefaultText = ""
        Me.TxtboxRemarks.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxRemarks.DisabledState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxRemarks.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxRemarks.FocusedState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.ForeColor = System.Drawing.Color.Black
        Me.TxtboxRemarks.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxRemarks.HoverState.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.Location = New System.Drawing.Point(10, 466)
        Me.TxtboxRemarks.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.TxtboxRemarks.Name = "TxtboxRemarks"
        Me.TxtboxRemarks.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxRemarks.PlaceholderText = ""
        Me.TxtboxRemarks.SelectedText = ""
        Me.TxtboxRemarks.ShadowDecoration.Parent = Me.TxtboxRemarks
        Me.TxtboxRemarks.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxRemarks.TabIndex = 35
        '
        'Guna2Separator7
        '
        Me.Guna2Separator7.Location = New System.Drawing.Point(12, 427)
        Me.Guna2Separator7.Name = "Guna2Separator7"
        Me.Guna2Separator7.Size = New System.Drawing.Size(759, 10)
        Me.Guna2Separator7.TabIndex = 34
        Me.Guna2Separator7.TabStop = False
        '
        'TxtboxSalary
        '
        Me.TxtboxSalary.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxSalary.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxSalary.DefaultText = ""
        Me.TxtboxSalary.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxSalary.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxSalary.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSalary.DisabledState.Parent = Me.TxtboxSalary
        Me.TxtboxSalary.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSalary.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSalary.FocusedState.Parent = Me.TxtboxSalary
        Me.TxtboxSalary.ForeColor = System.Drawing.Color.Black
        Me.TxtboxSalary.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSalary.HoverState.Parent = Me.TxtboxSalary
        Me.TxtboxSalary.Location = New System.Drawing.Point(12, 401)
        Me.TxtboxSalary.Margin = New System.Windows.Forms.Padding(9, 3, 9, 3)
        Me.TxtboxSalary.Name = "TxtboxSalary"
        Me.TxtboxSalary.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxSalary.PlaceholderText = ""
        Me.TxtboxSalary.SelectedText = ""
        Me.TxtboxSalary.ShadowDecoration.Parent = Me.TxtboxSalary
        Me.TxtboxSalary.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxSalary.TabIndex = 32
        '
        'Guna2HtmlLabel14
        '
        Me.Guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel14.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel14.Location = New System.Drawing.Point(13, 378)
        Me.Guna2HtmlLabel14.Name = "Guna2HtmlLabel14"
        Me.Guna2HtmlLabel14.Size = New System.Drawing.Size(32, 15)
        Me.Guna2HtmlLabel14.TabIndex = 31
        Me.Guna2HtmlLabel14.TabStop = False
        Me.Guna2HtmlLabel14.Text = "Salary"
        '
        'Guna2Separator5
        '
        Me.Guna2Separator5.Location = New System.Drawing.Point(13, 362)
        Me.Guna2Separator5.Name = "Guna2Separator5"
        Me.Guna2Separator5.Size = New System.Drawing.Size(759, 10)
        Me.Guna2Separator5.TabIndex = 30
        Me.Guna2Separator5.TabStop = False
        '
        'Guna2HtmlLabel13
        '
        Me.Guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel13.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel13.Location = New System.Drawing.Point(337, 313)
        Me.Guna2HtmlLabel13.Name = "Guna2HtmlLabel13"
        Me.Guna2HtmlLabel13.Size = New System.Drawing.Size(59, 15)
        Me.Guna2HtmlLabel13.TabIndex = 29
        Me.Guna2HtmlLabel13.TabStop = False
        Me.Guna2HtmlLabel13.Text = "HDMF Num"
        '
        'Guna2HtmlLabel12
        '
        Me.Guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel12.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel12.Location = New System.Drawing.Point(172, 311)
        Me.Guna2HtmlLabel12.Name = "Guna2HtmlLabel12"
        Me.Guna2HtmlLabel12.Size = New System.Drawing.Size(53, 15)
        Me.Guna2HtmlLabel12.TabIndex = 28
        Me.Guna2HtmlLabel12.TabStop = False
        Me.Guna2HtmlLabel12.Text = "PHIC Num"
        '
        'TxtboxHdmfNum
        '
        Me.TxtboxHdmfNum.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxHdmfNum.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxHdmfNum.DefaultText = ""
        Me.TxtboxHdmfNum.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxHdmfNum.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxHdmfNum.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxHdmfNum.DisabledState.Parent = Me.TxtboxHdmfNum
        Me.TxtboxHdmfNum.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxHdmfNum.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxHdmfNum.FocusedState.Parent = Me.TxtboxHdmfNum
        Me.TxtboxHdmfNum.ForeColor = System.Drawing.Color.Black
        Me.TxtboxHdmfNum.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxHdmfNum.HoverState.Parent = Me.TxtboxHdmfNum
        Me.TxtboxHdmfNum.Location = New System.Drawing.Point(337, 336)
        Me.TxtboxHdmfNum.Margin = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.TxtboxHdmfNum.Name = "TxtboxHdmfNum"
        Me.TxtboxHdmfNum.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxHdmfNum.PlaceholderText = ""
        Me.TxtboxHdmfNum.SelectedText = ""
        Me.TxtboxHdmfNum.ShadowDecoration.Parent = Me.TxtboxHdmfNum
        Me.TxtboxHdmfNum.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxHdmfNum.TabIndex = 27
        '
        'TxtboxPhicNum
        '
        Me.TxtboxPhicNum.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxPhicNum.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPhicNum.DefaultText = ""
        Me.TxtboxPhicNum.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPhicNum.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPhicNum.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPhicNum.DisabledState.Parent = Me.TxtboxPhicNum
        Me.TxtboxPhicNum.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPhicNum.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPhicNum.FocusedState.Parent = Me.TxtboxPhicNum
        Me.TxtboxPhicNum.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPhicNum.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPhicNum.HoverState.Parent = Me.TxtboxPhicNum
        Me.TxtboxPhicNum.Location = New System.Drawing.Point(172, 336)
        Me.TxtboxPhicNum.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxPhicNum.Name = "TxtboxPhicNum"
        Me.TxtboxPhicNum.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPhicNum.PlaceholderText = ""
        Me.TxtboxPhicNum.SelectedText = ""
        Me.TxtboxPhicNum.ShadowDecoration.Parent = Me.TxtboxPhicNum
        Me.TxtboxPhicNum.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxPhicNum.TabIndex = 26
        '
        'TxtboxSssNum
        '
        Me.TxtboxSssNum.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxSssNum.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxSssNum.DefaultText = ""
        Me.TxtboxSssNum.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxSssNum.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxSssNum.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSssNum.DisabledState.Parent = Me.TxtboxSssNum
        Me.TxtboxSssNum.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSssNum.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSssNum.FocusedState.Parent = Me.TxtboxSssNum
        Me.TxtboxSssNum.ForeColor = System.Drawing.Color.Black
        Me.TxtboxSssNum.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSssNum.HoverState.Parent = Me.TxtboxSssNum
        Me.TxtboxSssNum.Location = New System.Drawing.Point(12, 336)
        Me.TxtboxSssNum.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxSssNum.Name = "TxtboxSssNum"
        Me.TxtboxSssNum.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxSssNum.PlaceholderText = ""
        Me.TxtboxSssNum.SelectedText = ""
        Me.TxtboxSssNum.ShadowDecoration.Parent = Me.TxtboxSssNum
        Me.TxtboxSssNum.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxSssNum.TabIndex = 25
        '
        'Guna2HtmlLabel11
        '
        Me.Guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel11.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel11.Location = New System.Drawing.Point(13, 313)
        Me.Guna2HtmlLabel11.Name = "Guna2HtmlLabel11"
        Me.Guna2HtmlLabel11.Size = New System.Drawing.Size(49, 15)
        Me.Guna2HtmlLabel11.TabIndex = 24
        Me.Guna2HtmlLabel11.TabStop = False
        Me.Guna2HtmlLabel11.Text = "SSS Num"
        '
        'Guna2Separator4
        '
        Me.Guna2Separator4.Location = New System.Drawing.Point(12, 297)
        Me.Guna2Separator4.Name = "Guna2Separator4"
        Me.Guna2Separator4.Size = New System.Drawing.Size(759, 10)
        Me.Guna2Separator4.TabIndex = 23
        Me.Guna2Separator4.TabStop = False
        '
        'Guna2HtmlLabel10
        '
        Me.Guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel10.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel10.Location = New System.Drawing.Point(172, 249)
        Me.Guna2HtmlLabel10.Name = "Guna2HtmlLabel10"
        Me.Guna2HtmlLabel10.Size = New System.Drawing.Size(40, 15)
        Me.Guna2HtmlLabel10.TabIndex = 22
        Me.Guna2HtmlLabel10.TabStop = False
        Me.Guna2HtmlLabel10.Text = "Position"
        '
        'TxtboxPosition
        '
        Me.TxtboxPosition.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxPosition.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPosition.DefaultText = ""
        Me.TxtboxPosition.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPosition.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPosition.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPosition.DisabledState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPosition.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPosition.FocusedState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPosition.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPosition.HoverState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.Location = New System.Drawing.Point(172, 270)
        Me.TxtboxPosition.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxPosition.Name = "TxtboxPosition"
        Me.TxtboxPosition.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPosition.PlaceholderText = ""
        Me.TxtboxPosition.SelectedText = ""
        Me.TxtboxPosition.ShadowDecoration.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxPosition.TabIndex = 21
        '
        'Guna2HtmlLabel9
        '
        Me.Guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel9.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel9.Location = New System.Drawing.Point(13, 249)
        Me.Guna2HtmlLabel9.Name = "Guna2HtmlLabel9"
        Me.Guna2HtmlLabel9.Size = New System.Drawing.Size(27, 15)
        Me.Guna2HtmlLabel9.TabIndex = 20
        Me.Guna2HtmlLabel9.TabStop = False
        Me.Guna2HtmlLabel9.Text = "Type"
        '
        'CmboxType
        '
        Me.CmboxType.BackColor = System.Drawing.Color.Transparent
        Me.CmboxType.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.CmboxType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxType.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxType.FocusedState.Parent = Me.CmboxType
        Me.CmboxType.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxType.ForeColor = System.Drawing.Color.Black
        Me.CmboxType.FormattingEnabled = True
        Me.CmboxType.HoverState.Parent = Me.CmboxType
        Me.CmboxType.ItemHeight = 15
        Me.CmboxType.Items.AddRange(New Object() {"ELEM", "HS", "NTP"})
        Me.CmboxType.ItemsAppearance.Parent = Me.CmboxType
        Me.CmboxType.Location = New System.Drawing.Point(13, 270)
        Me.CmboxType.Name = "CmboxType"
        Me.CmboxType.ShadowDecoration.Parent = Me.CmboxType
        Me.CmboxType.Size = New System.Drawing.Size(149, 21)
        Me.CmboxType.TabIndex = 19
        '
        'Guna2Separator3
        '
        Me.Guna2Separator3.Location = New System.Drawing.Point(12, 235)
        Me.Guna2Separator3.Name = "Guna2Separator3"
        Me.Guna2Separator3.Size = New System.Drawing.Size(759, 10)
        Me.Guna2Separator3.TabIndex = 18
        Me.Guna2Separator3.TabStop = False
        '
        'Guna2HtmlLabel8
        '
        Me.Guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel8.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel8.Location = New System.Drawing.Point(172, 183)
        Me.Guna2HtmlLabel8.Name = "Guna2HtmlLabel8"
        Me.Guna2HtmlLabel8.Size = New System.Drawing.Size(64, 15)
        Me.Guna2HtmlLabel8.TabIndex = 17
        Me.Guna2HtmlLabel8.TabStop = False
        Me.Guna2HtmlLabel8.Text = "Employee no"
        '
        'TxtboxEmployeeNo
        '
        Me.TxtboxEmployeeNo.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxEmployeeNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxEmployeeNo.DefaultText = ""
        Me.TxtboxEmployeeNo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxEmployeeNo.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxEmployeeNo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxEmployeeNo.DisabledState.Parent = Me.TxtboxEmployeeNo
        Me.TxtboxEmployeeNo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxEmployeeNo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxEmployeeNo.FocusedState.Parent = Me.TxtboxEmployeeNo
        Me.TxtboxEmployeeNo.ForeColor = System.Drawing.Color.Black
        Me.TxtboxEmployeeNo.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxEmployeeNo.HoverState.Parent = Me.TxtboxEmployeeNo
        Me.TxtboxEmployeeNo.Location = New System.Drawing.Point(172, 209)
        Me.TxtboxEmployeeNo.Margin = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.TxtboxEmployeeNo.Name = "TxtboxEmployeeNo"
        Me.TxtboxEmployeeNo.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxEmployeeNo.PlaceholderText = ""
        Me.TxtboxEmployeeNo.SelectedText = ""
        Me.TxtboxEmployeeNo.ShadowDecoration.Parent = Me.TxtboxEmployeeNo
        Me.TxtboxEmployeeNo.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxEmployeeNo.TabIndex = 16
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(13, 183)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(81, 15)
        Me.Guna2HtmlLabel7.TabIndex = 15
        Me.Guna2HtmlLabel7.TabStop = False
        Me.Guna2HtmlLabel7.Text = "Account number"
        '
        'TxtboxAccNumber
        '
        Me.TxtboxAccNumber.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAccNumber.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAccNumber.DefaultText = ""
        Me.TxtboxAccNumber.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAccNumber.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAccNumber.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAccNumber.DisabledState.Parent = Me.TxtboxAccNumber
        Me.TxtboxAccNumber.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAccNumber.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAccNumber.FocusedState.Parent = Me.TxtboxAccNumber
        Me.TxtboxAccNumber.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAccNumber.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAccNumber.HoverState.Parent = Me.TxtboxAccNumber
        Me.TxtboxAccNumber.Location = New System.Drawing.Point(12, 209)
        Me.TxtboxAccNumber.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxAccNumber.Name = "TxtboxAccNumber"
        Me.TxtboxAccNumber.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAccNumber.PlaceholderText = ""
        Me.TxtboxAccNumber.SelectedText = ""
        Me.TxtboxAccNumber.ShadowDecoration.Parent = Me.TxtboxAccNumber
        Me.TxtboxAccNumber.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxAccNumber.TabIndex = 14
        '
        'Guna2Separator2
        '
        Me.Guna2Separator2.Location = New System.Drawing.Point(12, 167)
        Me.Guna2Separator2.Name = "Guna2Separator2"
        Me.Guna2Separator2.Size = New System.Drawing.Size(759, 10)
        Me.Guna2Separator2.TabIndex = 13
        Me.Guna2Separator2.TabStop = False
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(13, 118)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(50, 15)
        Me.Guna2HtmlLabel6.TabIndex = 12
        Me.Guna2HtmlLabel6.TabStop = False
        Me.Guna2HtmlLabel6.Text = "Birth Date"
        '
        'DtpBirthDate
        '
        Me.DtpBirthDate.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.DtpBirthDate.BorderThickness = 1
        Me.DtpBirthDate.CheckedState.Parent = Me.DtpBirthDate
        Me.DtpBirthDate.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DtpBirthDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtpBirthDate.HoverState.Parent = Me.DtpBirthDate
        Me.DtpBirthDate.Location = New System.Drawing.Point(12, 141)
        Me.DtpBirthDate.MaxDate = New Date(9998, 12, 31, 0, 0, 0, 0)
        Me.DtpBirthDate.MinDate = New Date(1753, 1, 1, 0, 0, 0, 0)
        Me.DtpBirthDate.Name = "DtpBirthDate"
        Me.DtpBirthDate.ShadowDecoration.Parent = Me.DtpBirthDate
        Me.DtpBirthDate.Size = New System.Drawing.Size(150, 20)
        Me.DtpBirthDate.TabIndex = 11
        Me.DtpBirthDate.Value = New Date(2024, 3, 20, 16, 46, 20, 976)
        '
        'Guna2Separator1
        '
        Me.Guna2Separator1.Location = New System.Drawing.Point(12, 102)
        Me.Guna2Separator1.Name = "Guna2Separator1"
        Me.Guna2Separator1.Size = New System.Drawing.Size(759, 10)
        Me.Guna2Separator1.TabIndex = 10
        Me.Guna2Separator1.TabStop = False
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(511, 53)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(65, 15)
        Me.Guna2HtmlLabel5.TabIndex = 9
        Me.Guna2HtmlLabel5.TabStop = False
        Me.Guna2HtmlLabel5.Text = "Middle Name"
        '
        'TxtboxMiddleName
        '
        Me.TxtboxMiddleName.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxMiddleName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxMiddleName.DefaultText = ""
        Me.TxtboxMiddleName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxMiddleName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxMiddleName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxMiddleName.DisabledState.Parent = Me.TxtboxMiddleName
        Me.TxtboxMiddleName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxMiddleName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxMiddleName.FocusedState.Parent = Me.TxtboxMiddleName
        Me.TxtboxMiddleName.ForeColor = System.Drawing.Color.Black
        Me.TxtboxMiddleName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxMiddleName.HoverState.Parent = Me.TxtboxMiddleName
        Me.TxtboxMiddleName.Location = New System.Drawing.Point(511, 76)
        Me.TxtboxMiddleName.Margin = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.TxtboxMiddleName.Name = "TxtboxMiddleName"
        Me.TxtboxMiddleName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxMiddleName.PlaceholderText = ""
        Me.TxtboxMiddleName.SelectedText = ""
        Me.TxtboxMiddleName.ShadowDecoration.Parent = Me.TxtboxMiddleName
        Me.TxtboxMiddleName.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxMiddleName.TabIndex = 8
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(346, 53)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(53, 15)
        Me.Guna2HtmlLabel4.TabIndex = 7
        Me.Guna2HtmlLabel4.TabStop = False
        Me.Guna2HtmlLabel4.Text = "First Name"
        '
        'TxtboxFirstName
        '
        Me.TxtboxFirstName.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxFirstName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxFirstName.DefaultText = ""
        Me.TxtboxFirstName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxFirstName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxFirstName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxFirstName.DisabledState.Parent = Me.TxtboxFirstName
        Me.TxtboxFirstName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxFirstName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxFirstName.FocusedState.Parent = Me.TxtboxFirstName
        Me.TxtboxFirstName.ForeColor = System.Drawing.Color.Black
        Me.TxtboxFirstName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxFirstName.HoverState.Parent = Me.TxtboxFirstName
        Me.TxtboxFirstName.Location = New System.Drawing.Point(346, 76)
        Me.TxtboxFirstName.Margin = New System.Windows.Forms.Padding(7, 3, 7, 3)
        Me.TxtboxFirstName.Name = "TxtboxFirstName"
        Me.TxtboxFirstName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxFirstName.PlaceholderText = ""
        Me.TxtboxFirstName.SelectedText = ""
        Me.TxtboxFirstName.ShadowDecoration.Parent = Me.TxtboxFirstName
        Me.TxtboxFirstName.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxFirstName.TabIndex = 6
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(253, 53)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(71, 15)
        Me.Guna2HtmlLabel3.TabIndex = 5
        Me.Guna2HtmlLabel3.TabStop = False
        Me.Guna2HtmlLabel3.Text = "Appel (ex. Ma)"
        '
        'TxtboxAppellation
        '
        Me.TxtboxAppellation.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxAppellation.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxAppellation.DefaultText = ""
        Me.TxtboxAppellation.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxAppellation.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxAppellation.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAppellation.DisabledState.Parent = Me.TxtboxAppellation
        Me.TxtboxAppellation.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxAppellation.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAppellation.FocusedState.Parent = Me.TxtboxAppellation
        Me.TxtboxAppellation.ForeColor = System.Drawing.Color.Black
        Me.TxtboxAppellation.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxAppellation.HoverState.Parent = Me.TxtboxAppellation
        Me.TxtboxAppellation.Location = New System.Drawing.Point(253, 76)
        Me.TxtboxAppellation.Margin = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.TxtboxAppellation.Name = "TxtboxAppellation"
        Me.TxtboxAppellation.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxAppellation.PlaceholderText = ""
        Me.TxtboxAppellation.SelectedText = ""
        Me.TxtboxAppellation.ShadowDecoration.Parent = Me.TxtboxAppellation
        Me.TxtboxAppellation.Size = New System.Drawing.Size(80, 20)
        Me.TxtboxAppellation.TabIndex = 4
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(172, 53)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(63, 15)
        Me.Guna2HtmlLabel2.TabIndex = 3
        Me.Guna2HtmlLabel2.TabStop = False
        Me.Guna2HtmlLabel2.Text = "Suffix (ex. Jr)"
        '
        'TxtboxSuffix
        '
        Me.TxtboxSuffix.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxSuffix.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxSuffix.DefaultText = ""
        Me.TxtboxSuffix.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxSuffix.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxSuffix.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSuffix.DisabledState.Parent = Me.TxtboxSuffix
        Me.TxtboxSuffix.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSuffix.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSuffix.FocusedState.Parent = Me.TxtboxSuffix
        Me.TxtboxSuffix.ForeColor = System.Drawing.Color.Black
        Me.TxtboxSuffix.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSuffix.HoverState.Parent = Me.TxtboxSuffix
        Me.TxtboxSuffix.Location = New System.Drawing.Point(172, 76)
        Me.TxtboxSuffix.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxSuffix.Name = "TxtboxSuffix"
        Me.TxtboxSuffix.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxSuffix.PlaceholderText = ""
        Me.TxtboxSuffix.SelectedText = ""
        Me.TxtboxSuffix.ShadowDecoration.Parent = Me.TxtboxSuffix
        Me.TxtboxSuffix.Size = New System.Drawing.Size(70, 20)
        Me.TxtboxSuffix.TabIndex = 2
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(13, 53)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(54, 15)
        Me.Guna2HtmlLabel1.TabIndex = 1
        Me.Guna2HtmlLabel1.TabStop = False
        Me.Guna2HtmlLabel1.Text = "Last Name"
        '
        'TxtboxLastName
        '
        Me.TxtboxLastName.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.TxtboxLastName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxLastName.DefaultText = ""
        Me.TxtboxLastName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxLastName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxLastName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxLastName.DisabledState.Parent = Me.TxtboxLastName
        Me.TxtboxLastName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxLastName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxLastName.FocusedState.Parent = Me.TxtboxLastName
        Me.TxtboxLastName.ForeColor = System.Drawing.Color.Black
        Me.TxtboxLastName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxLastName.HoverState.Parent = Me.TxtboxLastName
        Me.TxtboxLastName.Location = New System.Drawing.Point(13, 76)
        Me.TxtboxLastName.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxLastName.Name = "TxtboxLastName"
        Me.TxtboxLastName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxLastName.PlaceholderText = ""
        Me.TxtboxLastName.SelectedText = ""
        Me.TxtboxLastName.ShadowDecoration.Parent = Me.TxtboxLastName
        Me.TxtboxLastName.Size = New System.Drawing.Size(150, 20)
        Me.TxtboxLastName.TabIndex = 0
        '
        'EmpListCreateEmp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 561)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.Name = "EmpListCreateEmp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EmpListCreateEmp"
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxLastName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxSuffix As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxAppellation As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxMiddleName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxFirstName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents DtpBirthDate As Guna.UI2.WinForms.Guna2DateTimePicker
    Friend WithEvents Guna2Separator1 As Guna.UI2.WinForms.Guna2Separator
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel8 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxEmployeeNo As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxAccNumber As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2Separator2 As Guna.UI2.WinForms.Guna2Separator
    Friend WithEvents CmboxType As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2Separator3 As Guna.UI2.WinForms.Guna2Separator
    Friend WithEvents Guna2HtmlLabel10 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxPosition As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel9 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Separator4 As Guna.UI2.WinForms.Guna2Separator
    Friend WithEvents TxtboxPhicNum As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxSssNum As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel13 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel12 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxHdmfNum As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel11 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Separator5 As Guna.UI2.WinForms.Guna2Separator
    Friend WithEvents TxtboxSalary As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel14 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel16 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents CmboxStatus As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2HtmlLabel15 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxRemarks As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2Separator7 As Guna.UI2.WinForms.Guna2Separator
    Friend WithEvents BtnSave As Guna.UI2.WinForms.Guna2Button
End Class
