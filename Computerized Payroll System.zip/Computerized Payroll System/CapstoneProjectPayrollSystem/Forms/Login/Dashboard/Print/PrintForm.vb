﻿Public Class PrintForm
    Private Sub BtnNetPay_Click(sender As Object, e As EventArgs) Handles BtnNetPay.Click
        If Dashboard.UserPayrollDtglist.RowCount <= 0 Then
            Exit Sub
        End If

        Dim payrollNo As String = Dashboard.UserPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value

        Dim tblPrintNetPay As New DataTable

        tblPrintNetPay.Columns.Add("EmployeeNo")
        tblPrintNetPay.Columns.Add("AcctNo")
        tblPrintNetPay.Columns.Add("FullName")
        tblPrintNetPay.Columns.Add("Position")
        tblPrintNetPay.Columns.Add("Coverage")
        tblPrintNetPay.Columns.Add("Remarks")
        tblPrintNetPay.Columns.Add("SssNum")
        tblPrintNetPay.Columns.Add("HdmfNum")
        tblPrintNetPay.Columns.Add("PhicNum")
        tblPrintNetPay.Columns.Add("Salary")
        tblPrintNetPay.Columns.Add("Month")
        tblPrintNetPay.Columns.Add("CalendarDays")
        tblPrintNetPay.Columns.Add("TotalNoOfDaysServed")
        tblPrintNetPay.Columns.Add("DailyRate")
        tblPrintNetPay.Columns.Add("Basic")
        tblPrintNetPay.Columns.Add("Absences")
        tblPrintNetPay.Columns.Add("AbsencesAmount")
        tblPrintNetPay.Columns.Add("Tardiness")
        tblPrintNetPay.Columns.Add("TardinessAmount")
        tblPrintNetPay.Columns.Add("AdjustmentAdd")
        tblPrintNetPay.Columns.Add("AdjustmentSub")
        tblPrintNetPay.Columns.Add("GrossPay")
        tblPrintNetPay.Columns.Add("SssPs")
        tblPrintNetPay.Columns.Add("SssEs")
        tblPrintNetPay.Columns.Add("Phic")
        tblPrintNetPay.Columns.Add("Hdmf")
        tblPrintNetPay.Columns.Add("Tax")
        tblPrintNetPay.Columns.Add("NetPay")
        tblPrintNetPay.Columns.Add("HeaderPayrollNo")
        tblPrintNetPay.Columns.Add("HeaderType")
        tblPrintNetPay.Columns.Add("HeaderPayrollTitle")
        tblPrintNetPay.Columns.Add("HeaderPeriod")
        tblPrintNetPay.Columns.Add("HeaderCreatedBy")

        For Each row As DataRow In RetrieveData("SELECT employeesnums.EmployeeNo,
                                                        payrollreports.AcctNo,
                                                        FullName,
                                                        Position,
                                                        Coverage,
                                                        Remarks,
                                                        SssNum,
                                                        HdmfNum,
                                                        PhicNum,
                                                        Salary,
                                                        Month,
                                                        CalendarDays,
                                                        TotalNoOfDaysServed,
                                                        DailyRate,
                                                        Basic,
                                                        Absences,
                                                        AbsencesAmount,
                                                        Tardiness,
                                                        TardinessAmount,
                                                        AdjustmentAdd,
                                                        AdjustmentSub,
                                                        GrossPay,
                                                        SssPs,
                                                        SssEs,
                                                        Phic,
                                                        Hdmf,
                                                        Tax,
                                                        NetPay,
                                                        HeaderPayrollNo,
                                                        HeaderType,
                                                        HeaderPayrollTitle,
                                                        HeaderPeriod,
                                                        HeaderCreatedBy
                                                 FROM
                                                        employeesnums INNER JOIN payrollreports
                                                 ON
                                                        employeesnums.AcctNo = payrollreports.AcctNo
                                                 WHERE
                                                        HeaderPayrollNo = '" & Dashboard.UserPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value & "'", strCon).rows

            tblPrintNetPay.Rows.Add(row.Item("EmployeeNo"),
                                      row.Item("AcctNo"),
                                      row.Item("FullName"),
                                      row.Item("Position"),
                                      row.Item("Coverage"),
                                      row.Item("Remarks"),
                                      row.Item("SssNum"),
                                      row.Item("HdmfNum"),
                                      row.Item("PhicNum"),
                                      row.Item("Salary"),
                                      row.Item("Month"),
                                      row.Item("CalendarDays"),
                                      row.Item("TotalNoOfDaysServed"),
                                      row.Item("DailyRate"),
                                      row.Item("Basic"),
                                      row.Item("Absences"),
                                      row.Item("AbsencesAmount"),
                                      row.Item("Tardiness"),
                                      row.Item("TardinessAmount"),
                                      row.Item("AdjustmentAdd"),
                                      row.Item("AdjustmentSub"),
                                      row.Item("GrossPay"),
                                      row.Item("SssPs"),
                                      row.Item("SssEs"),
                                      row.Item("Phic"),
                                      row.Item("Hdmf"),
                                      row.Item("Tax"),
                                      row.Item("NetPay"),
                                      row.Item("HeaderPayrollNo"),
                                      row.Item("HeaderType"),
                                      row.Item("HeaderPayrollTitle"),
                                      row.Item("HeaderPeriod"),
                                      row.Item("HeaderCreatedBy")
                                      )
        Next

        RetrieveRow("SELECT * FROM signatories WHERE Type = 'BUDGET'", strCon)
        Dim budgetFullname As String = myreader("FullName")
        Dim budgetPosition As String = myreader("Position")

        RetrieveRow("SELECT * FROM signatories WHERE Type = 'APPROVAL'", strCon)
        Dim approvalFullname As String = myreader("FullName")
        Dim approvalPosition As String = myreader("Position")

        Dim rtpdoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        rtpdoc = New PrintNetPayReports
        rtpdoc.SetDataSource(tblPrintNetPay)
        rtpdoc.SetParameterValue("UserFullName", GlobalVariables.loginFullName.ToString.ToUpper)
        rtpdoc.SetParameterValue("UserPosition", GlobalVariables.loginPosition.ToString.ToUpper)
        rtpdoc.SetParameterValue("ApprovalFullName", approvalFullname.ToUpper)
        rtpdoc.SetParameterValue("ApprovalPosition", approvalPosition.ToUpper)
        rtpdoc.SetParameterValue("BudgetFullName", budgetFullname.ToUpper)
        rtpdoc.SetParameterValue("BudgetPosition", budgetPosition.ToUpper)
        PrintNetPayForm.CrystalReportViewer1.ReportSource = rtpdoc
        PrintNetPayForm.Show()
        Me.Close()
    End Sub

    Private Sub BtnHdmf_Click(sender As Object, e As EventArgs) Handles BtnHdmf.Click
        If Dashboard.UserPayrollDtglist.RowCount <= 0 Then
            Exit Sub
        End If

        Dim payrollNo As String = Dashboard.UserPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value

        Dim tblPrintHdmf As New DataTable

        tblPrintHdmf.Columns.Add("EmployeeNo")
        tblPrintHdmf.Columns.Add("AcctNo")
        tblPrintHdmf.Columns.Add("FullName")
        tblPrintHdmf.Columns.Add("Position")
        tblPrintHdmf.Columns.Add("Coverage")
        tblPrintHdmf.Columns.Add("Remarks")
        tblPrintHdmf.Columns.Add("SssNum")
        tblPrintHdmf.Columns.Add("HdmfNum")
        tblPrintHdmf.Columns.Add("PhicNum")
        tblPrintHdmf.Columns.Add("Salary")
        tblPrintHdmf.Columns.Add("Month")
        tblPrintHdmf.Columns.Add("CalendarDays")
        tblPrintHdmf.Columns.Add("TotalNoOfDaysServed")
        tblPrintHdmf.Columns.Add("DailyRate")
        tblPrintHdmf.Columns.Add("Basic")
        tblPrintHdmf.Columns.Add("Absences")
        tblPrintHdmf.Columns.Add("AbsencesAmount")
        tblPrintHdmf.Columns.Add("Tardiness")
        tblPrintHdmf.Columns.Add("TardinessAmount")
        tblPrintHdmf.Columns.Add("AdjustmentAdd")
        tblPrintHdmf.Columns.Add("AdjustmentSub")
        tblPrintHdmf.Columns.Add("GrossPay")
        tblPrintHdmf.Columns.Add("SssPs")
        tblPrintHdmf.Columns.Add("SssEs")
        tblPrintHdmf.Columns.Add("Phic")
        tblPrintHdmf.Columns.Add("Hdmf")
        tblPrintHdmf.Columns.Add("Tax")
        tblPrintHdmf.Columns.Add("NetPay")
        tblPrintHdmf.Columns.Add("HeaderPayrollNo")
        tblPrintHdmf.Columns.Add("HeaderType")
        tblPrintHdmf.Columns.Add("HeaderPayrollTitle")
        tblPrintHdmf.Columns.Add("HeaderPeriod")
        tblPrintHdmf.Columns.Add("HeaderCreatedBy")

        For Each row As DataRow In RetrieveData("SELECT employeesnums.EmployeeNo,
                                                        payrollreports.AcctNo,
                                                        FullName,
                                                        Position,
                                                        Coverage,
                                                        Remarks,
                                                        SssNum,
                                                        HdmfNum,
                                                        PhicNum,
                                                        Salary,
                                                        Month,
                                                        CalendarDays,
                                                        TotalNoOfDaysServed,
                                                        DailyRate,
                                                        Basic,
                                                        Absences,
                                                        AbsencesAmount,
                                                        Tardiness,
                                                        TardinessAmount,
                                                        AdjustmentAdd,
                                                        AdjustmentSub,
                                                        GrossPay,
                                                        SssPs,
                                                        SssEs,
                                                        Phic,
                                                        Hdmf,
                                                        Tax,
                                                        NetPay,
                                                        HeaderPayrollNo,
                                                        HeaderType,
                                                        HeaderPayrollTitle,
                                                        HeaderPeriod,
                                                        HeaderCreatedBy
                                                 FROM
                                                        employeesnums INNER JOIN payrollreports
                                                 ON
                                                        employeesnums.AcctNo = payrollreports.AcctNo
                                                 WHERE
                                                        HeaderPayrollNo = '" & Dashboard.UserPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value & "'", strCon).rows

            tblPrintHdmf.Rows.Add(row.Item("EmployeeNo"),
                                      row.Item("AcctNo"),
                                      row.Item("FullName"),
                                      row.Item("Position"),
                                      row.Item("Coverage"),
                                      row.Item("Remarks"),
                                      row.Item("SssNum"),
                                      row.Item("HdmfNum"),
                                      row.Item("PhicNum"),
                                      row.Item("Salary"),
                                      row.Item("Month"),
                                      row.Item("CalendarDays"),
                                      row.Item("TotalNoOfDaysServed"),
                                      row.Item("DailyRate"),
                                      row.Item("Basic"),
                                      row.Item("Absences"),
                                      row.Item("AbsencesAmount"),
                                      row.Item("Tardiness"),
                                      row.Item("TardinessAmount"),
                                      row.Item("AdjustmentAdd"),
                                      row.Item("AdjustmentSub"),
                                      row.Item("GrossPay"),
                                      row.Item("SssPs"),
                                      row.Item("SssEs"),
                                      row.Item("Phic"),
                                      row.Item("Hdmf"),
                                      row.Item("Tax"),
                                      row.Item("NetPay"),
                                      row.Item("HeaderPayrollNo"),
                                      row.Item("HeaderType"),
                                      row.Item("HeaderPayrollTitle"),
                                      row.Item("HeaderPeriod"),
                                      row.Item("HeaderCreatedBy")
                                      )
        Next

        RetrieveRow("SELECT * FROM signatories WHERE Type = 'APPROVAL'", strCon)
        Dim authorizedFullName As String = myreader("FullName")
        Dim authorizedPosition As String = myreader("Position")

        Dim rtpdoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        rtpdoc = New PrintHdmfReports
        rtpdoc.SetDataSource(tblPrintHdmf)
        rtpdoc.SetParameterValue("AuthorizedFullName", AuthorizedFullName.ToUpper)
        rtpdoc.SetParameterValue("AuthorizedPosition", authorizedPosition.ToUpper)
        PrintHdmfForm.CrystalReportViewer1.ReportSource = rtpdoc
        PrintHdmfForm.Show()
        Me.Close()

    End Sub

    Private Sub BtnPhic_Click(sender As Object, e As EventArgs) Handles BtnPhic.Click
        If Dashboard.UserPayrollDtglist.RowCount <= 0 Then
            Exit Sub
        End If

        Dim payrollNo As String = Dashboard.UserPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value

        Dim tblPrintPhic As New DataTable

        tblPrintPhic.Columns.Add("EmployeeNo")
        tblPrintPhic.Columns.Add("AcctNo")
        tblPrintPhic.Columns.Add("FullName")
        tblPrintPhic.Columns.Add("Position")
        tblPrintPhic.Columns.Add("Coverage")
        tblPrintPhic.Columns.Add("Remarks")
        tblPrintPhic.Columns.Add("SssNum")
        tblPrintPhic.Columns.Add("HdmfNum")
        tblPrintPhic.Columns.Add("PhicNum")
        tblPrintPhic.Columns.Add("Salary")
        tblPrintPhic.Columns.Add("Month")
        tblPrintPhic.Columns.Add("CalendarDays")
        tblPrintPhic.Columns.Add("TotalNoOfDaysServed")
        tblPrintPhic.Columns.Add("DailyRate")
        tblPrintPhic.Columns.Add("Basic")
        tblPrintPhic.Columns.Add("Absences")
        tblPrintPhic.Columns.Add("AbsencesAmount")
        tblPrintPhic.Columns.Add("Tardiness")
        tblPrintPhic.Columns.Add("TardinessAmount")
        tblPrintPhic.Columns.Add("AdjustmentAdd")
        tblPrintPhic.Columns.Add("AdjustmentSub")
        tblPrintPhic.Columns.Add("GrossPay")
        tblPrintPhic.Columns.Add("SssPs")
        tblPrintPhic.Columns.Add("SssEs")
        tblPrintPhic.Columns.Add("Phic")
        tblPrintPhic.Columns.Add("Hdmf")
        tblPrintPhic.Columns.Add("Tax")
        tblPrintPhic.Columns.Add("NetPay")
        tblPrintPhic.Columns.Add("HeaderPayrollNo")
        tblPrintPhic.Columns.Add("HeaderType")
        tblPrintPhic.Columns.Add("HeaderPayrollTitle")
        tblPrintPhic.Columns.Add("HeaderPeriod")
        tblPrintPhic.Columns.Add("HeaderCreatedBy")

        For Each row As DataRow In RetrieveData("SELECT employeesnums.EmployeeNo,
                                                        payrollreports.AcctNo,
                                                        FullName,
                                                        Position,
                                                        Coverage,
                                                        Remarks,
                                                        SssNum,
                                                        HdmfNum,
                                                        PhicNum,
                                                        Salary,
                                                        Month,
                                                        CalendarDays,
                                                        TotalNoOfDaysServed,
                                                        DailyRate,
                                                        Basic,
                                                        Absences,
                                                        AbsencesAmount,
                                                        Tardiness,
                                                        TardinessAmount,
                                                        AdjustmentAdd,
                                                        AdjustmentSub,
                                                        GrossPay,
                                                        SssPs,
                                                        SssEs,
                                                        Phic,
                                                        Hdmf,
                                                        Tax,
                                                        NetPay,
                                                        HeaderPayrollNo,
                                                        HeaderType,
                                                        HeaderPayrollTitle,
                                                        HeaderPeriod,
                                                        HeaderCreatedBy
                                                 FROM
                                                        employeesnums INNER JOIN payrollreports
                                                 ON
                                                        employeesnums.AcctNo = payrollreports.AcctNo
                                                 WHERE
                                                        HeaderPayrollNo = '" & Dashboard.UserPayrollDtglist.CurrentRow.Cells("PAYROLL NO").Value & "'", strCon).rows

            tblPrintPhic.Rows.Add(row.Item("EmployeeNo"),
                                      row.Item("AcctNo"),
                                      row.Item("FullName"),
                                      row.Item("Position"),
                                      row.Item("Coverage"),
                                      row.Item("Remarks"),
                                      row.Item("SssNum"),
                                      row.Item("HdmfNum"),
                                      row.Item("PhicNum"),
                                      row.Item("Salary"),
                                      row.Item("Month"),
                                      row.Item("CalendarDays"),
                                      row.Item("TotalNoOfDaysServed"),
                                      row.Item("DailyRate"),
                                      row.Item("Basic"),
                                      row.Item("Absences"),
                                      row.Item("AbsencesAmount"),
                                      row.Item("Tardiness"),
                                      row.Item("TardinessAmount"),
                                      row.Item("AdjustmentAdd"),
                                      row.Item("AdjustmentSub"),
                                      row.Item("GrossPay"),
                                      row.Item("SssPs"),
                                      row.Item("SssEs"),
                                      row.Item("Phic"),
                                      row.Item("Hdmf"),
                                      row.Item("Tax"),
                                      row.Item("NetPay"),
                                      row.Item("HeaderPayrollNo"),
                                      row.Item("HeaderType"),
                                      row.Item("HeaderPayrollTitle"),
                                      row.Item("HeaderPeriod"),
                                      row.Item("HeaderCreatedBy")
                                      )
        Next

        RetrieveRow("SELECT * FROM signatories WHERE Type = 'APPROVAL'", strCon)
        Dim authorizedFullName As String = myreader("FullName")
        Dim authorizedPosition As String = myreader("Position")

        Dim rtpdoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        rtpdoc = New PrintPhicReports
        rtpdoc.SetDataSource(tblPrintPhic)
        rtpdoc.SetParameterValue("AuthorizedFullName", authorizedFullName.ToUpper)
        rtpdoc.SetParameterValue("AuthorizedPosition", authorizedPosition.ToUpper)
        PrintPhicForm.CrystalReportViewer1.ReportSource = rtpdoc
        PrintPhicForm.Show()
        Me.Close()
    End Sub
End Class