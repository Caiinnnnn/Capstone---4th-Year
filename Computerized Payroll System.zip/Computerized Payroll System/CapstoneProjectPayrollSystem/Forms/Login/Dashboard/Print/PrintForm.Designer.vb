﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PrintForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnNetPay = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnHdmf = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnPhic = New Guna.UI2.WinForms.Guna2Button()
        Me.SuspendLayout()
        '
        'BtnNetPay
        '
        Me.BtnNetPay.CheckedState.Parent = Me.BtnNetPay
        Me.BtnNetPay.CustomImages.Parent = Me.BtnNetPay
        Me.BtnNetPay.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnNetPay.ForeColor = System.Drawing.Color.White
        Me.BtnNetPay.HoverState.Parent = Me.BtnNetPay
        Me.BtnNetPay.Location = New System.Drawing.Point(137, 12)
        Me.BtnNetPay.Name = "BtnNetPay"
        Me.BtnNetPay.ShadowDecoration.Parent = Me.BtnNetPay
        Me.BtnNetPay.Size = New System.Drawing.Size(180, 45)
        Me.BtnNetPay.TabIndex = 0
        Me.BtnNetPay.Text = "NET PAY"
        '
        'BtnHdmf
        '
        Me.BtnHdmf.CheckedState.Parent = Me.BtnHdmf
        Me.BtnHdmf.CustomImages.Parent = Me.BtnHdmf
        Me.BtnHdmf.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnHdmf.ForeColor = System.Drawing.Color.White
        Me.BtnHdmf.HoverState.Parent = Me.BtnHdmf
        Me.BtnHdmf.Location = New System.Drawing.Point(137, 63)
        Me.BtnHdmf.Name = "BtnHdmf"
        Me.BtnHdmf.ShadowDecoration.Parent = Me.BtnHdmf
        Me.BtnHdmf.Size = New System.Drawing.Size(180, 45)
        Me.BtnHdmf.TabIndex = 1
        Me.BtnHdmf.Text = "HDMF"
        '
        'BtnPhic
        '
        Me.BtnPhic.CheckedState.Parent = Me.BtnPhic
        Me.BtnPhic.CustomImages.Parent = Me.BtnPhic
        Me.BtnPhic.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnPhic.ForeColor = System.Drawing.Color.White
        Me.BtnPhic.HoverState.Parent = Me.BtnPhic
        Me.BtnPhic.Location = New System.Drawing.Point(137, 114)
        Me.BtnPhic.Name = "BtnPhic"
        Me.BtnPhic.ShadowDecoration.Parent = Me.BtnPhic
        Me.BtnPhic.Size = New System.Drawing.Size(180, 45)
        Me.BtnPhic.TabIndex = 2
        Me.BtnPhic.Text = "PHIC"
        '
        'PrintForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(449, 172)
        Me.Controls.Add(Me.BtnPhic)
        Me.Controls.Add(Me.BtnHdmf)
        Me.Controls.Add(Me.BtnNetPay)
        Me.Name = "PrintForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PrintForm"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnNetPay As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnHdmf As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnPhic As Guna.UI2.WinForms.Guna2Button
End Class
