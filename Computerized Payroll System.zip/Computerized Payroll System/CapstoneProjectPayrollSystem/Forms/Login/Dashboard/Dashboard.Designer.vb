﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.PboxAvatar = New Guna.UI2.WinForms.Guna2CirclePictureBox()
        Me.LblPosition = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.BtnLogout = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnSearch = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnEmplist = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnForFindes = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnPrint = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.LblLogin = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ELEMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NTPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountSettingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangeAvatarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Guna2Panel3 = New Guna.UI2.WinForms.Guna2Panel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.UserPayrollDtglist = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AllPayrollDtglist = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.Guna2Panel1.SuspendLayout()
        CType(Me.PboxAvatar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2Panel2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Guna2Panel3.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.UserPayrollDtglist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.AllPayrollDtglist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(131, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Guna2Panel1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel1.BorderThickness = 1
        Me.Guna2Panel1.Controls.Add(Me.PboxAvatar)
        Me.Guna2Panel1.Controls.Add(Me.LblPosition)
        Me.Guna2Panel1.Controls.Add(Me.BtnLogout)
        Me.Guna2Panel1.Controls.Add(Me.BtnSearch)
        Me.Guna2Panel1.Controls.Add(Me.BtnEmplist)
        Me.Guna2Panel1.Controls.Add(Me.BtnForFindes)
        Me.Guna2Panel1.Controls.Add(Me.BtnPrint)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button1)
        Me.Guna2Panel1.Controls.Add(Me.LblLogin)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(220, 729)
        Me.Guna2Panel1.TabIndex = 0
        '
        'PboxAvatar
        '
        Me.PboxAvatar.Location = New System.Drawing.Point(50, 12)
        Me.PboxAvatar.Name = "PboxAvatar"
        Me.PboxAvatar.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.PboxAvatar.ShadowDecoration.Parent = Me.PboxAvatar
        Me.PboxAvatar.Size = New System.Drawing.Size(120, 120)
        Me.PboxAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PboxAvatar.TabIndex = 9
        Me.PboxAvatar.TabStop = False
        '
        'LblPosition
        '
        Me.LblPosition.AutoSize = False
        Me.LblPosition.BackColor = System.Drawing.Color.Transparent
        Me.LblPosition.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPosition.Location = New System.Drawing.Point(1, 192)
        Me.LblPosition.Name = "LblPosition"
        Me.LblPosition.Size = New System.Drawing.Size(217, 26)
        Me.LblPosition.TabIndex = 8
        Me.LblPosition.Text = "Position"
        Me.LblPosition.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BtnLogout
        '
        Me.BtnLogout.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnLogout.BorderRadius = 10
        Me.BtnLogout.BorderThickness = 1
        Me.BtnLogout.CheckedState.Parent = Me.BtnLogout
        Me.BtnLogout.CustomImages.Parent = Me.BtnLogout
        Me.BtnLogout.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnLogout.ForeColor = System.Drawing.Color.White
        Me.BtnLogout.HoverState.Parent = Me.BtnLogout
        Me.BtnLogout.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.logout
        Me.BtnLogout.Location = New System.Drawing.Point(12, 585)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.ShadowDecoration.Parent = Me.BtnLogout
        Me.BtnLogout.Size = New System.Drawing.Size(196, 62)
        Me.BtnLogout.TabIndex = 7
        Me.BtnLogout.Text = "LOGOUT"
        Me.BtnLogout.TextOffset = New System.Drawing.Point(4, 0)
        '
        'BtnSearch
        '
        Me.BtnSearch.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSearch.BorderRadius = 10
        Me.BtnSearch.BorderThickness = 1
        Me.BtnSearch.CheckedState.Parent = Me.BtnSearch
        Me.BtnSearch.CustomImages.Parent = Me.BtnSearch
        Me.BtnSearch.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSearch.ForeColor = System.Drawing.Color.White
        Me.BtnSearch.HoverState.Parent = Me.BtnSearch
        Me.BtnSearch.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.search
        Me.BtnSearch.ImageOffset = New System.Drawing.Point(-2, 0)
        Me.BtnSearch.Location = New System.Drawing.Point(12, 517)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.ShadowDecoration.Parent = Me.BtnSearch
        Me.BtnSearch.Size = New System.Drawing.Size(196, 62)
        Me.BtnSearch.TabIndex = 6
        Me.BtnSearch.Text = "SEARCH"
        Me.BtnSearch.TextOffset = New System.Drawing.Point(2, 0)
        '
        'BtnEmplist
        '
        Me.BtnEmplist.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnEmplist.BorderRadius = 10
        Me.BtnEmplist.BorderThickness = 1
        Me.BtnEmplist.CheckedState.Parent = Me.BtnEmplist
        Me.BtnEmplist.CustomImages.Parent = Me.BtnEmplist
        Me.BtnEmplist.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnEmplist.ForeColor = System.Drawing.Color.White
        Me.BtnEmplist.HoverState.Parent = Me.BtnEmplist
        Me.BtnEmplist.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.employees
        Me.BtnEmplist.ImageOffset = New System.Drawing.Point(-2, 0)
        Me.BtnEmplist.Location = New System.Drawing.Point(12, 449)
        Me.BtnEmplist.Name = "BtnEmplist"
        Me.BtnEmplist.ShadowDecoration.Parent = Me.BtnEmplist
        Me.BtnEmplist.Size = New System.Drawing.Size(196, 62)
        Me.BtnEmplist.TabIndex = 5
        Me.BtnEmplist.Text = "EMP LIST"
        Me.BtnEmplist.TextOffset = New System.Drawing.Point(3, 0)
        '
        'BtnForFindes
        '
        Me.BtnForFindes.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnForFindes.BorderRadius = 10
        Me.BtnForFindes.BorderThickness = 1
        Me.BtnForFindes.CheckedState.Parent = Me.BtnForFindes
        Me.BtnForFindes.CustomImages.Parent = Me.BtnForFindes
        Me.BtnForFindes.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnForFindes.ForeColor = System.Drawing.Color.White
        Me.BtnForFindes.HoverState.Parent = Me.BtnForFindes
        Me.BtnForFindes.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.forfindes
        Me.BtnForFindes.ImageOffset = New System.Drawing.Point(3, 0)
        Me.BtnForFindes.Location = New System.Drawing.Point(12, 381)
        Me.BtnForFindes.Name = "BtnForFindes"
        Me.BtnForFindes.ShadowDecoration.Parent = Me.BtnForFindes
        Me.BtnForFindes.Size = New System.Drawing.Size(196, 62)
        Me.BtnForFindes.TabIndex = 4
        Me.BtnForFindes.Text = "FOR FINDES"
        Me.BtnForFindes.TextOffset = New System.Drawing.Point(6, 0)
        '
        'BtnPrint
        '
        Me.BtnPrint.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnPrint.BorderRadius = 10
        Me.BtnPrint.BorderThickness = 1
        Me.BtnPrint.CheckedState.Parent = Me.BtnPrint
        Me.BtnPrint.CustomImages.Parent = Me.BtnPrint
        Me.BtnPrint.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnPrint.ForeColor = System.Drawing.Color.White
        Me.BtnPrint.HoverState.Parent = Me.BtnPrint
        Me.BtnPrint.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.print
        Me.BtnPrint.ImageOffset = New System.Drawing.Point(-5, 0)
        Me.BtnPrint.Location = New System.Drawing.Point(12, 313)
        Me.BtnPrint.Name = "BtnPrint"
        Me.BtnPrint.ShadowDecoration.Parent = Me.BtnPrint
        Me.BtnPrint.Size = New System.Drawing.Size(196, 62)
        Me.BtnPrint.TabIndex = 3
        Me.BtnPrint.Text = "PRINT"
        '
        'Guna2Button1
        '
        Me.Guna2Button1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Button1.BorderRadius = 10
        Me.Guna2Button1.BorderThickness = 1
        Me.Guna2Button1.CheckedState.Parent = Me.Guna2Button1
        Me.Guna2Button1.CustomImages.Parent = Me.Guna2Button1
        Me.Guna2Button1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button1.ForeColor = System.Drawing.Color.White
        Me.Guna2Button1.HoverState.Parent = Me.Guna2Button1
        Me.Guna2Button1.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.payroll
        Me.Guna2Button1.Location = New System.Drawing.Point(12, 245)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.ShadowDecoration.Parent = Me.Guna2Button1
        Me.Guna2Button1.Size = New System.Drawing.Size(196, 62)
        Me.Guna2Button1.TabIndex = 2
        Me.Guna2Button1.Text = "PAYROLL"
        Me.Guna2Button1.TextOffset = New System.Drawing.Point(5, 0)
        '
        'LblLogin
        '
        Me.LblLogin.AutoSize = False
        Me.LblLogin.BackColor = System.Drawing.Color.Transparent
        Me.LblLogin.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogin.Location = New System.Drawing.Point(0, 160)
        Me.LblLogin.Name = "LblLogin"
        Me.LblLogin.Size = New System.Drawing.Size(217, 26)
        Me.LblLogin.TabIndex = 1
        Me.LblLogin.Text = "Username"
        Me.LblLogin.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(177, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2Panel2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2Panel2.BorderThickness = 1
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2Panel2.Controls.Add(Me.MenuStrip1)
        Me.Guna2Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2Panel2.Location = New System.Drawing.Point(220, 0)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(1130, 132)
        Me.Guna2Panel2.TabIndex = 1
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Segoe UI Semibold", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(7, 62)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(333, 34)
        Me.Guna2HtmlLabel1.TabIndex = 1
        Me.Guna2HtmlLabel1.Text = "Lord's Jubilee Christian School"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TypeToolStripMenuItem, Me.AccountSettingToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1130, 29)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TypeToolStripMenuItem
        '
        Me.TypeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ELEMToolStripMenuItem, Me.HSToolStripMenuItem, Me.NTPToolStripMenuItem})
        Me.TypeToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TypeToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.TypeToolStripMenuItem.Name = "TypeToolStripMenuItem"
        Me.TypeToolStripMenuItem.Size = New System.Drawing.Size(57, 25)
        Me.TypeToolStripMenuItem.Text = "Type"
        '
        'ELEMToolStripMenuItem
        '
        Me.ELEMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.ELEMToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ELEMToolStripMenuItem.Name = "ELEMToolStripMenuItem"
        Me.ELEMToolStripMenuItem.Size = New System.Drawing.Size(119, 26)
        Me.ELEMToolStripMenuItem.Text = "ELEM"
        '
        'HSToolStripMenuItem
        '
        Me.HSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.HSToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.HSToolStripMenuItem.Name = "HSToolStripMenuItem"
        Me.HSToolStripMenuItem.Size = New System.Drawing.Size(119, 26)
        Me.HSToolStripMenuItem.Text = "HS"
        '
        'NTPToolStripMenuItem
        '
        Me.NTPToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.NTPToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.NTPToolStripMenuItem.Name = "NTPToolStripMenuItem"
        Me.NTPToolStripMenuItem.Size = New System.Drawing.Size(119, 26)
        Me.NTPToolStripMenuItem.Text = "NTP"
        '
        'AccountSettingToolStripMenuItem
        '
        Me.AccountSettingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.ChangeAvatarToolStripMenuItem})
        Me.AccountSettingToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AccountSettingToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.AccountSettingToolStripMenuItem.Name = "AccountSettingToolStripMenuItem"
        Me.AccountSettingToolStripMenuItem.Size = New System.Drawing.Size(138, 25)
        Me.AccountSettingToolStripMenuItem.Text = "Account Settings"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.ChangePasswordToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(201, 26)
        Me.ChangePasswordToolStripMenuItem.Text = "change password"
        '
        'ChangeAvatarToolStripMenuItem
        '
        Me.ChangeAvatarToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.ChangeAvatarToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ChangeAvatarToolStripMenuItem.Name = "ChangeAvatarToolStripMenuItem"
        Me.ChangeAvatarToolStripMenuItem.Size = New System.Drawing.Size(201, 26)
        Me.ChangeAvatarToolStripMenuItem.Text = "change avatar"
        '
        'Guna2Panel3
        '
        Me.Guna2Panel3.Controls.Add(Me.TabControl1)
        Me.Guna2Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2Panel3.Location = New System.Drawing.Point(220, 132)
        Me.Guna2Panel3.Name = "Guna2Panel3"
        Me.Guna2Panel3.ShadowDecoration.Parent = Me.Guna2Panel3
        Me.Guna2Panel3.Size = New System.Drawing.Size(1130, 597)
        Me.Guna2Panel3.TabIndex = 2
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1130, 597)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.UserPayrollDtglist)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1122, 571)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'UserPayrollDtglist
        '
        Me.UserPayrollDtglist.AllowUserToAddRows = False
        Me.UserPayrollDtglist.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.UserPayrollDtglist.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.UserPayrollDtglist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.UserPayrollDtglist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.UserPayrollDtglist.BackgroundColor = System.Drawing.Color.White
        Me.UserPayrollDtglist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.UserPayrollDtglist.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.UserPayrollDtglist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.UserPayrollDtglist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.UserPayrollDtglist.ColumnHeadersHeight = 25
        Me.UserPayrollDtglist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.UserPayrollDtglist.DefaultCellStyle = DataGridViewCellStyle3
        Me.UserPayrollDtglist.Dock = System.Windows.Forms.DockStyle.Fill
        Me.UserPayrollDtglist.EnableHeadersVisualStyles = False
        Me.UserPayrollDtglist.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.UserPayrollDtglist.Location = New System.Drawing.Point(3, 3)
        Me.UserPayrollDtglist.MultiSelect = False
        Me.UserPayrollDtglist.Name = "UserPayrollDtglist"
        Me.UserPayrollDtglist.ReadOnly = True
        Me.UserPayrollDtglist.RowHeadersVisible = False
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.UserPayrollDtglist.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.UserPayrollDtglist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.UserPayrollDtglist.Size = New System.Drawing.Size(1116, 565)
        Me.UserPayrollDtglist.TabIndex = 0
        Me.UserPayrollDtglist.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt
        Me.UserPayrollDtglist.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.UserPayrollDtglist.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.UserPayrollDtglist.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.UserPayrollDtglist.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.UserPayrollDtglist.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.UserPayrollDtglist.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.UserPayrollDtglist.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.UserPayrollDtglist.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.UserPayrollDtglist.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.UserPayrollDtglist.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.UserPayrollDtglist.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.UserPayrollDtglist.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.UserPayrollDtglist.ThemeStyle.HeaderStyle.Height = 25
        Me.UserPayrollDtglist.ThemeStyle.ReadOnly = True
        Me.UserPayrollDtglist.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.UserPayrollDtglist.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.UserPayrollDtglist.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.UserPayrollDtglist.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.UserPayrollDtglist.ThemeStyle.RowsStyle.Height = 22
        Me.UserPayrollDtglist.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        Me.UserPayrollDtglist.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.AllPayrollDtglist)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1122, 571)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "All Payroll"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'AllPayrollDtglist
        '
        Me.AllPayrollDtglist.AllowUserToAddRows = False
        Me.AllPayrollDtglist.AllowUserToDeleteRows = False
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.AllPayrollDtglist.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.AllPayrollDtglist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.AllPayrollDtglist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.AllPayrollDtglist.BackgroundColor = System.Drawing.Color.White
        Me.AllPayrollDtglist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.AllPayrollDtglist.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.AllPayrollDtglist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AllPayrollDtglist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.AllPayrollDtglist.ColumnHeadersHeight = 25
        Me.AllPayrollDtglist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.AllPayrollDtglist.DefaultCellStyle = DataGridViewCellStyle7
        Me.AllPayrollDtglist.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AllPayrollDtglist.EnableHeadersVisualStyles = False
        Me.AllPayrollDtglist.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.AllPayrollDtglist.Location = New System.Drawing.Point(3, 3)
        Me.AllPayrollDtglist.MultiSelect = False
        Me.AllPayrollDtglist.Name = "AllPayrollDtglist"
        Me.AllPayrollDtglist.ReadOnly = True
        Me.AllPayrollDtglist.RowHeadersVisible = False
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.AllPayrollDtglist.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.AllPayrollDtglist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.AllPayrollDtglist.Size = New System.Drawing.Size(1116, 565)
        Me.AllPayrollDtglist.TabIndex = 1
        Me.AllPayrollDtglist.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt
        Me.AllPayrollDtglist.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.AllPayrollDtglist.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.AllPayrollDtglist.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.AllPayrollDtglist.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.AllPayrollDtglist.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.AllPayrollDtglist.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.AllPayrollDtglist.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.AllPayrollDtglist.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.AllPayrollDtglist.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.AllPayrollDtglist.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.AllPayrollDtglist.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.AllPayrollDtglist.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.AllPayrollDtglist.ThemeStyle.HeaderStyle.Height = 25
        Me.AllPayrollDtglist.ThemeStyle.ReadOnly = True
        Me.AllPayrollDtglist.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.AllPayrollDtglist.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.AllPayrollDtglist.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.AllPayrollDtglist.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.AllPayrollDtglist.ThemeStyle.RowsStyle.Height = 22
        Me.AllPayrollDtglist.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        Me.AllPayrollDtglist.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'Dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1350, 729)
        Me.Controls.Add(Me.Guna2Panel3)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(1364, 726)
        Me.Name = "Dashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DASHBOARD"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Guna2Panel1.ResumeLayout(False)
        CType(Me.PboxAvatar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel2.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Guna2Panel3.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.UserPayrollDtglist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.AllPayrollDtglist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents TypeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ELEMToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NTPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LblLogin As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents BtnSearch As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnEmplist As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnForFindes As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnPrint As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel3 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents BtnLogout As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents LblPosition As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents AccountSettingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UserPayrollDtglist As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents ChangePasswordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChangeAvatarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PboxAvatar As Guna.UI2.WinForms.Guna2CirclePictureBox
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents AllPayrollDtglist As Guna.UI2.WinForms.Guna2DataGridView
End Class
