﻿Public Class AdminDashboard

    Public Sub RefreshAdminDashboard()
        Dim avatar As Dictionary(Of String, Bitmap) = New Dictionary(Of String, Bitmap)
        avatar.Add("man_1", My.Resources.man_1)
        avatar.Add("man_2", My.Resources.man_2)
        avatar.Add("man_3", My.Resources.man_3)
        avatar.Add("man_4", My.Resources.man_4)
        avatar.Add("man_5", My.Resources.man_5)
        avatar.Add("man_6", My.Resources.man_6)
        avatar.Add("man_7", My.Resources.man_7)
        avatar.Add("woman_1", My.Resources.woman_1)
        avatar.Add("woman_2", My.Resources.woman_2)
        avatar.Add("woman_3", My.Resources.woman_3)
        avatar.Add("woman_4", My.Resources.woman_4)
        avatar.Add("woman_5", My.Resources.woman_5)
        avatar.Add("woman_6", My.Resources.woman_6)
        avatar.Add("woman_7", My.Resources.woman_7)
        avatar.Add("animal_1", My.Resources.animal_1)
        avatar.Add("animal_2", My.Resources.animal_2)
        avatar.Add("animal_3", My.Resources.animal_3)
        avatar.Add("animal_4", My.Resources.animal_4)
        avatar.Add("animal_5", My.Resources.animal_5)
        avatar.Add("animal_6", My.Resources.animal_6)
        avatar.Add("animal_7", My.Resources.animal_7)

        Dim profileAvatar As String
        RetrieveRow("SELECT * FROM user_accts WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon)
        profileAvatar = myreader("Avatar")
        PboxAvatar.Image = avatar.Item(profileAvatar)

        RetrieveRow("SELECT * FROM user_accts WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon)

        GlobalVariables.loginFullName = myreader("FullName").ToString
        GlobalVariables.loginPosition = myreader("Position").ToString

        LblLogin.Text = GlobalVariables.loginFullName
        LblPosition.Text = GlobalVariables.loginPosition
    End Sub
    Private Sub AdminDashboard_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        App.Close()
    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click
        Me.Dispose()
        Me.Close()
        App.Show()
        App.TxtboxPassword.Clear()
        App.TxtboxUsername.Clear()
        App.TxtboxUsername.Focus()
    End Sub

    Private Sub AdminDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RefreshAdminDashboard()
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        AdminChangePassword.Show()
    End Sub

    Private Sub ChangeAvatarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangeAvatarToolStripMenuItem.Click
        AdminChangeAvatar.Show()
    End Sub

    Private Sub BtnUsers_Click(sender As Object, e As EventArgs) Handles BtnUsers.Click
        Users.Show()
    End Sub

    Private Sub BtnSignatories_Click(sender As Object, e As EventArgs) Handles BtnSignatories.Click
        Signatories.Show()
    End Sub
End Class