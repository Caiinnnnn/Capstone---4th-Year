﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdminDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminDashboard))
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AccountSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangeAvatarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BtnUsers = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnSignatories = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnLogout = New Guna.UI2.WinForms.Guna2Button()
        Me.LblPosition = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.LblLogin = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.PboxAvatar = New Guna.UI2.WinForms.Guna2CirclePictureBox()
        Me.Guna2Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PboxAvatar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(131, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Guna2Panel1.Controls.Add(Me.MenuStrip1)
        Me.Guna2Panel1.Controls.Add(Me.BtnUsers)
        Me.Guna2Panel1.Controls.Add(Me.BtnSignatories)
        Me.Guna2Panel1.Controls.Add(Me.BtnLogout)
        Me.Guna2Panel1.Controls.Add(Me.LblPosition)
        Me.Guna2Panel1.Controls.Add(Me.LblLogin)
        Me.Guna2Panel1.Controls.Add(Me.PboxAvatar)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(218, 493)
        Me.Guna2Panel1.TabIndex = 0
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccountSettingsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(218, 29)
        Me.MenuStrip1.TabIndex = 16
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AccountSettingsToolStripMenuItem
        '
        Me.AccountSettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.ChangeAvatarToolStripMenuItem})
        Me.AccountSettingsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AccountSettingsToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.AccountSettingsToolStripMenuItem.Name = "AccountSettingsToolStripMenuItem"
        Me.AccountSettingsToolStripMenuItem.Size = New System.Drawing.Size(138, 25)
        Me.AccountSettingsToolStripMenuItem.Text = "Account Settings"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.ChangePasswordToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(201, 26)
        Me.ChangePasswordToolStripMenuItem.Text = "change password"
        '
        'ChangeAvatarToolStripMenuItem
        '
        Me.ChangeAvatarToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.ChangeAvatarToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ChangeAvatarToolStripMenuItem.Name = "ChangeAvatarToolStripMenuItem"
        Me.ChangeAvatarToolStripMenuItem.Size = New System.Drawing.Size(201, 26)
        Me.ChangeAvatarToolStripMenuItem.Text = "change avatar"
        '
        'BtnUsers
        '
        Me.BtnUsers.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnUsers.BorderRadius = 10
        Me.BtnUsers.BorderThickness = 1
        Me.BtnUsers.CheckedState.Parent = Me.BtnUsers
        Me.BtnUsers.CustomImages.Parent = Me.BtnUsers
        Me.BtnUsers.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnUsers.ForeColor = System.Drawing.Color.White
        Me.BtnUsers.HoverState.Parent = Me.BtnUsers
        Me.BtnUsers.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.users
        Me.BtnUsers.ImageOffset = New System.Drawing.Point(-11, 0)
        Me.BtnUsers.Location = New System.Drawing.Point(12, 270)
        Me.BtnUsers.Name = "BtnUsers"
        Me.BtnUsers.ShadowDecoration.Parent = Me.BtnUsers
        Me.BtnUsers.Size = New System.Drawing.Size(196, 62)
        Me.BtnUsers.TabIndex = 15
        Me.BtnUsers.Text = "USERS"
        '
        'BtnSignatories
        '
        Me.BtnSignatories.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSignatories.BorderRadius = 10
        Me.BtnSignatories.BorderThickness = 1
        Me.BtnSignatories.CheckedState.Parent = Me.BtnSignatories
        Me.BtnSignatories.CustomImages.Parent = Me.BtnSignatories
        Me.BtnSignatories.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSignatories.ForeColor = System.Drawing.Color.White
        Me.BtnSignatories.HoverState.Parent = Me.BtnSignatories
        Me.BtnSignatories.Image = CType(resources.GetObject("BtnSignatories.Image"), System.Drawing.Image)
        Me.BtnSignatories.Location = New System.Drawing.Point(12, 338)
        Me.BtnSignatories.Name = "BtnSignatories"
        Me.BtnSignatories.ShadowDecoration.Parent = Me.BtnSignatories
        Me.BtnSignatories.Size = New System.Drawing.Size(196, 62)
        Me.BtnSignatories.TabIndex = 14
        Me.BtnSignatories.Text = "SIGNATORIES"
        Me.BtnSignatories.TextOffset = New System.Drawing.Point(10, 0)
        '
        'BtnLogout
        '
        Me.BtnLogout.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnLogout.BorderRadius = 10
        Me.BtnLogout.BorderThickness = 1
        Me.BtnLogout.CheckedState.Parent = Me.BtnLogout
        Me.BtnLogout.CustomImages.Parent = Me.BtnLogout
        Me.BtnLogout.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnLogout.ForeColor = System.Drawing.Color.White
        Me.BtnLogout.HoverState.Parent = Me.BtnLogout
        Me.BtnLogout.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.logout
        Me.BtnLogout.ImageOffset = New System.Drawing.Point(-9, 0)
        Me.BtnLogout.Location = New System.Drawing.Point(12, 406)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.ShadowDecoration.Parent = Me.BtnLogout
        Me.BtnLogout.Size = New System.Drawing.Size(196, 62)
        Me.BtnLogout.TabIndex = 13
        Me.BtnLogout.Text = "LOGOUT"
        Me.BtnLogout.TextOffset = New System.Drawing.Point(5, 0)
        '
        'LblPosition
        '
        Me.LblPosition.AutoSize = False
        Me.LblPosition.BackColor = System.Drawing.Color.Transparent
        Me.LblPosition.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPosition.Location = New System.Drawing.Point(1, 217)
        Me.LblPosition.Name = "LblPosition"
        Me.LblPosition.Size = New System.Drawing.Size(217, 26)
        Me.LblPosition.TabIndex = 12
        Me.LblPosition.Text = "Position"
        Me.LblPosition.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblLogin
        '
        Me.LblLogin.AutoSize = False
        Me.LblLogin.BackColor = System.Drawing.Color.Transparent
        Me.LblLogin.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLogin.Location = New System.Drawing.Point(0, 185)
        Me.LblLogin.Name = "LblLogin"
        Me.LblLogin.Size = New System.Drawing.Size(217, 26)
        Me.LblLogin.TabIndex = 11
        Me.LblLogin.Text = "Username"
        Me.LblLogin.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PboxAvatar
        '
        Me.PboxAvatar.Location = New System.Drawing.Point(50, 45)
        Me.PboxAvatar.Name = "PboxAvatar"
        Me.PboxAvatar.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.PboxAvatar.ShadowDecoration.Parent = Me.PboxAvatar
        Me.PboxAvatar.Size = New System.Drawing.Size(120, 120)
        Me.PboxAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PboxAvatar.TabIndex = 10
        Me.PboxAvatar.TabStop = False
        '
        'AdminDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(218, 493)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.MaximizeBox = False
        Me.Name = "AdminDashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AdminDashboard"
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PboxAvatar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents PboxAvatar As Guna.UI2.WinForms.Guna2CirclePictureBox
    Friend WithEvents LblPosition As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents LblLogin As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents BtnLogout As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnUsers As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnSignatories As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AccountSettingsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChangeAvatarToolStripMenuItem As ToolStripMenuItem
End Class
