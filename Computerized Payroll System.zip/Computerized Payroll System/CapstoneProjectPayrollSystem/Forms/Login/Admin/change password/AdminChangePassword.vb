﻿Public Class AdminChangePassword
    Private Sub ClearField()
        TxtboxOldPassword.Clear()
        TxtboxNewPassword.Clear()
        TxtboxConfirmNewPassword.Clear()
        TxtboxOldPassword.Focus()
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        RetrieveRow("SELECT * FROM user_accts WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon)

        Dim currentPassword As String = myreader("Password")
        Dim oldPassword As String = TxtboxOldPassword.Text
        Dim newPassword As String = TxtboxNewPassword.Text
        Dim confirmNewPassword As String = TxtboxConfirmNewPassword.Text

        If TxtboxOldPassword.Text = "" Or
           TxtboxNewPassword.Text = "" Or
           TxtboxConfirmNewPassword.Text = "" Then
            MessageBox.Show("Fields cannot be empty")
            ClearField()
            Exit Sub
        End If

        If currentPassword <> oldPassword Then
            MessageBox.Show("old password doesn't match")
            ClearField()
            Exit Sub
        End If

        If confirmNewPassword = oldPassword Or
           newPassword = oldPassword Then
            MessageBox.Show("Cannot use old password")
            ClearField()
            Exit Sub
        End If

        If newPassword <> confirmNewPassword Then
            MessageBox.Show("New password doesn't match")
            ClearField()
            Exit Sub
        End If

        UpdateSql("UPDATE user_accts SET Password = '" & newPassword & "' WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon, False)
        MessageBox.Show("Updated password Successfully")
        Me.Close()
    End Sub
End Class