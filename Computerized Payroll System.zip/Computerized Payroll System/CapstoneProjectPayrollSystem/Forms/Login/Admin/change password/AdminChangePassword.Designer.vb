﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminChangePassword
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxOldPassword = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox2 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TxtboxConfirmNewPassword = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxNewPassword = New Guna.UI2.WinForms.Guna2TextBox()
        Me.BtnSave = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.Guna2GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.Controls.Add(Me.TxtboxOldPassword)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox1.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(350, 70)
        Me.Guna2GroupBox1.TabIndex = 3
        Me.Guna2GroupBox1.Text = "OLD PASSWORD"
        Me.Guna2GroupBox1.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxOldPassword
        '
        Me.TxtboxOldPassword.BorderColor = System.Drawing.Color.Black
        Me.TxtboxOldPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxOldPassword.DefaultText = ""
        Me.TxtboxOldPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxOldPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxOldPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxOldPassword.DisabledState.Parent = Me.TxtboxOldPassword
        Me.TxtboxOldPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxOldPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxOldPassword.FocusedState.Parent = Me.TxtboxOldPassword
        Me.TxtboxOldPassword.ForeColor = System.Drawing.Color.Black
        Me.TxtboxOldPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxOldPassword.HoverState.Parent = Me.TxtboxOldPassword
        Me.TxtboxOldPassword.Location = New System.Drawing.Point(4, 35)
        Me.TxtboxOldPassword.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxOldPassword.Name = "TxtboxOldPassword"
        Me.TxtboxOldPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TxtboxOldPassword.PlaceholderText = "Enter old password"
        Me.TxtboxOldPassword.SelectedText = ""
        Me.TxtboxOldPassword.ShadowDecoration.Parent = Me.TxtboxOldPassword
        Me.TxtboxOldPassword.Size = New System.Drawing.Size(342, 25)
        Me.TxtboxOldPassword.TabIndex = 0
        '
        'Guna2GroupBox2
        '
        Me.Guna2GroupBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox2.Controls.Add(Me.TxtboxConfirmNewPassword)
        Me.Guna2GroupBox2.Controls.Add(Me.TxtboxNewPassword)
        Me.Guna2GroupBox2.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GroupBox2.CustomBorderThickness = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.Guna2GroupBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox2.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox2.Location = New System.Drawing.Point(12, 99)
        Me.Guna2GroupBox2.Name = "Guna2GroupBox2"
        Me.Guna2GroupBox2.ShadowDecoration.Parent = Me.Guna2GroupBox2
        Me.Guna2GroupBox2.Size = New System.Drawing.Size(350, 122)
        Me.Guna2GroupBox2.TabIndex = 4
        Me.Guna2GroupBox2.Text = "NEW PASSWORD"
        Me.Guna2GroupBox2.TextOffset = New System.Drawing.Point(0, -10)
        '
        'TxtboxConfirmNewPassword
        '
        Me.TxtboxConfirmNewPassword.BorderColor = System.Drawing.Color.Black
        Me.TxtboxConfirmNewPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxConfirmNewPassword.DefaultText = ""
        Me.TxtboxConfirmNewPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxConfirmNewPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxConfirmNewPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxConfirmNewPassword.DisabledState.Parent = Me.TxtboxConfirmNewPassword
        Me.TxtboxConfirmNewPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxConfirmNewPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxConfirmNewPassword.FocusedState.Parent = Me.TxtboxConfirmNewPassword
        Me.TxtboxConfirmNewPassword.ForeColor = System.Drawing.Color.Black
        Me.TxtboxConfirmNewPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxConfirmNewPassword.HoverState.Parent = Me.TxtboxConfirmNewPassword
        Me.TxtboxConfirmNewPassword.Location = New System.Drawing.Point(4, 66)
        Me.TxtboxConfirmNewPassword.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.TxtboxConfirmNewPassword.Name = "TxtboxConfirmNewPassword"
        Me.TxtboxConfirmNewPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TxtboxConfirmNewPassword.PlaceholderText = "Confirm new password"
        Me.TxtboxConfirmNewPassword.SelectedText = ""
        Me.TxtboxConfirmNewPassword.ShadowDecoration.Parent = Me.TxtboxConfirmNewPassword
        Me.TxtboxConfirmNewPassword.Size = New System.Drawing.Size(342, 25)
        Me.TxtboxConfirmNewPassword.TabIndex = 1
        '
        'TxtboxNewPassword
        '
        Me.TxtboxNewPassword.BorderColor = System.Drawing.Color.Black
        Me.TxtboxNewPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxNewPassword.DefaultText = ""
        Me.TxtboxNewPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxNewPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxNewPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxNewPassword.DisabledState.Parent = Me.TxtboxNewPassword
        Me.TxtboxNewPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxNewPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxNewPassword.FocusedState.Parent = Me.TxtboxNewPassword
        Me.TxtboxNewPassword.ForeColor = System.Drawing.Color.Black
        Me.TxtboxNewPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxNewPassword.HoverState.Parent = Me.TxtboxNewPassword
        Me.TxtboxNewPassword.Location = New System.Drawing.Point(4, 35)
        Me.TxtboxNewPassword.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtboxNewPassword.Name = "TxtboxNewPassword"
        Me.TxtboxNewPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TxtboxNewPassword.PlaceholderText = "Enter new password"
        Me.TxtboxNewPassword.SelectedText = ""
        Me.TxtboxNewPassword.ShadowDecoration.Parent = Me.TxtboxNewPassword
        Me.TxtboxNewPassword.Size = New System.Drawing.Size(342, 25)
        Me.TxtboxNewPassword.TabIndex = 0
        '
        'BtnSave
        '
        Me.BtnSave.CheckedState.Parent = Me.BtnSave
        Me.BtnSave.CustomImages.Parent = Me.BtnSave
        Me.BtnSave.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSave.ForeColor = System.Drawing.Color.White
        Me.BtnSave.HoverState.Parent = Me.BtnSave
        Me.BtnSave.Location = New System.Drawing.Point(101, 240)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.ShadowDecoration.Parent = Me.BtnSave
        Me.BtnSave.Size = New System.Drawing.Size(180, 45)
        Me.BtnSave.TabIndex = 5
        Me.BtnSave.Text = "SAVE"
        '
        'AdminChangePassword
        '
        Me.AcceptButton = Me.BtnSave
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(374, 297)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.Controls.Add(Me.Guna2GroupBox2)
        Me.Controls.Add(Me.BtnSave)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(390, 336)
        Me.MinimumSize = New System.Drawing.Size(390, 336)
        Me.Name = "AdminChangePassword"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AdminChangePassword"
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxOldPassword As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox2 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TxtboxConfirmNewPassword As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxNewPassword As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents BtnSave As Guna.UI2.WinForms.Guna2Button
End Class
