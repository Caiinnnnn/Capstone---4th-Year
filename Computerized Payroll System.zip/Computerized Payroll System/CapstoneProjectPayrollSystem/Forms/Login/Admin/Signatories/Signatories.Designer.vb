﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Signatories
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxBudgetFullName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxBudgetPosition = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxApprovalPosition = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxApprovalFullName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.BtnSave = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.AutoSize = False
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2HtmlLabel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(312, 32)
        Me.Guna2HtmlLabel1.TabIndex = 0
        Me.Guna2HtmlLabel1.Text = "SIGNATORIES"
        Me.Guna2HtmlLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(12, 97)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(133, 19)
        Me.Guna2HtmlLabel2.TabIndex = 1
        Me.Guna2HtmlLabel2.Text = "For budget allocation"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(12, 122)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(61, 19)
        Me.Guna2HtmlLabel3.TabIndex = 2
        Me.Guna2HtmlLabel3.Text = "Full Name"
        '
        'TxtboxBudgetFullName
        '
        Me.TxtboxBudgetFullName.BorderColor = System.Drawing.Color.Black
        Me.TxtboxBudgetFullName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxBudgetFullName.DefaultText = ""
        Me.TxtboxBudgetFullName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxBudgetFullName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxBudgetFullName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxBudgetFullName.DisabledState.Parent = Me.TxtboxBudgetFullName
        Me.TxtboxBudgetFullName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxBudgetFullName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxBudgetFullName.FocusedState.Parent = Me.TxtboxBudgetFullName
        Me.TxtboxBudgetFullName.ForeColor = System.Drawing.Color.Black
        Me.TxtboxBudgetFullName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxBudgetFullName.HoverState.Parent = Me.TxtboxBudgetFullName
        Me.TxtboxBudgetFullName.Location = New System.Drawing.Point(79, 122)
        Me.TxtboxBudgetFullName.Name = "TxtboxBudgetFullName"
        Me.TxtboxBudgetFullName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxBudgetFullName.PlaceholderText = ""
        Me.TxtboxBudgetFullName.SelectedText = ""
        Me.TxtboxBudgetFullName.ShadowDecoration.Parent = Me.TxtboxBudgetFullName
        Me.TxtboxBudgetFullName.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxBudgetFullName.TabIndex = 3
        '
        'TxtboxBudgetPosition
        '
        Me.TxtboxBudgetPosition.BorderColor = System.Drawing.Color.Black
        Me.TxtboxBudgetPosition.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxBudgetPosition.DefaultText = ""
        Me.TxtboxBudgetPosition.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxBudgetPosition.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxBudgetPosition.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxBudgetPosition.DisabledState.Parent = Me.TxtboxBudgetPosition
        Me.TxtboxBudgetPosition.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxBudgetPosition.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxBudgetPosition.FocusedState.Parent = Me.TxtboxBudgetPosition
        Me.TxtboxBudgetPosition.ForeColor = System.Drawing.Color.Black
        Me.TxtboxBudgetPosition.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxBudgetPosition.HoverState.Parent = Me.TxtboxBudgetPosition
        Me.TxtboxBudgetPosition.Location = New System.Drawing.Point(79, 148)
        Me.TxtboxBudgetPosition.Name = "TxtboxBudgetPosition"
        Me.TxtboxBudgetPosition.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxBudgetPosition.PlaceholderText = ""
        Me.TxtboxBudgetPosition.SelectedText = ""
        Me.TxtboxBudgetPosition.ShadowDecoration.Parent = Me.TxtboxBudgetPosition
        Me.TxtboxBudgetPosition.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxBudgetPosition.TabIndex = 5
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(24, 149)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(49, 19)
        Me.Guna2HtmlLabel4.TabIndex = 4
        Me.Guna2HtmlLabel4.Text = "Position"
        '
        'TxtboxApprovalPosition
        '
        Me.TxtboxApprovalPosition.BorderColor = System.Drawing.Color.Black
        Me.TxtboxApprovalPosition.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxApprovalPosition.DefaultText = ""
        Me.TxtboxApprovalPosition.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxApprovalPosition.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxApprovalPosition.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxApprovalPosition.DisabledState.Parent = Me.TxtboxApprovalPosition
        Me.TxtboxApprovalPosition.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxApprovalPosition.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxApprovalPosition.FocusedState.Parent = Me.TxtboxApprovalPosition
        Me.TxtboxApprovalPosition.ForeColor = System.Drawing.Color.Black
        Me.TxtboxApprovalPosition.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxApprovalPosition.HoverState.Parent = Me.TxtboxApprovalPosition
        Me.TxtboxApprovalPosition.Location = New System.Drawing.Point(79, 267)
        Me.TxtboxApprovalPosition.Name = "TxtboxApprovalPosition"
        Me.TxtboxApprovalPosition.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxApprovalPosition.PlaceholderText = ""
        Me.TxtboxApprovalPosition.SelectedText = ""
        Me.TxtboxApprovalPosition.ShadowDecoration.Parent = Me.TxtboxApprovalPosition
        Me.TxtboxApprovalPosition.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxApprovalPosition.TabIndex = 10
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(24, 268)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(49, 19)
        Me.Guna2HtmlLabel5.TabIndex = 9
        Me.Guna2HtmlLabel5.Text = "Position"
        '
        'TxtboxApprovalFullName
        '
        Me.TxtboxApprovalFullName.BorderColor = System.Drawing.Color.Black
        Me.TxtboxApprovalFullName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxApprovalFullName.DefaultText = ""
        Me.TxtboxApprovalFullName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxApprovalFullName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxApprovalFullName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxApprovalFullName.DisabledState.Parent = Me.TxtboxApprovalFullName
        Me.TxtboxApprovalFullName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxApprovalFullName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxApprovalFullName.FocusedState.Parent = Me.TxtboxApprovalFullName
        Me.TxtboxApprovalFullName.ForeColor = System.Drawing.Color.Black
        Me.TxtboxApprovalFullName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxApprovalFullName.HoverState.Parent = Me.TxtboxApprovalFullName
        Me.TxtboxApprovalFullName.Location = New System.Drawing.Point(79, 241)
        Me.TxtboxApprovalFullName.Name = "TxtboxApprovalFullName"
        Me.TxtboxApprovalFullName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxApprovalFullName.PlaceholderText = ""
        Me.TxtboxApprovalFullName.SelectedText = ""
        Me.TxtboxApprovalFullName.ShadowDecoration.Parent = Me.TxtboxApprovalFullName
        Me.TxtboxApprovalFullName.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxApprovalFullName.TabIndex = 8
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(12, 241)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(61, 19)
        Me.Guna2HtmlLabel6.TabIndex = 7
        Me.Guna2HtmlLabel6.Text = "Full Name"
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(12, 216)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(80, 19)
        Me.Guna2HtmlLabel7.TabIndex = 6
        Me.Guna2HtmlLabel7.Text = "For approval"
        '
        'BtnSave
        '
        Me.BtnSave.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSave.BorderThickness = 1
        Me.BtnSave.CheckedState.Parent = Me.BtnSave
        Me.BtnSave.CustomImages.Parent = Me.BtnSave
        Me.BtnSave.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSave.ForeColor = System.Drawing.Color.White
        Me.BtnSave.HoverState.Parent = Me.BtnSave
        Me.BtnSave.Location = New System.Drawing.Point(79, 305)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.ShadowDecoration.Parent = Me.BtnSave
        Me.BtnSave.Size = New System.Drawing.Size(180, 45)
        Me.BtnSave.TabIndex = 11
        Me.BtnSave.Text = "SAVE"
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.signature
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(12, 41)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.ShadowDecoration.Parent = Me.Guna2PictureBox1
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(50, 50)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox1.TabIndex = 12
        Me.Guna2PictureBox1.TabStop = False
        '
        'Signatories
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(312, 362)
        Me.Controls.Add(Me.Guna2PictureBox1)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.TxtboxApprovalPosition)
        Me.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Controls.Add(Me.TxtboxApprovalFullName)
        Me.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Controls.Add(Me.Guna2HtmlLabel7)
        Me.Controls.Add(Me.TxtboxBudgetPosition)
        Me.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Controls.Add(Me.TxtboxBudgetFullName)
        Me.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Name = "Signatories"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Signatories"
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxBudgetFullName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxBudgetPosition As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxApprovalPosition As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxApprovalFullName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents BtnSave As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
End Class
