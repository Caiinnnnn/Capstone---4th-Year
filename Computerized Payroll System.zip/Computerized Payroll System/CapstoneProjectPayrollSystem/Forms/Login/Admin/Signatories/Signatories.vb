﻿Public Class Signatories
    Private Sub Signatories_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrieveRow("SELECT * FROM signatories WHERE Type = 'BUDGET'", strCon)
        TxtboxBudgetFullName.Text = myreader("FullName")
        TxtboxBudgetPosition.Text = myreader("Position")

        RetrieveRow("SELECT * FROM signatories WHERE Type = 'APPROVAL'", strCon)
        TxtboxApprovalFullName.Text = myreader("FullName")
        TxtboxApprovalPosition.Text = myreader("Position")
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If TxtboxBudgetFullName.Text = "" Or
           TxtboxBudgetPosition.Text = "" Or
           TxtboxApprovalFullName.Text = "" Or
           TxtboxApprovalPosition.Text = "" Then
            MessageBox.Show("Cannot have empty fields")
            Exit Sub
        End If

        UpdateQuery("UPDATE signatories SET FullName = '" & TxtboxBudgetFullName.Text & "',
                                            Position = '" & TxtboxBudgetPosition.Text & "'
                                            WHERE Type = 'BUDGET'", strCon, False)

        UpdateQuery("UPDATE signatories SET FullName = '" & TxtboxApprovalFullName.Text & "',
                                            Position = '" & TxtboxApprovalPosition.Text & "'
                                            WHERE Type = 'APPROVAL'", strCon, True)

        Me.Close()
    End Sub
End Class