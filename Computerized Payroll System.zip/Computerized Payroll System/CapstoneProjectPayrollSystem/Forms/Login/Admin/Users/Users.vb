﻿Public Class Users
    Public tblUsers As New DataTable("tblUsers")

    Public Sub UsersClearField()
        TxtboxUsername.Clear()
        TxtboxPassword.Clear()
        TxtboxFullName.Clear()
        TxtboxPosition.Clear()
        CmboxUserType.SelectedIndex = -1
        TxtboxSearch.Clear()
        CmboxSearchUserType.SelectedIndex = -1
        TxtboxUsername.Focus()
    End Sub

    Public Sub RefreshUsers()

        tblUsers.Clear()

        For Each row As DataRow In RetrieveData("SELECT * FROM user_accts", strCon).Rows
            tblUsers.Rows.Add(row.Item("Username"),
                              row.Item("Password"),
                              row.Item("FullName"),
                              row.Item("Position"),
                              row.Item("UserType")
                             )
        Next

        Dtglist.DataSource = tblUsers


    End Sub

    Private Sub Users_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LblUsernameValidate.Text = ""

        tblUsers.Columns.Add("USERNAME")
        tblUsers.Columns.Add("PASSWORD")
        tblUsers.Columns.Add("FULL NAME")
        tblUsers.Columns.Add("POSITION")
        tblUsers.Columns.Add("USER TYPE")

        'Dtglist.DataSource = tblUsers

        RefreshUsers()
    End Sub

    Private Sub TxtboxUsername_Leave(sender As Object, e As EventArgs) Handles TxtboxUsername.Leave
        If TxtboxUsername.Text = "" Then
            PicboxUsernameValidate.Image = Nothing
            LblUsernameValidate.Text = Nothing
            Exit Sub
        End If

        Dim validateUser As Integer = CountSql("SELECT COUNT (Username) FROM user_accts WHERE Username = '" & TxtboxUsername.Text & "'", strCon)

        If validateUser >= 1 Then
            PicboxUsernameValidate.Image = My.Resources.cross_mark
            LblUsernameValidate.Text = "Username has been taken"
            LblUsernameValidate.ForeColor = Color.Red
        ElseIf validateUser < 1 Then
            PicboxUsernameValidate.Image = My.Resources.check_mark
            LblUsernameValidate.Text = "Username is available"
            LblUsernameValidate.ForeColor = Color.Green
        End If
    End Sub

    Private Sub BtnCreate_Click(sender As Object, e As EventArgs) Handles BtnCreate.Click

        If TxtboxUsername.Text = "" Or
            TxtboxPassword.Text = "" Or
            TxtboxFullName.Text = "" Or
            TxtboxPosition.Text = "" Or
            CmboxUserType.SelectedIndex = -1 Then

            MessageBox.Show("Cannot have empty fields")
            TxtboxUsername.Focus()
            Exit Sub
        End If

        If TxtboxUsername.Text.Length <= 3 Or TxtboxPassword.Text.Length <= 3 Then
            MessageBox.Show("Username/Password cannot be less than 3 characters")
            TxtboxUsername.Focus()
            Exit Sub
        End If

        CreateQuery("INSERT INTO user_accts (Username,
                                            Password,
                                            Fullname,
                                            Position,
                                            Avatar,
                                            UserType)
                                            VALUES (
                                            '" & TxtboxUsername.Text & "',
                                            '" & TxtboxPassword.Text & "',
                                            '" & TxtboxFullName.Text & "',
                                            '" & TxtboxPosition.Text.ToUpper & "',
                                            'man_1',
                                            '" & CmboxUserType.Text & "')", strCon, True)
        RefreshUsers()
        UsersClearField()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        RefreshUsers()
        UsersClearField()
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        tblUsers.Clear()

        For Each row As DataRow In RetrieveData("SELECT * FROM user_accts
                                                WHERE
                                                (Username LIKE '%" & TxtboxSearch.Text & "%' AND UserType LIKE '%" & CmboxSearchUserType.Text & "%')
                                                OR (FullName LIKE '%" & TxtboxSearch.Text & "%' AND UserType LIKE '%" & CmboxSearchUserType.Text & "%')
                                                OR (Position LIKE '%" & TxtboxSearch.Text & "%' AND UserType LIKE '%" & CmboxSearchUserType.Text & "%')", strCon).Rows
            tblUsers.Rows.Add(row.Item("Username"),
                              row.Item("Password"),
                              row.Item("FullName"),
                              row.Item("Position"),
                              row.Item("UserType")
                             )
        Next

        Dtglist.DataSource = tblUsers
    End Sub

    Private Sub Dtglist_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dtglist.CellDoubleClick
        If Dtglist.RowCount <= 0 Then
            Exit Sub
        End If

        EditUsers.TxtboxUsername.Text = Dtglist.CurrentRow.Cells("USERNAME").Value
        EditUsers.TxtboxPassword.Text = Dtglist.CurrentRow.Cells("PASSWORD").Value
        EditUsers.TxtboxFullName.Text = Dtglist.CurrentRow.Cells("FULL NAME").Value
        EditUsers.TxtboxPosition.Text = Dtglist.CurrentRow.Cells("POSITION").Value
        EditUsers.CmboxUserType.Text = Dtglist.CurrentRow.Cells("USER TYPE").Value

        EditUsers.Show()
    End Sub
End Class