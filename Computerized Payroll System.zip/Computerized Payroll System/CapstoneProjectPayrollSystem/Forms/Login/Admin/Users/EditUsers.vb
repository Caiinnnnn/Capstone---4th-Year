﻿Public Class EditUsers
    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles BtnUpdate.Click
        If TxtboxUsername.Text = "" Or
            TxtboxPassword.Text = "" Or
            TxtboxFullName.Text = "" Or
            TxtboxPosition.Text = "" Or
            CmboxUserType.SelectedIndex = -1 Then

            MessageBox.Show("Cannot have empty fields")
            TxtboxUsername.Focus()
            Exit Sub
        End If

        If TxtboxUsername.Text.Length <= 3 Or TxtboxPassword.Text.Length <= 3 Then
            MessageBox.Show("Username/Password cannot be less than 3 characters")
            TxtboxUsername.Focus()
            Exit Sub
        End If

        UpdateQuery("UPDATE user_accts SET
                    Password = '" & TxtboxPassword.Text & "',
                    FullName = '" & TxtboxFullName.Text & "',
                    Position = '" & TxtboxPosition.Text & "',
                    UserType = '" & CmboxUserType.Text & "'
                    WHERE
                    Username = '" & TxtboxUsername.Text & "'", strCon, True)
        Users.UsersClearField()
        Users.RefreshUsers()
        Me.Close()
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click

        If TxtboxUsername.Text = GlobalVariables.loginUsername Then
            MessageBox.Show("Cannot delete currently active user")
            Me.Close()
            Exit Sub
        End If

        If CmboxUserType.Text = "Admin" Then
            Dim countAdmin As Integer = CountSql("SELECT COUNT (*) FROM user_accts WHERE UserType = 'Admin'", strCon)
            If countAdmin <= 1 Then
                MessageBox.Show("Cannot delete last admin")
                Me.Close()
                Exit Sub
            End If
        End If

        Dim confirmDelete As String = InputBox("type CONFIRM to delete data", "DELETE")

        If confirmDelete.ToUpper <> "CONFIRM" Then
            MessageBox.Show("Incorrect input")
            Exit Sub
        End If

        DeleteQuery("DELETE FROM user_accts WHERE Username = '" & TxtboxUsername.Text & "'", strCon, True)
        Users.UsersClearField()
        Users.RefreshUsers()
        Me.Close()
    End Sub
End Class