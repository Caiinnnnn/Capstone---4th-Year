﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Users
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.LblUsernameValidate = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.CmboxUserType = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxPosition = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxFullName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxPassword = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxUsername = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Dtglist = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.BtnCreate = New Guna.UI2.WinForms.Guna2Button()
        Me.TxtboxSearch = New Guna.UI2.WinForms.Guna2TextBox()
        Me.CmboxSearchUserType = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.BtnSearch = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnClear = New Guna.UI2.WinForms.Guna2Button()
        Me.PicboxUsernameValidate = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        CType(Me.Dtglist, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicboxUsernameValidate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LblUsernameValidate
        '
        Me.LblUsernameValidate.BackColor = System.Drawing.Color.Transparent
        Me.LblUsernameValidate.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblUsernameValidate.ForeColor = System.Drawing.Color.Black
        Me.LblUsernameValidate.Location = New System.Drawing.Point(86, 75)
        Me.LblUsernameValidate.Name = "LblUsernameValidate"
        Me.LblUsernameValidate.Size = New System.Drawing.Size(126, 19)
        Me.LblUsernameValidate.TabIndex = 25
        Me.LblUsernameValidate.Text = "LblUsernameValidate"
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(15, 198)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(63, 19)
        Me.Guna2HtmlLabel5.TabIndex = 23
        Me.Guna2HtmlLabel5.Text = "User Type"
        '
        'CmboxUserType
        '
        Me.CmboxUserType.BackColor = System.Drawing.Color.Transparent
        Me.CmboxUserType.BorderColor = System.Drawing.Color.Black
        Me.CmboxUserType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxUserType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxUserType.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxUserType.FocusedState.Parent = Me.CmboxUserType
        Me.CmboxUserType.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxUserType.ForeColor = System.Drawing.Color.Black
        Me.CmboxUserType.FormattingEnabled = True
        Me.CmboxUserType.HoverState.Parent = Me.CmboxUserType
        Me.CmboxUserType.ItemHeight = 15
        Me.CmboxUserType.Items.AddRange(New Object() {"Admin", "User"})
        Me.CmboxUserType.ItemsAppearance.Parent = Me.CmboxUserType
        Me.CmboxUserType.Location = New System.Drawing.Point(86, 198)
        Me.CmboxUserType.Name = "CmboxUserType"
        Me.CmboxUserType.ShadowDecoration.Parent = Me.CmboxUserType
        Me.CmboxUserType.Size = New System.Drawing.Size(200, 21)
        Me.CmboxUserType.TabIndex = 22
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(28, 173)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(52, 19)
        Me.Guna2HtmlLabel4.TabIndex = 21
        Me.Guna2HtmlLabel4.Text = "Position"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(16, 148)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(64, 19)
        Me.Guna2HtmlLabel3.TabIndex = 20
        Me.Guna2HtmlLabel3.Text = "Full Name"
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(18, 122)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(61, 19)
        Me.Guna2HtmlLabel2.TabIndex = 19
        Me.Guna2HtmlLabel2.Text = "Password"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(15, 97)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(64, 19)
        Me.Guna2HtmlLabel1.TabIndex = 18
        Me.Guna2HtmlLabel1.Text = "Username"
        '
        'TxtboxPosition
        '
        Me.TxtboxPosition.BorderColor = System.Drawing.Color.Black
        Me.TxtboxPosition.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPosition.DefaultText = ""
        Me.TxtboxPosition.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPosition.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPosition.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPosition.DisabledState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPosition.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPosition.FocusedState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPosition.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPosition.HoverState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.Location = New System.Drawing.Point(86, 172)
        Me.TxtboxPosition.Margin = New System.Windows.Forms.Padding(21, 34, 21, 34)
        Me.TxtboxPosition.Name = "TxtboxPosition"
        Me.TxtboxPosition.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPosition.PlaceholderText = ""
        Me.TxtboxPosition.SelectedText = ""
        Me.TxtboxPosition.ShadowDecoration.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxPosition.TabIndex = 17
        '
        'TxtboxFullName
        '
        Me.TxtboxFullName.BorderColor = System.Drawing.Color.Black
        Me.TxtboxFullName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxFullName.DefaultText = ""
        Me.TxtboxFullName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxFullName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxFullName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxFullName.DisabledState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxFullName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxFullName.FocusedState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.ForeColor = System.Drawing.Color.Black
        Me.TxtboxFullName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxFullName.HoverState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.Location = New System.Drawing.Point(86, 147)
        Me.TxtboxFullName.Margin = New System.Windows.Forms.Padding(14, 21, 14, 21)
        Me.TxtboxFullName.Name = "TxtboxFullName"
        Me.TxtboxFullName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxFullName.PlaceholderText = ""
        Me.TxtboxFullName.SelectedText = ""
        Me.TxtboxFullName.ShadowDecoration.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxFullName.TabIndex = 16
        '
        'TxtboxPassword
        '
        Me.TxtboxPassword.BorderColor = System.Drawing.Color.Black
        Me.TxtboxPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPassword.DefaultText = ""
        Me.TxtboxPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPassword.DisabledState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPassword.FocusedState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPassword.HoverState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.Location = New System.Drawing.Point(86, 122)
        Me.TxtboxPassword.Margin = New System.Windows.Forms.Padding(9, 13, 9, 13)
        Me.TxtboxPassword.Name = "TxtboxPassword"
        Me.TxtboxPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPassword.PlaceholderText = ""
        Me.TxtboxPassword.SelectedText = ""
        Me.TxtboxPassword.ShadowDecoration.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxPassword.TabIndex = 15
        '
        'TxtboxUsername
        '
        Me.TxtboxUsername.BorderColor = System.Drawing.Color.Black
        Me.TxtboxUsername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxUsername.DefaultText = ""
        Me.TxtboxUsername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxUsername.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxUsername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxUsername.DisabledState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxUsername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxUsername.FocusedState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.ForeColor = System.Drawing.Color.Black
        Me.TxtboxUsername.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxUsername.HoverState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.Location = New System.Drawing.Point(86, 96)
        Me.TxtboxUsername.Margin = New System.Windows.Forms.Padding(6, 8, 6, 8)
        Me.TxtboxUsername.Name = "TxtboxUsername"
        Me.TxtboxUsername.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxUsername.PlaceholderText = ""
        Me.TxtboxUsername.SelectedText = ""
        Me.TxtboxUsername.ShadowDecoration.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxUsername.TabIndex = 14
        '
        'Dtglist
        '
        Me.Dtglist.AllowUserToAddRows = False
        Me.Dtglist.AllowUserToDeleteRows = False
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.Dtglist.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle10
        Me.Dtglist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Dtglist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Dtglist.BackgroundColor = System.Drawing.Color.White
        Me.Dtglist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dtglist.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Dtglist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle11.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dtglist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Dtglist.DefaultCellStyle = DataGridViewCellStyle12
        Me.Dtglist.EnableHeadersVisualStyles = False
        Me.Dtglist.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Dtglist.Location = New System.Drawing.Point(321, 93)
        Me.Dtglist.Name = "Dtglist"
        Me.Dtglist.ReadOnly = True
        Me.Dtglist.RowHeadersVisible = False
        Me.Dtglist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dtglist.Size = New System.Drawing.Size(464, 177)
        Me.Dtglist.TabIndex = 26
        Me.Dtglist.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.Dtglist.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.Dtglist.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.Dtglist.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.Dtglist.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.Dtglist.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Dtglist.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.Dtglist.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.Dtglist.ThemeStyle.HeaderStyle.Height = 23
        Me.Dtglist.ThemeStyle.ReadOnly = True
        Me.Dtglist.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Dtglist.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Dtglist.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Dtglist.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.Dtglist.ThemeStyle.RowsStyle.Height = 22
        Me.Dtglist.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        Me.Dtglist.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.AutoSize = False
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2HtmlLabel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(0, 0)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(800, 33)
        Me.Guna2HtmlLabel6.TabIndex = 28
        Me.Guna2HtmlLabel6.Text = "USER MANAGEMENT"
        Me.Guna2HtmlLabel6.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft
        '
        'BtnCreate
        '
        Me.BtnCreate.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnCreate.BorderThickness = 1
        Me.BtnCreate.CheckedState.Parent = Me.BtnCreate
        Me.BtnCreate.CustomImages.Parent = Me.BtnCreate
        Me.BtnCreate.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnCreate.ForeColor = System.Drawing.Color.White
        Me.BtnCreate.HoverState.Parent = Me.BtnCreate
        Me.BtnCreate.Location = New System.Drawing.Point(97, 229)
        Me.BtnCreate.Name = "BtnCreate"
        Me.BtnCreate.ShadowDecoration.Parent = Me.BtnCreate
        Me.BtnCreate.Size = New System.Drawing.Size(180, 45)
        Me.BtnCreate.TabIndex = 29
        Me.BtnCreate.Text = "CREATE"
        '
        'TxtboxSearch
        '
        Me.TxtboxSearch.BorderColor = System.Drawing.Color.Black
        Me.TxtboxSearch.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxSearch.DefaultText = ""
        Me.TxtboxSearch.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxSearch.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxSearch.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSearch.DisabledState.Parent = Me.TxtboxSearch
        Me.TxtboxSearch.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxSearch.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSearch.FocusedState.Parent = Me.TxtboxSearch
        Me.TxtboxSearch.ForeColor = System.Drawing.Color.Black
        Me.TxtboxSearch.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxSearch.HoverState.Parent = Me.TxtboxSearch
        Me.TxtboxSearch.Location = New System.Drawing.Point(321, 281)
        Me.TxtboxSearch.Margin = New System.Windows.Forms.Padding(6, 8, 6, 8)
        Me.TxtboxSearch.Name = "TxtboxSearch"
        Me.TxtboxSearch.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxSearch.PlaceholderText = ""
        Me.TxtboxSearch.SelectedText = ""
        Me.TxtboxSearch.ShadowDecoration.Parent = Me.TxtboxSearch
        Me.TxtboxSearch.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxSearch.TabIndex = 30
        '
        'CmboxSearchUserType
        '
        Me.CmboxSearchUserType.BackColor = System.Drawing.Color.Transparent
        Me.CmboxSearchUserType.BorderColor = System.Drawing.Color.Black
        Me.CmboxSearchUserType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxSearchUserType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxSearchUserType.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxSearchUserType.FocusedState.Parent = Me.CmboxSearchUserType
        Me.CmboxSearchUserType.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxSearchUserType.ForeColor = System.Drawing.Color.Black
        Me.CmboxSearchUserType.FormattingEnabled = True
        Me.CmboxSearchUserType.HoverState.Parent = Me.CmboxSearchUserType
        Me.CmboxSearchUserType.ItemHeight = 15
        Me.CmboxSearchUserType.Items.AddRange(New Object() {"Admin", "User"})
        Me.CmboxSearchUserType.ItemsAppearance.Parent = Me.CmboxSearchUserType
        Me.CmboxSearchUserType.Location = New System.Drawing.Point(530, 281)
        Me.CmboxSearchUserType.Name = "CmboxSearchUserType"
        Me.CmboxSearchUserType.ShadowDecoration.Parent = Me.CmboxSearchUserType
        Me.CmboxSearchUserType.Size = New System.Drawing.Size(91, 21)
        Me.CmboxSearchUserType.TabIndex = 31
        '
        'BtnSearch
        '
        Me.BtnSearch.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnSearch.BorderThickness = 1
        Me.BtnSearch.CheckedState.Parent = Me.BtnSearch
        Me.BtnSearch.CustomImages.Parent = Me.BtnSearch
        Me.BtnSearch.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnSearch.ForeColor = System.Drawing.Color.White
        Me.BtnSearch.HoverState.Parent = Me.BtnSearch
        Me.BtnSearch.Location = New System.Drawing.Point(627, 281)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.ShadowDecoration.Parent = Me.BtnSearch
        Me.BtnSearch.Size = New System.Drawing.Size(61, 21)
        Me.BtnSearch.TabIndex = 32
        Me.BtnSearch.Text = "SEARCH"
        '
        'BtnClear
        '
        Me.BtnClear.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BtnClear.BorderThickness = 1
        Me.BtnClear.CheckedState.Parent = Me.BtnClear
        Me.BtnClear.CustomImages.Parent = Me.BtnClear
        Me.BtnClear.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnClear.ForeColor = System.Drawing.Color.White
        Me.BtnClear.HoverState.Parent = Me.BtnClear
        Me.BtnClear.Location = New System.Drawing.Point(727, 281)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.ShadowDecoration.Parent = Me.BtnClear
        Me.BtnClear.Size = New System.Drawing.Size(61, 21)
        Me.BtnClear.TabIndex = 33
        Me.BtnClear.Text = "CLEAR"
        '
        'PicboxUsernameValidate
        '
        Me.PicboxUsernameValidate.Location = New System.Drawing.Point(295, 97)
        Me.PicboxUsernameValidate.Name = "PicboxUsernameValidate"
        Me.PicboxUsernameValidate.ShadowDecoration.Parent = Me.PicboxUsernameValidate
        Me.PicboxUsernameValidate.Size = New System.Drawing.Size(20, 20)
        Me.PicboxUsernameValidate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicboxUsernameValidate.TabIndex = 27
        Me.PicboxUsernameValidate.TabStop = False
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.users
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(321, 37)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.ShadowDecoration.Parent = Me.Guna2PictureBox1
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(50, 50)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox1.TabIndex = 34
        Me.Guna2PictureBox1.TabStop = False
        '
        'Users
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 320)
        Me.Controls.Add(Me.Guna2PictureBox1)
        Me.Controls.Add(Me.BtnClear)
        Me.Controls.Add(Me.BtnSearch)
        Me.Controls.Add(Me.CmboxSearchUserType)
        Me.Controls.Add(Me.TxtboxSearch)
        Me.Controls.Add(Me.BtnCreate)
        Me.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Controls.Add(Me.PicboxUsernameValidate)
        Me.Controls.Add(Me.LblUsernameValidate)
        Me.Controls.Add(Me.Dtglist)
        Me.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Controls.Add(Me.CmboxUserType)
        Me.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Controls.Add(Me.TxtboxPosition)
        Me.Controls.Add(Me.TxtboxFullName)
        Me.Controls.Add(Me.TxtboxPassword)
        Me.Controls.Add(Me.TxtboxUsername)
        Me.Name = "Users"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Users"
        CType(Me.Dtglist, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicboxUsernameValidate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblUsernameValidate As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents CmboxUserType As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxPosition As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxFullName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxPassword As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxUsername As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Dtglist As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents PicboxUsernameValidate As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents BtnCreate As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents TxtboxSearch As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents CmboxSearchUserType As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents BtnSearch As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnClear As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
End Class
