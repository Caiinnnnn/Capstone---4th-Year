﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditUsers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxUsername = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxPassword = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxFullName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TxtboxPosition = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.BtnUpdate = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnDelete = New Guna.UI2.WinForms.Guna2Button()
        Me.CmboxUserType = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.SuspendLayout()
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.AutoSize = False
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(75, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2HtmlLabel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(343, 32)
        Me.Guna2HtmlLabel1.TabIndex = 0
        Me.Guna2HtmlLabel1.Text = "Edit User"
        Me.Guna2HtmlLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(30, 52)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(64, 19)
        Me.Guna2HtmlLabel2.TabIndex = 1
        Me.Guna2HtmlLabel2.Text = "Username"
        '
        'TxtboxUsername
        '
        Me.TxtboxUsername.BorderColor = System.Drawing.Color.Black
        Me.TxtboxUsername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxUsername.DefaultText = ""
        Me.TxtboxUsername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxUsername.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxUsername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxUsername.DisabledState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxUsername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxUsername.FocusedState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.ForeColor = System.Drawing.Color.Black
        Me.TxtboxUsername.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxUsername.HoverState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.Location = New System.Drawing.Point(103, 52)
        Me.TxtboxUsername.Margin = New System.Windows.Forms.Padding(6, 8, 6, 8)
        Me.TxtboxUsername.Name = "TxtboxUsername"
        Me.TxtboxUsername.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxUsername.PlaceholderText = ""
        Me.TxtboxUsername.ReadOnly = True
        Me.TxtboxUsername.SelectedText = ""
        Me.TxtboxUsername.ShadowDecoration.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxUsername.TabIndex = 15
        '
        'TxtboxPassword
        '
        Me.TxtboxPassword.BorderColor = System.Drawing.Color.Black
        Me.TxtboxPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPassword.DefaultText = ""
        Me.TxtboxPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPassword.DisabledState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPassword.FocusedState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPassword.HoverState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.Location = New System.Drawing.Point(103, 88)
        Me.TxtboxPassword.Margin = New System.Windows.Forms.Padding(6, 8, 6, 8)
        Me.TxtboxPassword.Name = "TxtboxPassword"
        Me.TxtboxPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPassword.PlaceholderText = ""
        Me.TxtboxPassword.SelectedText = ""
        Me.TxtboxPassword.ShadowDecoration.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxPassword.TabIndex = 17
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(33, 89)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(61, 19)
        Me.Guna2HtmlLabel3.TabIndex = 16
        Me.Guna2HtmlLabel3.Text = "Password"
        '
        'TxtboxFullName
        '
        Me.TxtboxFullName.BorderColor = System.Drawing.Color.Black
        Me.TxtboxFullName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxFullName.DefaultText = ""
        Me.TxtboxFullName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxFullName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxFullName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxFullName.DisabledState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxFullName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxFullName.FocusedState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.ForeColor = System.Drawing.Color.Black
        Me.TxtboxFullName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxFullName.HoverState.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.Location = New System.Drawing.Point(103, 124)
        Me.TxtboxFullName.Margin = New System.Windows.Forms.Padding(6, 8, 6, 8)
        Me.TxtboxFullName.Name = "TxtboxFullName"
        Me.TxtboxFullName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxFullName.PlaceholderText = ""
        Me.TxtboxFullName.SelectedText = ""
        Me.TxtboxFullName.ShadowDecoration.Parent = Me.TxtboxFullName
        Me.TxtboxFullName.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxFullName.TabIndex = 19
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(30, 125)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(64, 19)
        Me.Guna2HtmlLabel4.TabIndex = 18
        Me.Guna2HtmlLabel4.Text = "Full Name"
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(42, 161)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(52, 19)
        Me.Guna2HtmlLabel5.TabIndex = 23
        Me.Guna2HtmlLabel5.Text = "Position"
        '
        'TxtboxPosition
        '
        Me.TxtboxPosition.BorderColor = System.Drawing.Color.Black
        Me.TxtboxPosition.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPosition.DefaultText = ""
        Me.TxtboxPosition.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPosition.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPosition.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPosition.DisabledState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPosition.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPosition.FocusedState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPosition.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPosition.HoverState.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.Location = New System.Drawing.Point(103, 160)
        Me.TxtboxPosition.Margin = New System.Windows.Forms.Padding(21, 34, 21, 34)
        Me.TxtboxPosition.Name = "TxtboxPosition"
        Me.TxtboxPosition.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxPosition.PlaceholderText = ""
        Me.TxtboxPosition.SelectedText = ""
        Me.TxtboxPosition.ShadowDecoration.Parent = Me.TxtboxPosition
        Me.TxtboxPosition.Size = New System.Drawing.Size(200, 20)
        Me.TxtboxPosition.TabIndex = 22
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(31, 197)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(63, 19)
        Me.Guna2HtmlLabel6.TabIndex = 25
        Me.Guna2HtmlLabel6.Text = "User Type"
        '
        'BtnUpdate
        '
        Me.BtnUpdate.CheckedState.Parent = Me.BtnUpdate
        Me.BtnUpdate.CustomImages.Parent = Me.BtnUpdate
        Me.BtnUpdate.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnUpdate.ForeColor = System.Drawing.Color.White
        Me.BtnUpdate.HoverState.Parent = Me.BtnUpdate
        Me.BtnUpdate.Location = New System.Drawing.Point(12, 244)
        Me.BtnUpdate.Name = "BtnUpdate"
        Me.BtnUpdate.ShadowDecoration.Parent = Me.BtnUpdate
        Me.BtnUpdate.Size = New System.Drawing.Size(158, 45)
        Me.BtnUpdate.TabIndex = 26
        Me.BtnUpdate.Text = "UPDATE"
        '
        'BtnDelete
        '
        Me.BtnDelete.CheckedState.Parent = Me.BtnDelete
        Me.BtnDelete.CustomImages.Parent = Me.BtnDelete
        Me.BtnDelete.FillColor = System.Drawing.Color.Red
        Me.BtnDelete.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnDelete.ForeColor = System.Drawing.Color.White
        Me.BtnDelete.HoverState.Parent = Me.BtnDelete
        Me.BtnDelete.Location = New System.Drawing.Point(176, 244)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.ShadowDecoration.Parent = Me.BtnDelete
        Me.BtnDelete.Size = New System.Drawing.Size(158, 45)
        Me.BtnDelete.TabIndex = 27
        Me.BtnDelete.Text = "DELETE"
        '
        'CmboxUserType
        '
        Me.CmboxUserType.BackColor = System.Drawing.Color.Transparent
        Me.CmboxUserType.BorderColor = System.Drawing.Color.Black
        Me.CmboxUserType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CmboxUserType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmboxUserType.FocusedColor = System.Drawing.Color.Empty
        Me.CmboxUserType.FocusedState.Parent = Me.CmboxUserType
        Me.CmboxUserType.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CmboxUserType.ForeColor = System.Drawing.Color.Black
        Me.CmboxUserType.FormattingEnabled = True
        Me.CmboxUserType.HoverState.Parent = Me.CmboxUserType
        Me.CmboxUserType.ItemHeight = 15
        Me.CmboxUserType.Items.AddRange(New Object() {"Admin", "User"})
        Me.CmboxUserType.ItemsAppearance.Parent = Me.CmboxUserType
        Me.CmboxUserType.Location = New System.Drawing.Point(103, 195)
        Me.CmboxUserType.Name = "CmboxUserType"
        Me.CmboxUserType.ShadowDecoration.Parent = Me.CmboxUserType
        Me.CmboxUserType.Size = New System.Drawing.Size(200, 21)
        Me.CmboxUserType.TabIndex = 28
        '
        'EditUsers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(343, 320)
        Me.Controls.Add(Me.CmboxUserType)
        Me.Controls.Add(Me.BtnDelete)
        Me.Controls.Add(Me.BtnUpdate)
        Me.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Controls.Add(Me.TxtboxPosition)
        Me.Controls.Add(Me.TxtboxFullName)
        Me.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Controls.Add(Me.TxtboxPassword)
        Me.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Controls.Add(Me.TxtboxUsername)
        Me.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Name = "EditUsers"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EditUsers"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxUsername As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxPassword As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxFullName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents TxtboxPosition As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents BtnUpdate As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnDelete As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents CmboxUserType As Guna.UI2.WinForms.Guna2ComboBox
End Class
