﻿Public Class AdminChangeAvatar
    Private Sub AdminChangeAvatar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrieveRow("SELECT * FROM user_accts WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon)
        Dim selectedAvatar As String = myreader("Avatar")

        If selectedAvatar = "man_1" Then
            Radio_man1.Checked = True
        ElseIf selectedAvatar = "man_2" Then
            Radio_man2.Checked = True
        ElseIf selectedAvatar = "man_3" Then
            Radio_man3.Checked = True
        ElseIf selectedAvatar = "man_4" Then
            Radio_man4.Checked = True
        ElseIf selectedAvatar = "man_5" Then
            Radio_man5.Checked = True
        ElseIf selectedAvatar = "man_6" Then
            Radio_man6.Checked = True
        ElseIf selectedAvatar = "man_7" Then
            Radio_man7.Checked = True
        ElseIf selectedAvatar = "woman_1" Then
            Radio_woman1.Checked = True
        ElseIf selectedAvatar = "woman_2" Then
            Radio_woman2.Checked = True
        ElseIf selectedAvatar = "woman_3" Then
            Radio_woman3.Checked = True
        ElseIf selectedAvatar = "woman_4" Then
            Radio_woman4.Checked = True
        ElseIf selectedAvatar = "woman_5" Then
            Radio_woman5.Checked = True
        ElseIf selectedAvatar = "woman_6" Then
            Radio_woman6.Checked = True
        ElseIf selectedAvatar = "woman_7" Then
            Radio_woman7.Checked = True
        ElseIf selectedAvatar = "animal_1" Then
            Radio_animal1.Checked = True
        ElseIf selectedAvatar = "animal_2" Then
            Radio_animal2.Checked = True
        ElseIf selectedAvatar = "animal_3" Then
            Radio_animal3.Checked = True
        ElseIf selectedAvatar = "animal_4" Then
            Radio_animal4.Checked = True
        ElseIf selectedAvatar = "animal_5" Then
            Radio_animal5.Checked = True
        ElseIf selectedAvatar = "animal_6" Then
            Radio_animal6.Checked = True
        ElseIf selectedAvatar = "animal_7" Then
            Radio_animal7.Checked = True
        End If
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim selectedAvatar As String = "man_1"

        If Radio_man1.Checked = True Then
            selectedAvatar = "man_1"
        ElseIf Radio_man2.Checked = True Then
            selectedAvatar = "man_2"
        ElseIf Radio_man3.Checked = True Then
            selectedAvatar = "man_3"
        ElseIf Radio_man4.Checked = True Then
            selectedAvatar = "man_4"
        ElseIf Radio_man5.Checked = True Then
            selectedAvatar = "man_5"
        ElseIf Radio_man6.Checked = True Then
            selectedAvatar = "man_6"
        ElseIf Radio_man7.Checked = True Then
            selectedAvatar = "man_7"
        ElseIf Radio_woman1.Checked = True Then
            selectedAvatar = "woman_1"
        ElseIf Radio_woman2.Checked = True Then
            selectedAvatar = "woman_2"
        ElseIf Radio_woman3.Checked = True Then
            selectedAvatar = "woman_3"
        ElseIf Radio_woman4.Checked = True Then
            selectedAvatar = "woman_4"
        ElseIf Radio_woman5.Checked = True Then
            selectedAvatar = "woman_5"
        ElseIf Radio_woman6.Checked = True Then
            selectedAvatar = "woman_6"
        ElseIf Radio_woman7.Checked = True Then
            selectedAvatar = "woman_7"
        ElseIf Radio_animal1.Checked = True Then
            selectedAvatar = "animal_1"
        ElseIf Radio_animal2.Checked = True Then
            selectedAvatar = "animal_2"
        ElseIf Radio_animal3.Checked = True Then
            selectedAvatar = "animal_3"
        ElseIf Radio_animal4.Checked = True Then
            selectedAvatar = "animal_4"
        ElseIf Radio_animal5.Checked = True Then
            selectedAvatar = "animal_5"
        ElseIf Radio_animal6.Checked = True Then
            selectedAvatar = "animal_6"
        ElseIf Radio_animal7.Checked = True Then
            selectedAvatar = "animal_7"
        End If

        UpdateQuery("UPDATE user_accts SET Avatar = '" & selectedAvatar & "' WHERE Username = '" & GlobalVariables.loginUsername & "'", strCon, False)
        AdminDashboard.RefreshAdminDashboard()
        Me.Close()
    End Sub
End Class