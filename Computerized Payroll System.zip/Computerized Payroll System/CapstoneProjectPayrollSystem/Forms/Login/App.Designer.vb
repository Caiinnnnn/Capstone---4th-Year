﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class App
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.ChckboxShowPassword = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.BtnClose = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnLogin = New Guna.UI2.WinForms.Guna2Button()
        Me.TxtboxPassword = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TxtboxUsername = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2Panel1.SuspendLayout()
        Me.Guna2Panel2.SuspendLayout()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(131, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Guna2Panel1.Controls.Add(Me.ChckboxShowPassword)
        Me.Guna2Panel1.Controls.Add(Me.BtnClose)
        Me.Guna2Panel1.Controls.Add(Me.BtnLogin)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxPassword)
        Me.Guna2Panel1.Controls.Add(Me.TxtboxUsername)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(250, 489)
        Me.Guna2Panel1.TabIndex = 0
        '
        'ChckboxShowPassword
        '
        Me.ChckboxShowPassword.AutoSize = True
        Me.ChckboxShowPassword.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxShowPassword.CheckedState.BorderRadius = 2
        Me.ChckboxShowPassword.CheckedState.BorderThickness = 0
        Me.ChckboxShowPassword.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ChckboxShowPassword.Location = New System.Drawing.Point(39, 198)
        Me.ChckboxShowPassword.Name = "ChckboxShowPassword"
        Me.ChckboxShowPassword.Size = New System.Drawing.Size(102, 17)
        Me.ChckboxShowPassword.TabIndex = 4
        Me.ChckboxShowPassword.Text = "Show Password"
        Me.ChckboxShowPassword.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxShowPassword.UncheckedState.BorderRadius = 2
        Me.ChckboxShowPassword.UncheckedState.BorderThickness = 0
        Me.ChckboxShowPassword.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ChckboxShowPassword.UseVisualStyleBackColor = True
        '
        'BtnClose
        '
        Me.BtnClose.BorderRadius = 10
        Me.BtnClose.CheckedState.Parent = Me.BtnClose
        Me.BtnClose.CustomImages.Parent = Me.BtnClose
        Me.BtnClose.FillColor = System.Drawing.Color.Red
        Me.BtnClose.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnClose.ForeColor = System.Drawing.Color.White
        Me.BtnClose.HoverState.Parent = Me.BtnClose
        Me.BtnClose.Location = New System.Drawing.Point(29, 300)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.ShadowDecoration.Parent = Me.BtnClose
        Me.BtnClose.Size = New System.Drawing.Size(200, 45)
        Me.BtnClose.TabIndex = 3
        Me.BtnClose.Text = "Close"
        '
        'BtnLogin
        '
        Me.BtnLogin.BorderRadius = 10
        Me.BtnLogin.CheckedState.Parent = Me.BtnLogin
        Me.BtnLogin.CustomImages.Parent = Me.BtnLogin
        Me.BtnLogin.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnLogin.ForeColor = System.Drawing.Color.White
        Me.BtnLogin.HoverState.Parent = Me.BtnLogin
        Me.BtnLogin.Location = New System.Drawing.Point(29, 249)
        Me.BtnLogin.Name = "BtnLogin"
        Me.BtnLogin.ShadowDecoration.Parent = Me.BtnLogin
        Me.BtnLogin.Size = New System.Drawing.Size(200, 45)
        Me.BtnLogin.TabIndex = 2
        Me.BtnLogin.Text = "Login"
        '
        'TxtboxPassword
        '
        Me.TxtboxPassword.BorderColor = System.Drawing.Color.Black
        Me.TxtboxPassword.BorderRadius = 10
        Me.TxtboxPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxPassword.DefaultText = ""
        Me.TxtboxPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPassword.DisabledState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPassword.FocusedState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.ForeColor = System.Drawing.Color.Black
        Me.TxtboxPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxPassword.HoverState.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.Location = New System.Drawing.Point(29, 156)
        Me.TxtboxPassword.Name = "TxtboxPassword"
        Me.TxtboxPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TxtboxPassword.PlaceholderForeColor = System.Drawing.Color.Gray
        Me.TxtboxPassword.PlaceholderText = "Password"
        Me.TxtboxPassword.SelectedText = ""
        Me.TxtboxPassword.ShadowDecoration.Parent = Me.TxtboxPassword
        Me.TxtboxPassword.Size = New System.Drawing.Size(200, 36)
        Me.TxtboxPassword.TabIndex = 1
        '
        'TxtboxUsername
        '
        Me.TxtboxUsername.BorderColor = System.Drawing.Color.Black
        Me.TxtboxUsername.BorderRadius = 10
        Me.TxtboxUsername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtboxUsername.DefaultText = ""
        Me.TxtboxUsername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TxtboxUsername.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TxtboxUsername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxUsername.DisabledState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TxtboxUsername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxUsername.FocusedState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.ForeColor = System.Drawing.Color.Black
        Me.TxtboxUsername.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TxtboxUsername.HoverState.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.Location = New System.Drawing.Point(29, 103)
        Me.TxtboxUsername.Name = "TxtboxUsername"
        Me.TxtboxUsername.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TxtboxUsername.PlaceholderForeColor = System.Drawing.Color.Gray
        Me.TxtboxUsername.PlaceholderText = "Username"
        Me.TxtboxUsername.SelectedText = ""
        Me.TxtboxUsername.ShadowDecoration.Parent = Me.TxtboxUsername
        Me.TxtboxUsername.Size = New System.Drawing.Size(200, 36)
        Me.TxtboxUsername.TabIndex = 0
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.White
        Me.Guna2Panel2.Controls.Add(Me.Guna2PictureBox1)
        Me.Guna2Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2Panel2.Location = New System.Drawing.Point(250, 0)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(566, 489)
        Me.Guna2Panel2.TabIndex = 1
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = Global.CapstoneProjectPayrollSystem.My.Resources.Resources.ljcs_logo
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(54, 15)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.ShadowDecoration.Parent = Me.Guna2PictureBox1
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(450, 450)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox1.TabIndex = 0
        Me.Guna2PictureBox1.TabStop = False
        '
        'App
        '
        Me.AcceptButton = Me.BtnLogin
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(816, 489)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximumSize = New System.Drawing.Size(816, 489)
        Me.MinimumSize = New System.Drawing.Size(816, 489)
        Me.Name = "App"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "App"
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.Guna2Panel2.ResumeLayout(False)
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents BtnClose As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnLogin As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents TxtboxPassword As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TxtboxUsername As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents ChckboxShowPassword As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
End Class
